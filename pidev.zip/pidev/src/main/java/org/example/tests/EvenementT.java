package org.example.tests;

import javafx.application.Application;
import javafx.stage.Stage;

public class EvenementT extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Mon application JavaFX");
        primaryStage.setWidth(700);
        primaryStage.setHeight(700);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
