package org.example.utils;

import org.example.entities.Evenement;          // ⚠️ Corrigé
import org.example.services.EvenementService;   // ⚠️ Corrigé si tu as respecté la casse

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class TestEvenement {

    public static void main(String[] args) {

        EvenementService es = new EvenementService();

        // 🔹 Création d'un nouvel événement
        Evenement e = new Evenement(
                "Concert Rock",
                "Concert de rock en plein air",
                LocalDate.of(2026, 2, 15),
                LocalTime.of(20, 0),
                "Stade Municipal",
                50.0,
                200,
                "Actif"
        );

        // 🔹 Ajouter l'événement à la base
        es.ajouterEvenement(e);

        // 🔹 Afficher tous les événements pour vérifier
        List<Evenement> evenements = es.afficherEvenements();
        for (Evenement ev : evenements) {
            System.out.println("ID: " + ev.getId_event() +
                    ", Titre: " + ev.getTitre() +
                    ", Date: " + ev.getDate_event() +
                    ", Lieu: " + ev.getLieu() +
                    ", Prix: " + ev.getPrix());
        }
    }
}
