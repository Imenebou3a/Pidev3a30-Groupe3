package org.example.utils;

import org.example.entities.Hebergement;
import org.example.entities.Reservation;
import org.example.services.HebergementService;
import org.example.services.ReservationService;

import java.sql.Connection;
import java.time.LocalDate;
import java.util.List;

public class TestReservation {
    public static void main(String[] args) {
        Connection conn = MyDataBase.getConnection();
        if (conn == null) return;

        // Services
        HebergementService hs = new HebergementService(conn);
        ReservationService rs = new ReservationService(conn);

        // Ajouter hébergements
        Hebergement h1 = new Hebergement("Hotel Paradis", "Hotel", "Tunis", "200 DT");
        Hebergement h2 = new Hebergement("Auberge Sousse", "Auberge", "Sousse", "150 DT");
        hs.ajouterHebergement(h1);
        hs.ajouterHebergement(h2);

        // Ajouter réservations
        Reservation r1 = new Reservation(1, LocalDate.of(2026,2,15), LocalDate.of(2026,2,20), 2);
        Reservation r2 = new Reservation(2, LocalDate.of(2026,3,5), LocalDate.of(2026,3,10), 4);
        rs.ajouterReservation(r1);
        rs.ajouterReservation(r2);

        // Lister hébergements
        System.out.println("\n=== Hébergements ===");
        List<Hebergement> lh = hs.getAllHebergements();
        lh.forEach(System.out::println);

        // Lister réservations
        System.out.println("\n=== Réservations ===");
        List<Reservation> lr = rs.getAllReservations();
        lr.forEach(r -> System.out.println(
                "ID Hébergement: "+r.getIdHebergement()+
                        ", Du: "+r.getDateDebut()+
                        ", Au: "+r.getDateFin()+
                        ", Personnes: "+r.getNbPersonnes()
        ));
    }
}
