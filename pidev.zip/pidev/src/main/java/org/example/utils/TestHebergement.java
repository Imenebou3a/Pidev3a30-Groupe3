package org.example.utils;

import org.example.entities.Hebergement;
import org.example.services.HebergementService;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

public class TestHebergement {

    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/pidev?useSSL=false&serverTimezone=UTC";
        String user = "root";
        String password = "1234"; // ⚠️ mets le VRAI mot de passe MySQL

        try {
            // CHARGEMENT DU DRIVER
            Class.forName("com.mysql.cj.jdbc.Driver");

            // CONNEXION
            Connection conn = DriverManager.getConnection(url, user, password);
            System.out.println("✅ Connexion réussie");

            HebergementService service = new HebergementService(conn);

            Hebergement h1 = new Hebergement("Hotel Paradis", "Hotel", "Tunis", "200 DT");
            Hebergement h2 = new Hebergement("Auberge Sousse", "Auberge", "Sousse", "150 DT");

            service.ajouterHebergement(h1);
            service.ajouterHebergement(h2);

            System.out.println("✅ Hébergements ajoutés");

            List<Hebergement> liste = service.getAllHebergements();
            liste.forEach(System.out::println);

            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
