package org.example.utils;

import java.sql.Connection;

public class TestConnexion {
    public static void main(String[] args) {
        Connection conn = MyDataBase.getConnection();
        if (conn != null) {
            System.out.println("✅ Connexion réussie !");
        } else {
            System.out.println("❌ Échec de la connexion à la base de données.");
        }
    }
}
