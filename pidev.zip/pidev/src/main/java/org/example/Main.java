package org.example;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/reservation.fxml"));
        Scene scene = new Scene(loader.load());

        // Appliquer le CSS
        scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());

        stage.setTitle("Gestion Hébergements & Réservations");
        stage.setScene(scene);
        stage.setMaximized(true); // plein écran
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
