package org.example.services;

import org.example.entities.Hebergement;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HebergementService {

    private Connection conn;

    public HebergementService(Connection conn) {
        this.conn = conn;
    }

    public void ajouterHebergement(Hebergement h) {
        String sql = "INSERT INTO hebergement (nom, type, adresse, prix) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pst = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pst.setString(1, h.getNom());
            pst.setString(2, h.getType());
            pst.setString(3, h.getAdresse());
            pst.setString(4, h.getPrix());
            pst.executeUpdate();

            ResultSet rs = pst.getGeneratedKeys();
            if (rs.next()) h.setId(rs.getInt(1));

            System.out.println("Hébergement ajouté : " + h);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Hebergement> getAllHebergements() {
        List<Hebergement> liste = new ArrayList<>();
        String sql = "SELECT id, nom, type, adresse, prix FROM hebergement";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                liste.add(new Hebergement(
                        rs.getInt("id"),
                        rs.getString("nom"),
                        rs.getString("type"),
                        rs.getString("adresse"),
                        rs.getString("prix")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return liste;
    }
}
