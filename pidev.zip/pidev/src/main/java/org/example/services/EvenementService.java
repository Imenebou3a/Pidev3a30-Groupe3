package org.example.services;

import org.example.entities.Evenement;
import org.example.utils.MyDataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EvenementService {

    Connection conn = MyDataBase.getConnection();

    // 🔹 CREATE
    public void ajouterEvenement(Evenement e) {
        String sql = "INSERT INTO evenement (titre, description, date_event, heure_event, lieu, prix, nb_places, statut) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, e.getTitre());
            ps.setString(2, e.getDescription());
            ps.setDate(3, Date.valueOf(e.getDate_event()));
            ps.setTime(4, Time.valueOf(e.getHeure_event()));
            ps.setString(5, e.getLieu());
            ps.setDouble(6, e.getPrix());
            ps.setInt(7, e.getNb_places());
            ps.setString(8, e.getStatut());

            ps.executeUpdate();
            System.out.println("✅ Événement ajouté !");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // 🔹 READ : Tous les événements
    public List<Evenement> afficherEvenements() {
        List<Evenement> evenements = new ArrayList<>();
        String sql = "SELECT * FROM evenement";
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Evenement e = new Evenement();
                e.setId_event(rs.getLong("id_event"));
                e.setTitre(rs.getString("titre"));
                e.setDescription(rs.getString("description"));
                e.setDate_event(rs.getDate("date_event").toLocalDate());
                e.setHeure_event(rs.getTime("heure_event").toLocalTime());
                e.setLieu(rs.getString("lieu"));
                e.setPrix(rs.getDouble("prix"));
                e.setNb_places(rs.getInt("nb_places"));
                e.setStatut(rs.getString("statut"));
                evenements.add(e);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return evenements;
    }

    // 🔹 READ : Par ID
    public Evenement trouverEvenementParId(long id) {
        Evenement e = null;
        String sql = "SELECT * FROM evenement WHERE id_event=?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                e = new Evenement();
                e.setId_event(rs.getLong("id_event"));
                e.setTitre(rs.getString("titre"));
                e.setDescription(rs.getString("description"));
                e.setDate_event(rs.getDate("date_event").toLocalDate());
                e.setHeure_event(rs.getTime("heure_event").toLocalTime());
                e.setLieu(rs.getString("lieu"));
                e.setPrix(rs.getDouble("prix"));
                e.setNb_places(rs.getInt("nb_places"));
                e.setStatut(rs.getString("statut"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return e;
    }

    // 🔹 UPDATE
    public void modifierEvenement(Evenement e) {
        String sql = "UPDATE evenement SET titre=?, description=?, date_event=?, heure_event=?, lieu=?, prix=?, nb_places=?, statut=? WHERE id_event=?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, e.getTitre());
            ps.setString(2, e.getDescription());
            ps.setDate(3, Date.valueOf(e.getDate_event()));
            ps.setTime(4, Time.valueOf(e.getHeure_event()));
            ps.setString(5, e.getLieu());
            ps.setDouble(6, e.getPrix());
            ps.setInt(7, e.getNb_places());
            ps.setString(8, e.getStatut());
            ps.setLong(9, e.getId_event());

            ps.executeUpdate();
            System.out.println("✏️ Événement modifié !");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // 🔹 DELETE
    public void supprimerEvenement(long id_event) {
        String sql = "DELETE FROM evenement WHERE id_event=?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setLong(1, id_event);
            ps.executeUpdate();
            System.out.println("🗑️ Événement supprimé !");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
