package org.example.services;

import org.example.entities.participation;
import org.example.utils.MyDataBase;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class participationservice {

    Connection conn = MyDataBase.getConnection();

    // 🔹 CREATE : Ajouter une participation
    public void ajouterParticipation(participation p) {
        String sql = "INSERT INTO participation (nom_participant, prenom_participant, email, telephone, date_inscription, statut_p, id_event) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, p.getNom_participant());
            ps.setString(2, p.getPrenom_participant());
            ps.setString(3, p.getEmail());
            ps.setString(4, p.getTelephone());
            ps.setDate(5, Date.valueOf(p.getDate_inscription()));
            ps.setString(6, p.getStatut_p());
            ps.setInt(7, p.getId_event());

            ps.executeUpdate();
            System.out.println("✅ Participation ajoutée avec succès !");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // 🔹 READ : Afficher toutes les participations
    public List<participation> afficherParticipations() {
        List<participation> participations = new ArrayList<>();
        String sql = "SELECT * FROM participation";

        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                participation p = new participation();
                p.setId_participation(rs.getInt("id_participation"));
                p.setNom_participant(rs.getString("nom_participant"));
                p.setPrenom_participant(rs.getString("prenom_participant"));
                p.setEmail(rs.getString("email"));
                p.setTelephone(rs.getString("telephone"));
                p.setDate_inscription(rs.getDate("date_inscription").toLocalDate());
                p.setStatut_p(rs.getString("statut_p"));
                p.setId_event(rs.getInt("id_event"));

                participations.add(p);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return participations;
    }

    // 🔹 UPDATE : Modifier une participation
    public void modifierParticipation(participation p) {
        String sql = "UPDATE participation SET nom_participant=?, prenom_participant=?, email=?, telephone=?, date_inscription=?, statut_p=?, id_event=? WHERE id_participation=?";

        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, p.getNom_participant());
            ps.setString(2, p.getPrenom_participant());
            ps.setString(3, p.getEmail());
            ps.setString(4, p.getTelephone());
            ps.setDate(5, Date.valueOf(p.getDate_inscription()));
            ps.setString(6, p.getStatut_p());
            ps.setInt(7, p.getId_event());
            ps.setInt(8, p.getId_participation());

            ps.executeUpdate();
            System.out.println("✏️ Participation modifiée !");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // 🔹 DELETE : Supprimer une participation
    public void supprimerParticipation(int id_participation) {
        String sql = "DELETE FROM participation WHERE id_participation=?";

        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id_participation);
            ps.executeUpdate();
            System.out.println("🗑️ Participation supprimée !");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
