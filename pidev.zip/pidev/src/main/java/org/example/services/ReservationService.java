package org.example.services;

import org.example.entities.Reservation;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReservationService {

    private Connection conn;

    public ReservationService(Connection conn) {
        this.conn = conn;
    }

    public void ajouterReservation(Reservation r) {
        String sql = "INSERT INTO reservation (id_hebergement, date_debut, date_fin, nb_personnes) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, r.getIdHebergement());
            pst.setDate(2, Date.valueOf(r.getDateDebut()));
            pst.setDate(3, Date.valueOf(r.getDateFin()));
            pst.setInt(4, r.getNbPersonnes());
            pst.executeUpdate();
            System.out.println("Réservation ajoutée : " + r.getIdHebergement());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Reservation> getAllReservations() {
        List<Reservation> liste = new ArrayList<>();
        String sql = "SELECT id_hebergement, date_debut, date_fin, nb_personnes FROM reservation";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                liste.add(new Reservation(
                        rs.getInt("id_hebergement"),
                        rs.getDate("date_debut").toLocalDate(),
                        rs.getDate("date_fin").toLocalDate(),
                        rs.getInt("nb_personnes")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return liste;
    }
}
