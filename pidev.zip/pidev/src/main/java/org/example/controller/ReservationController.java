package org.example.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;

public class ReservationController {

    // Hébergements
    @FXML private TableView<?> tableHebergements;
    @FXML private TableColumn<?, ?> colNom;
    @FXML private TableColumn<?, ?> colType;
    @FXML private TableColumn<?, ?> colAdresse;
    @FXML private TableColumn<?, ?> colPrix;
    @FXML private TextField tfNom;
    @FXML private TextField tfType;
    @FXML private TextField tfAdresse;
    @FXML private TextField tfPrix;

    // Réservations
    @FXML private TableView<?> tableReservations;
    @FXML private TableColumn<?, ?> colIdHebergement;
    @FXML private TableColumn<?, ?> colDateDebut;
    @FXML private TableColumn<?, ?> colDateFin;
    @FXML private TableColumn<?, ?> colNbPersonnes;
    @FXML private TextField tfIdHebergement;
    @FXML private TextField tfNbPersonnes;
    @FXML private DatePicker dpDebut;
    @FXML private DatePicker dpFin;

    // Méthodes pour les boutons Hébergements
    @FXML
    private void ajouterHebergement() {
        System.out.println("Ajouter Hébergement");
    }

    @FXML
    private void modifierHebergement() {
        System.out.println("Modifier Hébergement");
    }

    @FXML
    private void supprimerHebergement() {
        System.out.println("Supprimer Hébergement");
    }

    // Méthodes pour les boutons Réservations
    @FXML
    private void ajouterReservation() {
        System.out.println("Ajouter Réservation");
    }

    @FXML
    private void modifierReservation() {
        System.out.println("Modifier Réservation");
    }

    @FXML
    private void supprimerReservation() {
        System.out.println("Supprimer Réservation");
    }
}
