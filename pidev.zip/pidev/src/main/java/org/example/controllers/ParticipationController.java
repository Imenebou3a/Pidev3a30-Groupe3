package org.example.controllers;

import org.example.entities.participation;
import org.example.services.participationservice;

import java.time.LocalDate;
import java.util.List;

public class ParticipationController {

    participationservice ps = new participationservice();

    // Ajouter une participation
    public void ajouter(String nom, String prenom, String email, String tel,
                        LocalDate dateInscription, String statut, int idEvent) {
        participation p = new participation(nom, prenom, email, tel, dateInscription, statut, idEvent);
        ps.ajouterParticipation(p);
    }

    // Lister toutes les participations
    public List<participation> lister() {
        return ps.afficherParticipations();
    }

    // Modifier une participation
    public void modifier(int id, String nom, String prenom, String email, String tel,
                         LocalDate dateInscription, String statut, int idEvent) {
        participation p = new participation(nom, prenom, email, tel, dateInscription, statut, idEvent);
        p.setId_participation(id);
        ps.modifierParticipation(p);
    }

    // Supprimer une participation
    public void supprimer(int id) {
        ps.supprimerParticipation(id);
    }
}
