package org.example.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.example.entities.Evenement;
import org.example.services.EvenementService;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class EvenementController {

    // ================= AJOUT =================
    @FXML public TextField txtTitre;
    @FXML public TextField txtDescription;
    @FXML public DatePicker dpDate;
    @FXML public TextField txtHeure;
    @FXML public TextField txtLieu;
    @FXML public TextField txtPrix;
    @FXML public TextField txtPlaces;
    @FXML public ComboBox<String> cbStatut;

    // ================= MODIFIER =================
    @FXML public TextField txtIdModif;
    @FXML public TextField txtTitreModif;
    @FXML public TextField txtDescriptionModif;
    @FXML public DatePicker dpDateModif;
    @FXML public TextField txtHeureModif;
    @FXML public TextField txtLieuModif;
    @FXML public TextField txtPrixModif;
    @FXML public TextField txtPlacesModif;
    @FXML public ComboBox<String> cbStatutModif;

    // ================= SUPPRIMER =================
    @FXML public TextField txtIdSupp;

    // ================= TABLE =================
    @FXML public TableView<Evenement> tableEvenements;
    @FXML public TableColumn<Evenement, Long> colId;
    @FXML public TableColumn<Evenement, String> colTitre;
    @FXML public TableColumn<Evenement, String> colDescription;
    @FXML public TableColumn<Evenement, LocalDate> colDate;
    @FXML public TableColumn<Evenement, LocalTime> colHeure;
    @FXML public TableColumn<Evenement, String> colLieu;
    @FXML public TableColumn<Evenement, Double> colPrix;
    @FXML public TableColumn<Evenement, Integer> colPlaces;
    @FXML public TableColumn<Evenement, String> colStatut;

    private EvenementService es = new EvenementService();
    private ObservableList<Evenement> evenementList = FXCollections.observableArrayList();

    // ================= INITIALIZE =================
    @FXML
    public void initialize() {
        // Initialiser ComboBox
        cbStatut.setItems(FXCollections.observableArrayList("Actif", "Annulé", "Complet"));
        cbStatutModif.setItems(FXCollections.observableArrayList("Actif", "Annulé", "Complet"));

        // Initialiser TableView
        colId.setCellValueFactory(cellData -> cellData.getValue().id_eventProperty().asObject());
        colTitre.setCellValueFactory(cellData -> cellData.getValue().titreProperty());
        colDescription.setCellValueFactory(cellData -> cellData.getValue().descriptionProperty());
        colDate.setCellValueFactory(cellData -> cellData.getValue().date_eventProperty());
        colHeure.setCellValueFactory(cellData -> cellData.getValue().heure_eventProperty());
        colLieu.setCellValueFactory(cellData -> cellData.getValue().lieuProperty());
        colPrix.setCellValueFactory(cellData -> cellData.getValue().prixProperty().asObject());
        colPlaces.setCellValueFactory(cellData -> cellData.getValue().nb_placesProperty().asObject());
        colStatut.setCellValueFactory(cellData -> cellData.getValue().statutProperty());

        // Charger les événements existants
        loadEvenements();
    }

    // ================= CRUD =================

    @FXML
    public void ajouterEvenement() {
        try {
            String titre = txtTitre.getText();
            String description = txtDescription.getText();
            LocalDate date = dpDate.getValue();
            LocalTime heure = LocalTime.parse(txtHeure.getText());
            String lieu = txtLieu.getText();
            double prix = Double.parseDouble(txtPrix.getText());
            int places = Integer.parseInt(txtPlaces.getText());
            String statut = cbStatut.getValue();

            Evenement e = new Evenement(titre, description, date, heure, lieu, prix, places, statut);
            es.ajouterEvenement(e);

            loadEvenements();
            clearAjouterFields();

            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Événement ajouté avec succès !");
            alert.show();

        } catch (Exception ex) {
            ex.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR, "Erreur lors de l'ajout de l'événement !");
            alert.show();
        }
    }

    @FXML
    public void modifierEvenement() {
        try {
            long id = Long.parseLong(txtIdModif.getText());
            Evenement e = es.trouverEvenementParId(id); // <-- correction ici
            if (e != null) {
                e.setTitre(txtTitreModif.getText());
                e.setDescription(txtDescriptionModif.getText());
                e.setDate_event(dpDateModif.getValue());
                e.setHeure_event(LocalTime.parse(txtHeureModif.getText()));
                e.setLieu(txtLieuModif.getText());
                e.setPrix(Double.parseDouble(txtPrixModif.getText()));
                e.setNb_places(Integer.parseInt(txtPlacesModif.getText()));
                e.setStatut(cbStatutModif.getValue());

                es.modifierEvenement(e);
                loadEvenements();
                clearModifierFields();

                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Événement modifié avec succès !");
                alert.show();
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Événement introuvable !");
                alert.show();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR, "Erreur lors de la modification !");
            alert.show();
        }
    }

    @FXML
    public void supprimerEvenement() {
        try {
            long id = Long.parseLong(txtIdSupp.getText());
            es.supprimerEvenement(id); // <-- correction ici
            loadEvenements();
            txtIdSupp.clear();

            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Événement supprimé avec succès !");
            alert.show();
        } catch (Exception ex) {
            ex.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR, "Erreur lors de la suppression !");
            alert.show();
        }
    }

    @FXML
    public void afficherEvenements() {
        loadEvenements(); // <-- méthode publique pour FXML
    }

    // ================= MÉTHODES UTILES =================
    private void loadEvenements() {
        List<Evenement> events = es.afficherEvenements();
        evenementList.setAll(events);
        tableEvenements.setItems(evenementList);
    }

    private void clearAjouterFields() {
        txtTitre.clear();
        txtDescription.clear();
        dpDate.setValue(null);
        txtHeure.clear();
        txtLieu.clear();
        txtPrix.clear();
        txtPlaces.clear();
        cbStatut.getSelectionModel().clearSelection();
    }

    private void clearModifierFields() {
        txtIdModif.clear();
        txtTitreModif.clear();
        txtDescriptionModif.clear();
        dpDateModif.setValue(null);
        txtHeureModif.clear();
        txtLieuModif.clear();
        txtPrixModif.clear();
        txtPlacesModif.clear();
        cbStatutModif.getSelectionModel().clearSelection();
    }
}
