package org.example.entities;

import java.time.LocalDate;

public class Reservation {
    private int idHebergement;
    private LocalDate dateDebut;
    private LocalDate dateFin;
    private int nbPersonnes;

    public Reservation(int idHebergement, LocalDate dateDebut, LocalDate dateFin, int nbPersonnes) {
        this.idHebergement = idHebergement;
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
        this.nbPersonnes = nbPersonnes;
    }

    public int getIdHebergement() { return idHebergement; }
    public LocalDate getDateDebut() { return dateDebut; }
    public LocalDate getDateFin() { return dateFin; }
    public int getNbPersonnes() { return nbPersonnes; }
}
