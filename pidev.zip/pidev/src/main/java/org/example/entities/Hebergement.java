package org.example.entities;

public class Hebergement {
    private int id;
    private String nom;
    private String type;
    private String adresse;
    private String prix;

    public Hebergement(int id, String nom, String type, String adresse, String prix) {
        this.id = id;
        this.nom = nom;
        this.type = type;
        this.adresse = adresse;
        this.prix = prix;
    }

    public Hebergement(String nom, String type, String adresse, String prix) {
        this.nom = nom;
        this.type = type;
        this.adresse = adresse;
        this.prix = prix;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNom() { return nom; }
    public String getType() { return type; }
    public String getAdresse() { return adresse; }
    public String getPrix() { return prix; }

    @Override
    public String toString() {
        return nom + " (" + type + ") - " + adresse + " - " + prix;
    }
}
