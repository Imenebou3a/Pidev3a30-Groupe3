package org.example.entities;

import java.time.LocalDate;

public class participation {

    private int id_participation;
    private String nom_participant;
    private String prenom_participant;
    private String email;
    private String telephone;
    private LocalDate date_inscription;
    private String statut_p;
    private int id_event; // clé étrangère vers evenement

    // Constructeur vide
    public participation() {
    }

    // Constructeur avec paramètres (sans id)
    public participation(String nom_participant, String prenom_participant,
                         String email, String telephone, LocalDate date_inscription,
                         String statut_p, int id_event) {
        this.nom_participant = nom_participant;
        this.prenom_participant = prenom_participant;
        this.email = email;
        this.telephone = telephone;
        this.date_inscription = date_inscription;
        this.statut_p = statut_p;
        this.id_event = id_event;
    }

    // Getters & Setters
    public int getId_participation() {
        return id_participation;
    }

    public void setId_participation(int id_participation) {
        this.id_participation = id_participation;
    }

    public String getNom_participant() {
        return nom_participant;
    }

    public void setNom_participant(String nom_participant) {
        this.nom_participant = nom_participant;
    }

    public String getPrenom_participant() {
        return prenom_participant;
    }

    public void setPrenom_participant(String prenom_participant) {
        this.prenom_participant = prenom_participant;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public LocalDate getDate_inscription() {
        return date_inscription;
    }

    public void setDate_inscription(LocalDate date_inscription) {
        this.date_inscription = date_inscription;
    }

    public String getStatut_p() {
        return statut_p;
    }

    public void setStatut_p(String statut_p) {
        this.statut_p = statut_p;
    }

    public int getId_event() {
        return id_event;
    }

    public void setId_event(int id_event) {
        this.id_event = id_event;
    }
}
