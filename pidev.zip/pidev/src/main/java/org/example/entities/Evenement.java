package org.example.entities;

import javafx.beans.property.*;
import java.time.LocalDate;
import java.time.LocalTime;

public class Evenement {

    private LongProperty id_event = new SimpleLongProperty();
    private StringProperty titre = new SimpleStringProperty();
    private StringProperty description = new SimpleStringProperty();
    private ObjectProperty<LocalDate> date_event = new SimpleObjectProperty<>();
    private ObjectProperty<LocalTime> heure_event = new SimpleObjectProperty<>();
    private StringProperty lieu = new SimpleStringProperty();
    private DoubleProperty prix = new SimpleDoubleProperty();
    private IntegerProperty nb_places = new SimpleIntegerProperty();
    private StringProperty statut = new SimpleStringProperty();

    // 🔹 Constructeur vide
    public Evenement() { }

    // 🔹 Constructeur sans id
    public Evenement(String titre, String description,
                     LocalDate date_event, LocalTime heure_event,
                     String lieu, double prix,
                     int nb_places, String statut) {
        this.titre.set(titre);
        this.description.set(description);
        this.date_event.set(date_event);
        this.heure_event.set(heure_event);
        this.lieu.set(lieu);
        this.prix.set(prix);
        this.nb_places.set(nb_places);
        this.statut.set(statut);
    }

    // 🔹 Getters & Setters classiques
    public long getId_event() { return id_event.get(); }
    public void setId_event(long id_event) { this.id_event.set(id_event); }

    public String getTitre() { return titre.get(); }
    public void setTitre(String titre) { this.titre.set(titre); }

    public String getDescription() { return description.get(); }
    public void setDescription(String description) { this.description.set(description); }

    public LocalDate getDate_event() { return date_event.get(); }
    public void setDate_event(LocalDate date_event) { this.date_event.set(date_event); }

    public LocalTime getHeure_event() { return heure_event.get(); }
    public void setHeure_event(LocalTime heure_event) { this.heure_event.set(heure_event); }

    public String getLieu() { return lieu.get(); }
    public void setLieu(String lieu) { this.lieu.set(lieu); }

    public double getPrix() { return prix.get(); }
    public void setPrix(double prix) { this.prix.set(prix); }

    public int getNb_places() { return nb_places.get(); }
    public void setNb_places(int nb_places) { this.nb_places.set(nb_places); }

    public String getStatut() { return statut.get(); }
    public void setStatut(String statut) { this.statut.set(statut); }

    // 🔹 Property getters pour TableView
    public LongProperty id_eventProperty() { return id_event; }
    public StringProperty titreProperty() { return titre; }
    public StringProperty descriptionProperty() { return description; }
    public ObjectProperty<LocalDate> date_eventProperty() { return date_event; }
    public ObjectProperty<LocalTime> heure_eventProperty() { return heure_event; }
    public StringProperty lieuProperty() { return lieu; }
    public DoubleProperty prixProperty() { return prix; }
    public IntegerProperty nb_placesProperty() { return nb_places; }
    public StringProperty statutProperty() { return statut; }
}
