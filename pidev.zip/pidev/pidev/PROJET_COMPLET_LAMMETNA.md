# 🏝️ PROJET LAMMETNA - DOCUMENTATION COMPLÈTE

## 📋 Vue d'ensemble

Lammetna est une plateforme de gestion et réservation d'hébergements en Tunisie, similaire à Airbnb.

## 🎨 Palette de Couleurs Officielle

### Couleurs Principales
- **Orange**: `#D9541E` - Boutons principaux, actions, prix
- **Teal**: `#17A2B8` - Navigation, titres, liens
- **Crème/Beige**: `#FFF8F0` - Backgrounds doux, sections prix
- **Gris Clair**: `#F5F7FA` - Backgrounds neutres, inputs

### Couleurs Secondaires
- **Orange Hover**: `#E86A35`
- **Orange Dark**: `#C24818`
- **Teal Hover**: `#1FC8E3`
- **Teal Dark**: `#138496`

### Couleurs Sidebar
- **Fond**: Dégradé beige `#F5F1ED` → `#EDE8E3`
- **Titre**: Teal `#17A2B8`
- **Sous-titre**: Orange `#D9541E`
- **Bouton actif**: Orange `#D9541E` avec texte blanc
- **Boutons normaux**: Gris `#4A5568`

## 🏗️ Architecture du Projet

### Structure des Dossiers
```
pidev/
├── src/main/java/org/example/
│   ├── controller/
│   │   ├── Backoffice/
│   │   │   ├── DashboardController.java
│   │   │   ├── HebergementBackController.java
│   │   │   └── ReservationBackController.java
│   │   └── Frontoffice/
│   │       └── HebergementFrontController.java
│   ├── entities/
│   │   ├── Hebergement.java
│   │   └── Reservation.java
│   ├── services/
│   │   ├── HebergementService.java
│   │   ├── ReservationService.java
│   │   ├── StatistiquesService.java
│   │   └── PdfService.java
│   ├── utils/
│   │   ├── MyDataBase.java
│   │   ├── ValidationUtils.java
│   │   └── AlertUtils.java
│   ├── BackOfficeApp.java
│   ├── FrontOfficeApp.java
│   └── MainAppWithSidebar.java
├── src/main/resources/
│   ├── Backoffice/
│   │   ├── back-final.css
│   │   ├── hebergement_back.fxml
│   │   ├── reservation_back.fxml
│   │   └── dashboard.fxml
│   ├── Frontoffice/
│   │   ├── airbnb.css
│   │   ├── hebergement-front-premium.fxml
│   │   └── hebergement-front.fxml
│   ├── styles/
│   │   ├── main-theme.css
│   │   └── animations.css
│   └── logo.png
└── uploads/hebergements/
```

## 🚀 Fonctionnalités

### Back-Office (Administration)

#### 1. Gestion des Hébergements
- **Liste**: Affichage avec filtres (recherche, type, prix)
- **Ajouter**: Formulaire avec validation en temps réel
- **Modifier**: Sélection et modification
- **Supprimer**: Confirmation avant suppression
- **Upload d'images**: Gestion des photos

#### 2. Gestion des Réservations
- **Liste**: Affichage avec filtres (hébergement, dates)
- **Ajouter**: Formulaire avec calcul automatique du prix
- **Modifier**: Mise à jour des réservations
- **Supprimer**: Suppression avec confirmation

#### 3. Dashboard (Statistiques)
- Nombre total d'hébergements
- Nombre total de réservations
- Statistiques visuelles

### Front-Office (Clients)

#### 1. Catalogue d'Hébergements
- Affichage en grille avec cards
- Filtres: recherche, type, prix maximum
- Images des hébergements
- Prix par nuit
- Bouton "Réserver"

#### 2. Réservation
- Sélection des dates
- Nombre de personnes
- Calcul automatique du prix total
- Validation de disponibilité

## 🎨 Design & CSS

### Fichiers CSS Principaux

#### 1. `main-theme.css` (Sidebar & Global)
- Sidebar beige/crème
- Boutons avec couleurs logo
- Tables et formulaires
- Animations

#### 2. `back-final.css` (Back-Office)
- TabPane moderne
- Formulaires stylisés
- Tables avec headers teal
- Boutons orange/teal

#### 3. `airbnb.css` (Front-Office)
- Navbar avec dégradé teal → orange
- Hero section
- Cards hébergements
- Filtres premium

### Composants Stylisés

#### Sidebar
```css
- Fond: Dégradé beige #F5F1ED → #EDE8E3
- Bouton actif: Orange #D9541E
- Hover: Teal léger rgba(23, 162, 184, 0.12)
```

#### TabPane
```css
- Tab normal: Gris #4A5568
- Tab hover: Fond teal léger
- Tab selected: Bordure orange #D9541E
```

#### Boutons
```css
- Primary: Orange #D9541E
- Secondary: Teal #17A2B8
- Danger: Rouge #DC3545
- Success: Vert #28A745
```

## 🔧 Configuration Base de Données

### Connexion MySQL
```java
URL: jdbc:mysql://localhost:3306/lammetna
User: root
Password: (vide ou votre mot de passe)
```

### Tables Principales

#### hebergements
```sql
CREATE TABLE hebergements (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nom VARCHAR(255) NOT NULL,
    type VARCHAR(100) NOT NULL,
    adresse VARCHAR(255) NOT NULL,
    prix VARCHAR(50) NOT NULL,
    image_path VARCHAR(500)
);
```

#### reservations
```sql
CREATE TABLE reservations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    id_hebergement INT NOT NULL,
    date_debut DATE NOT NULL,
    date_fin DATE NOT NULL,
    nb_personnes INT NOT NULL,
    FOREIGN KEY (id_hebergement) REFERENCES hebergements(id)
);
```

## 🚀 Lancement de l'Application

### Avec Maven
```bash
# Back-Office avec Sidebar
mvn clean javafx:run -Djavafx.mainClass=org.example.MainAppWithSidebar

# Back-Office simple
mvn clean javafx:run -Djavafx.mainClass=org.example.BackOfficeApp

# Front-Office
mvn clean javafx:run -Djavafx.mainClass=org.example.FrontOfficeApp
```

### Avec IDE
1. Ouvrir le projet dans IntelliJ IDEA ou Eclipse
2. Exécuter `MainAppWithSidebar.java` pour l'interface complète
3. Ou exécuter `BackOfficeApp.java` / `FrontOfficeApp.java` séparément

## 📝 Validation des Formulaires

### Règles de Validation

#### Hébergement
- **Nom**: Minimum 3 caractères, lettres et chiffres uniquement
- **Type**: Sélection obligatoire (Villa, Appartement, Maison d'hôtes, Studio, Riad)
- **Adresse**: Minimum 5 caractères
- **Prix**: Nombre positif, maximum 10000 DT

#### Réservation
- **Hébergement**: Sélection obligatoire
- **Date début**: Obligatoire, ne peut pas être dans le passé
- **Date fin**: Obligatoire, doit être après la date de début
- **Nb personnes**: Entre 1 et 20

### Validation en Temps Réel
- Bordure verte: Champ valide
- Bordure orange: Avertissement
- Bordure rouge: Erreur
- Messages d'erreur sous chaque champ

## 🐛 Résolution du Bug de Suppression

### Problème
Après suppression d'un hébergement, il reste affiché dans le tableau.

### Solution
Le code appelle déjà `chargerHebergements()` après suppression. Si le problème persiste:

1. **Vérifier la base de données**: La suppression est-elle effective en BD?
2. **Vérifier le service**: `HebergementService.supprimerHebergement()` fonctionne-t-il?
3. **Rafraîchir manuellement**: Cliquer sur "Réinitialiser" dans l'onglet Liste

### Code de Suppression
```java
@FXML
private void supprimerHebergement() {
    Hebergement h = comboHebergementSuppr.getValue();
    if (h == null) return;
    
    // Confirmation
    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
    if (alert.showAndWait().get() == ButtonType.OK) {
        hebergementService.supprimerHebergement(h.getId());
        chargerHebergements(); // ← Rafraîchit le tableau
        comboHebergementSuppr.setValue(null);
    }
}
```

## 📊 Export PDF

### Fonctionnalité
- Export de la liste des hébergements en PDF
- Export de la liste des réservations en PDF
- Fichiers sauvegardés dans `exports/`

### Utilisation
```java
PdfService pdfService = new PdfService();
pdfService.exporterHebergementsPDF(listeHebergements);
pdfService.exporterReservationsPDF(listeReservations);
```

## 🎯 Points Clés du Design

### Cohérence Visuelle
- Toutes les interfaces utilisent les mêmes 4 couleurs
- Sidebar beige/crème sur toutes les pages
- Boutons orange pour les actions principales
- Teal pour la navigation et les titres

### Expérience Utilisateur
- Validation en temps réel
- Messages de succès/erreur clairs
- Confirmations avant suppression
- Filtres intuitifs
- Preview des images

### Responsive
- Layouts adaptatifs avec GridPane et VBox
- Scroll automatique pour le contenu long
- Cards qui s'adaptent à la largeur

## 📚 Dépendances Maven

```xml
<dependencies>
    <!-- JavaFX -->
    <dependency>
        <groupId>org.openjfx</groupId>
        <artifactId>javafx-controls</artifactId>
        <version>17.0.2</version>
    </dependency>
    <dependency>
        <groupId>org.openjfx</groupId>
        <artifactId>javafx-fxml</artifactId>
        <version>17.0.2</version>
    </dependency>
    
    <!-- MySQL -->
    <dependency>
        <groupId>mysql</groupId>
        <artifactId>mysql-connector-java</artifactId>
        <version>8.0.33</version>
    </dependency>
    
    <!-- iText PDF -->
    <dependency>
        <groupId>com.itextpdf</groupId>
        <artifactId>itextpdf</artifactId>
        <version>5.5.13.3</version>
    </dependency>
</dependencies>
```

## 🔐 Sécurité

### Bonnes Pratiques Implémentées
- Validation côté client (JavaFX)
- Validation côté serveur (Service layer)
- Prepared statements pour éviter SQL injection
- Gestion des erreurs avec try-catch
- Messages d'erreur utilisateur-friendly

## 📞 Support

Pour toute question ou problème:
1. Vérifier cette documentation
2. Consulter les fichiers `.md` dans le projet
3. Vérifier les logs de la console
4. Tester la connexion à la base de données

---

**Version**: 1.0  
**Date**: Février 2026  
**Auteur**: Équipe Lammetna  
**Licence**: Projet Académique
