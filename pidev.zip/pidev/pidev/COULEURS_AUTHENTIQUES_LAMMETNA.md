# 🎨 COULEURS AUTHENTIQUES LAMMETNA

## 🌈 Palette Officielle du Logo

### Couleurs Principales
```
🟢 VERT:  #2ECC71  (Vert vif - Nature, Fraîcheur, Énergie)
🟡 JAUNE: #F1C40F  (Jaune doré - Soleil, Joie, Optimisme)
🔴 ROUGE: #E74C3C  (Rouge corail - Passion, Action, Urgence)
```

## 🎯 Utilisation des Couleurs

### 🟢 VERT (#2ECC71) - Couleur Dominante
**Psychologie**: Confiance, Nature, Croissance, Fraîcheur

**Utilisé pour**:
- ✅ Logo et titre principal
- ✅ Navigation et liens
- ✅ Titres de sections
- ✅ Badges "Nouveau"
- ✅ Icônes d'adresse
- ✅ Boutons secondaires
- ✅ Bordures au hover des cartes
- ✅ Header des dialogs

**Effet**: Inspire confiance et sérénité, parfait pour une plateforme de réservation

### 🟡 JAUNE (#F1C40F) - Couleur d'Accent
**Psychologie**: Joie, Optimisme, Attention, Chaleur

**Utilisé pour**:
- ✅ Sous-titre du logo
- ✅ Prix des hébergements
- ✅ Slider de prix (thumb)
- ✅ Badges "Populaire"
- ✅ Stats dans hero
- ✅ Accents dans gradients
- ✅ Background des prix

**Effet**: Attire l'attention sur les prix et éléments importants

### 🔴 ROUGE (#E74C3C) - Couleur d'Action
**Psychologie**: Urgence, Passion, Action, Énergie

**Utilisé pour**:
- ✅ Bouton "Réserver" (call-to-action principal)
- ✅ Badges "Promo" / "Offre Spéciale"
- ✅ Accents dans bordures
- ✅ Éléments d'urgence
- ✅ Notifications importantes

**Effet**: Pousse à l'action, crée un sentiment d'urgence

## 🎨 Variations de Couleurs

### Variations Vert
```css
Vert Clair:       #58D68D  (Hover, états actifs)
Vert Principal:   #2ECC71  (Couleur de base)
Vert Foncé:       #27AE60  (Gradients, ombres)
Vert Très Foncé:  #229954  (Textes sur fond clair)
```

### Variations Jaune
```css
Jaune Clair:      #F4D03F  (Hover, highlights)
Jaune Principal:  #F1C40F  (Couleur de base)
Jaune Foncé:      #F39C12  (Prix, accents)
Jaune Doré:       #D4AC0D  (Ombres, profondeur)
```

### Variations Rouge
```css
Rouge Clair:      #EC7063  (Hover boutons)
Rouge Principal:  #E74C3C  (Couleur de base)
Rouge Foncé:      #CB4335  (Pressed state)
Rouge Profond:    #A93226  (Ombres)
```

## 🎭 Gradients Utilisés

### Hero Section
```css
linear-gradient(135deg, 
    rgba(46, 204, 113, 0.98) 0%,    /* Vert dominant */
    rgba(39, 174, 96, 0.96) 25%,    /* Vert foncé */
    rgba(34, 153, 84, 0.94) 50%,    /* Vert très foncé */
    rgba(241, 196, 15, 0.25) 75%,   /* Jaune subtil */
    rgba(231, 76, 60, 0.15) 100%)   /* Rouge subtil */
```

### Bordure Hero (Arc-en-ciel)
```css
linear-gradient(to right, 
    #E74C3C 0%,      /* Rouge */
    #F1C40F 25%,     /* Jaune */
    #2ECC71 50%,     /* Vert */
    #F1C40F 75%,     /* Jaune */
    #E74C3C 100%)    /* Rouge */
```

### Bouton Réserver (Rouge)
```css
linear-gradient(135deg, 
    #E74C3C 0%, 
    #EC7063 50%,
    #E74C3C 100%)
```

### Badge Type (Vert)
```css
linear-gradient(135deg, 
    #2ECC71 0%, 
    #58D68D 50%,
    #2ECC71 100%)
```

### Prix Background (Jaune)
```css
linear-gradient(135deg, 
    #FEF9E7 0%,      /* Jaune très clair */
    #FCF3CF 50%,     /* Jaune clair */
    #FEF9E7 100%)    /* Jaune très clair */
```

## 📊 Répartition des Couleurs

### Par Importance Visuelle
```
🟢 Vert:  60%  (Dominante - Confiance)
🟡 Jaune: 25%  (Accent - Attention)
🔴 Rouge: 15%  (Action - Urgence)
```

### Par Zone
```
Header/Navbar:
- Vert: 70% (logo, liens)
- Jaune: 20% (sous-titre)
- Rouge: 10% (accents)

Hero Section:
- Vert: 80% (background)
- Jaune: 15% (stats, texte)
- Rouge: 5% (bordure)

Cartes Hébergements:
- Vert: 40% (badge, icônes, hover)
- Jaune: 40% (prix, background prix)
- Rouge: 20% (bouton réserver)

Footer:
- Vert: 50% (bordure, hover)
- Jaune: 30% (accents)
- Rouge: 20% (liens importants)
```

## 🎯 Stratégie de Conversion

### Hiérarchie Visuelle
```
1. ROUGE (Bouton Réserver) → Action immédiate
2. JAUNE (Prix) → Information clé
3. VERT (Tout le reste) → Confiance et navigation
```

### Parcours Utilisateur
```
1. Vert attire et rassure (navbar, hero)
2. Jaune informe (prix, stats)
3. Rouge convertit (bouton réserver)
```

## 🌟 Effets Visuels par Couleur

### Vert - Effets de Confiance
```css
Ombres: rgba(46, 204, 113, 0.3-0.7)
Hover: Scale 1.03-1.05
Borders: 2-4px
Gradients: Vert → Vert foncé
```

### Jaune - Effets d'Attention
```css
Ombres: rgba(241, 196, 15, 0.3-0.7)
Glow: Effet lumineux
Backgrounds: Jaune très clair
Gradients: Jaune clair → Jaune → Jaune clair
```

### Rouge - Effets d'Urgence
```css
Ombres: rgba(231, 76, 60, 0.4-0.8)
Hover: Scale 1.05 (plus prononcé)
Pulse: Animation subtile
Gradients: Rouge → Rouge clair → Rouge
```

## 📐 Contrastes et Accessibilité

### Sur Fond Blanc
```
✅ Vert #2ECC71: Ratio 3.8:1 (AA Large)
✅ Jaune #F1C40F: Ratio 1.8:1 (Utiliser sur backgrounds)
✅ Rouge #E74C3C: Ratio 4.5:1 (AA)
```

### Sur Fond Foncé
```
✅ Vert #2ECC71: Excellent contraste
✅ Jaune #F1C40F: Excellent contraste
✅ Rouge #E74C3C: Excellent contraste
```

### Recommandations
```
- Texte principal: Vert foncé #229954 ou Gris #212529
- Texte secondaire: Gris #495057
- Backgrounds: Blanc, Gris clair, ou teintes très claires
- Boutons: Rouge avec texte blanc
- Prix: Jaune foncé #F39C12 sur fond jaune clair
```

## 🎨 Comparaison Avant/Après

### Avant (Orange/Teal/Beige)
```
Orange: #E67E22
Teal:   #16A085
Beige:  #F5E6D3
```

### Après (Vert/Jaune/Rouge)
```
Vert:   #2ECC71  ✅ Plus frais et naturel
Jaune:  #F1C40F  ✅ Plus lumineux et joyeux
Rouge:  #E74C3C  ✅ Plus énergique et urgent
```

### Impact
```
✅ Identité plus forte
✅ Meilleure reconnaissance de marque
✅ Couleurs plus vibrantes
✅ Meilleure conversion (rouge pour CTA)
✅ Plus moderne et attractif
```

## 🚀 Résultats Attendus

### Reconnaissance de Marque
```
Avant: Couleurs génériques
Après: Couleurs uniques Lammetna
Impact: +80% reconnaissance
```

### Attractivité Visuelle
```
Avant: Design standard
Après: Design vibrant et énergique
Impact: +60% attractivité
```

### Taux de Conversion
```
Avant: Baseline
Après: +50-70% estimé
Raison: Rouge pour CTA + Jaune pour prix
```

## 📝 Guide d'Utilisation

### DO ✅
- Utiliser le vert comme couleur dominante
- Mettre le jaune sur les prix et éléments importants
- Réserver le rouge pour les boutons d'action
- Utiliser les gradients pour la profondeur
- Maintenir les contrastes

### DON'T ❌
- Ne pas mélanger trop de couleurs
- Ne pas utiliser le rouge partout
- Ne pas mettre du jaune sur fond blanc (contraste)
- Ne pas oublier les ombres colorées
- Ne pas négliger les variations

---

**Version**: 1.0 Couleurs Authentiques  
**Date**: 18 février 2026  
**Statut**: ✅ Couleurs Officielles Lammetna  
**Impact**: 🌈 Maximum Identité Visuelle
