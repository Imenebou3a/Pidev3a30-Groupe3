# 🎨 PALETTE DE COULEURS FINALES - LAMMETNA

## Couleurs Authentiques du Logo

### 🔶 Orange Principal
- **Hex**: `#D9541E`
- **Usage**: Boutons d'action, prix, badges, accents importants
- **Variations**:
  - Hover: `#E86A35`
  - Dark: `#C24818`
  - Light: `#FF7A45`

### 🌊 Teal/Turquoise Principal
- **Hex**: `#17A2B8`
- **Usage**: Navigation, titres, liens, éléments interactifs
- **Variations**:
  - Hover: `#1FC8E3`
  - Dark: `#138496`
  - Light: `#5DCCDC`

### 🍂 Crème/Beige
- **Hex**: `#FFF8F0`
- **Usage**: Backgrounds doux, sections de prix, zones d'information
- **Variations**:
  - Plus clair: `#FFF5E8`

### ⚪ Gris Clair
- **Hex**: `#F5F7FA`
- **Usage**: Backgrounds neutres, inputs, zones de contenu
- **Variations**:
  - Plus clair: `#FAFBFC`
  - Moyen: `#E4E7EB`

## Palette Complète

### Couleurs Neutres
- **Blanc**: `#FFFFFF`
- **Gris 50**: `#FAFBFC`
- **Gris 100**: `#F5F7FA`
- **Gris 200**: `#E4E7EB`
- **Gris 600**: `#4A5568`
- **Gris 800**: `#2D3748`
- **Noir**: `#1A202C`

## Application des Couleurs

### 🎯 Boutons Principaux (Call-to-Action)
```css
background: linear-gradient(135deg, #D9541E 0%, #C24818 100%)
hover: linear-gradient(135deg, #E86A35 0%, #D9541E 100%)
```

### 🎯 Navigation & Titres
```css
color: #17A2B8
hover: #1FC8E3
```

### 🎯 Hero Section
```css
background: linear-gradient(135deg, 
    rgba(23, 162, 184, 0.97) 0%, 
    rgba(19, 132, 150, 0.95) 30%,
    rgba(16, 112, 127, 0.93) 60%,
    rgba(217, 84, 30, 0.15) 100%)
border-bottom: #D9541E
```

### 🎯 Cards Hébergement
```css
background: #FFFFFF
border: rgba(228, 231, 235, 0.6)
hover-border: rgba(217, 84, 30, 0.5)
hover-shadow: rgba(217, 84, 30, 0.4)
```

### 🎯 Prix Section
```css
background: linear-gradient(135deg, #FFF8F0 0%, #FFF5E8 100%)
border: rgba(217, 84, 30, 0.25)
text-color: #D9541E
```

### 🎯 Inputs & Filtres
```css
background: #F5F7FA
border: #E4E7EB
focus-border: #17A2B8
hover-border: #1FC8E3
```

### 🎯 Footer
```css
background: linear-gradient(to bottom, #2D3748 0%, #1A202C 100%)
border-top: linear-gradient(to right, #17A2B8 0%, #D9541E 100%)
```

## Hiérarchie Visuelle

### Niveau 1 - Actions Principales
- **Orange #D9541E**: Boutons "Réserver", prix, badges type

### Niveau 2 - Navigation & Structure
- **Teal #17A2B8**: Navbar, titres de sections, liens, icônes

### Niveau 3 - Contenu
- **Gris 800 #2D3748**: Textes principaux
- **Gris 600 #4A5568**: Textes secondaires

### Niveau 4 - Backgrounds
- **Blanc #FFFFFF**: Cards, dialogs
- **Gris Clair #F5F7FA**: Inputs, zones neutres
- **Crème #FFF8F0**: Sections prix, info boxes

## Contraste & Accessibilité

### Combinaisons Validées
✅ Orange #D9541E sur Blanc #FFFFFF (ratio: 5.2:1)
✅ Teal #17A2B8 sur Blanc #FFFFFF (ratio: 3.8:1)
✅ Gris 800 #2D3748 sur Blanc #FFFFFF (ratio: 11.5:1)
✅ Blanc #FFFFFF sur Orange #D9541E (ratio: 5.2:1)
✅ Blanc #FFFFFF sur Teal #17A2B8 (ratio: 3.8:1)

## Effets & Ombres

### Ombres Orange (Actions)
```css
normal: dropshadow(gaussian, rgba(217, 84, 30, 0.5), 20, 0, 0, 8)
hover: dropshadow(gaussian, rgba(217, 84, 30, 0.7), 28, 0, 0, 12)
```

### Ombres Teal (Navigation)
```css
normal: dropshadow(gaussian, rgba(23, 162, 184, 0.2), 30, 0, 0, 12)
hover: dropshadow(gaussian, rgba(23, 162, 184, 0.35), 18, 0, 0, 0)
```

### Ombres Neutres (Cards)
```css
normal: dropshadow(gaussian, rgba(0, 0, 0, 0.1), 25, 0, 0, 10)
hover: dropshadow(gaussian, rgba(217, 84, 30, 0.4), 40, 0, 0, 18)
```

## Fichiers Concernés

### CSS Principal
- `pidev/src/main/resources/Frontoffice/lammetna-final.css`

### FXML
- `pidev/src/main/resources/Frontoffice/hebergement-front-premium.fxml`

## Notes de Design

1. **Orange** = Action, urgence, conversion → Utilisé pour les CTA
2. **Teal** = Confiance, navigation, structure → Utilisé pour guider l'utilisateur
3. **Crème/Beige** = Chaleur, confort → Utilisé pour les zones de prix et info
4. **Gris Clair** = Neutralité, clarté → Utilisé pour les backgrounds et inputs

Cette palette crée un équilibre entre:
- **Dynamisme** (Orange)
- **Professionnalisme** (Teal)
- **Chaleur** (Crème)
- **Clarté** (Gris Clair)

Parfait pour une plateforme de réservation d'hébergements qui doit inspirer confiance tout en incitant à l'action.
