# 🎨 GUIDE D'UTILISATION - DESIGN ULTRA PREMIUM LAMMETNA

## 🌟 Vue d'Ensemble

Design exceptionnel niveau luxe avec logo Lammetna intégré, inspiré des meilleures plateformes mondiales (Airbnb, Booking.com, Stripe).

## 📁 Fichiers Créés

### Front-Office
1. **`hebergement-front-premium.fxml`** - FXML ultra premium avec logo
2. **`front-ultra-pro.css`** - CSS niveau luxe (amélioré)

### Caractéristiques Principales
✅ Logo Lammetna intégré dans navbar et hero
✅ Navbar avec navigation moderne
✅ Hero section avec statistiques
✅ Filtres premium avec effets
✅ Cartes hébergements ultra modernes
✅ Footer professionnel
✅ Animations et transitions fluides

## 🎯 Comment Utiliser

### Étape 1: Mettre à Jour le Contrôleur Front-Office

Ouvrez `HebergementFrontController.java` et assurez-vous qu'il charge le bon FXML:

```java
// Dans FrontOfficeApp.java ou votre launcher
FXMLLoader loader = new FXMLLoader(
    getClass().getResource("/Frontoffice/hebergement-front-premium.fxml")
);
```

### Étape 2: Vérifier le Logo

Le logo doit être à l'emplacement:
```
pidev/src/main/resources/logo.png
```

Si le logo n'est pas là, copiez-le depuis votre dossier.

### Étape 3: Lancer l'Application

```bash
cd pidev
mvn clean javafx:run
```

## 🎨 Éléments du Design

### 1. Navbar Premium
```
- Logo Lammetna (60x60px)
- Titre "Lammetna" en teal
- Sous-titre "STAYS • EXPERIENCES • EVENTS" en orange
- Navigation: Hébergements, Favoris, Contact
- Background blanc avec ombre
```

### 2. Hero Section Ultra Premium
```
- Gradient teal avec touche orange
- Logo grand format (120x120px)
- Titre 62px: "Découvrez Votre Séjour de Rêve"
- Sous-titre 22px en beige
- Statistiques: 500+ hébergements, 10K+ clients, 4.9★
- Bordure orange en bas (5px)
```

### 3. Section Filtres
```
- Container blanc avec ombre importante
- Border-radius 24px
- Titre avec icône 🔍
- 3 filtres: Recherche, Type, Prix
- Slider prix avec thumb orange animé
- Effets hover sur tous les inputs
```

### 4. Cartes Hébergements
```
- Width: 400px
- Border-radius: 28px
- Image: 400x280px
- Badge type flottant
- Hover: translation -10px + scale 1.02
- Ombre orange au hover
- Prix en gradient beige
- Bouton réserver orange
```

### 5. Footer
```
- Background gradient gris foncé
- Bordure top gradient teal-orange
- Logo + infos + liens
- Texte blanc/gris clair
```

## ✨ Effets Visuels

### Hover Effects
```css
Cartes:
- translate-y: -10px
- scale: 1.02
- ombre: 40px blur, orange 40%
- border: 3px orange

Boutons:
- scale: 1.03
- ombre augmentée
- gradient inversé

Inputs:
- border: 3px teal
- ombre: 18px blur, teal 35%
- background: blanc
```

### Focus Effects
```css
Inputs/Combos:
- border-width: 2.5px → 3px
- border-color: → teal
- background: #F9FAFB → white
- ombre: teal 35%
```

### Pressed Effects
```css
Boutons:
- translate-y: +2px
- ombre réduite
- background: couleur foncée
```

## 🎯 Palette de Couleurs Utilisée

### Couleurs Principales
```
Orange: #E67E22 (actions, prix, accents)
Teal: #16A085 (sections, titres, liens)
Beige: #F5E6D3 (backgrounds doux, accents)
```

### Couleurs Secondaires
```
Orange Clair: #F39C12
Orange Foncé: #D35400
Teal Clair: #48C9B0
Teal Foncé: #138D75
Beige Clair: #FAF0E6
```

### Couleurs Neutres
```
Blanc: #FFFFFF
Gris 50: #F9FAFB (backgrounds)
Gris 100: #F3F4F6
Gris 200: #E5E7EB (bordures)
Gris 600: #4B5563 (texte secondaire)
Gris 800: #1F2937 (texte principal)
```

## 📐 Dimensions & Espacements

### Border Radius
```
Petit: 10-12px (badges)
Moyen: 14-16px (boutons, inputs)
Grand: 18-20px (containers)
Très Grand: 24-28px (cartes, sections)
```

### Padding
```
Compact: 16-18px (inputs)
Standard: 22-28px (cards)
Large: 30-35px (sections)
Très Large: 40-50px (containers principaux)
```

### Font Sizes
```
Très Petit: 10-11px (badges, labels)
Petit: 13-14px (texte secondaire)
Standard: 15-17px (texte, inputs)
Moyen: 18-22px (sous-titres)
Grand: 24-32px (titres sections)
Très Grand: 36-42px (statistiques)
Énorme: 62px (hero title)
```

### Font Weights
```
Normal: 600
Bold: 700-800
Extra Bold: 900
```

## 🚀 Améliorations Apportées

### Par Rapport à la Version Précédente

1. **Logo Intégré**
   - Navbar avec logo 60x60px
   - Hero avec logo 120x120px
   - Footer avec logo 50x50px

2. **Navbar Professionnelle**
   - Navigation claire
   - Liens avec hover effects
   - Indicateur de page active

3. **Hero Section Améliorée**
   - Statistiques en temps réel
   - Gradient plus riche
   - Bordure orange distinctive

4. **Filtres Plus Modernes**
   - Container avec titre
   - Layout en grille
   - Effets visuels renforcés

5. **Cartes Plus Attractives**
   - Taille augmentée (400px)
   - Hover effects spectaculaires
   - Prix mis en valeur

6. **Footer Complet**
   - Informations organisées
   - Liens utiles
   - Design cohérent

## 🎭 Classes CSS Principales

### Navigation
```css
.navbar
.logo-title
.logo-subtitle
.nav-link
.nav-link-active
```

### Hero
```css
.hero-section-premium
.hero-logo
.hero-title-premium
.hero-subtitle-premium
.hero-stats
.stat-number
.stat-label
```

### Filtres
```css
.filter-container-premium
.filter-title
.filter-label-premium
.filter-input-premium
.filter-combo-premium
.prix-slider-premium
.prix-max-label-premium
```

### Cartes
```css
.hebergement-card
.hebergement-type-badge
.hebergement-nom
.hebergement-prix
.btn-reserver
```

### Footer
```css
.footer-premium
.footer-logo-text
.footer-text
.footer-link
```

## 📊 Comparaison Avant/Après

### Avant
- Design basique
- Pas de logo visible
- Hero simple
- Filtres standards
- Cartes 380px
- Pas de footer

### Après
- Design ultra premium
- Logo partout (navbar, hero, footer)
- Hero avec stats et gradient riche
- Filtres dans container stylisé
- Cartes 400px avec effets spectaculaires
- Footer professionnel complet

## 🔧 Personnalisation

### Changer les Couleurs
Modifiez les variables dans `.root`:
```css
.root {
    -fx-primary-orange: #VOTRE_COULEUR;
    -fx-primary-teal: #VOTRE_COULEUR;
    -fx-primary-beige: #VOTRE_COULEUR;
}
```

### Ajuster les Tailles
```css
/* Cartes plus grandes */
.hebergement-card {
    -fx-pref-width: 450px;
}

/* Hero plus haut */
.hero-section-premium {
    -fx-padding: 100 70;
}
```

### Modifier les Effets
```css
/* Hover plus prononcé */
.hebergement-card:hover {
    -fx-translate-y: -15px;
    -fx-scale-x: 1.05;
    -fx-scale-y: 1.05;
}
```

## 🎯 Conseils d'Utilisation

1. **Logo de Qualité**
   - Utilisez un PNG transparent
   - Résolution minimum: 200x200px
   - Optimisez la taille du fichier

2. **Images Hébergements**
   - Format: JPG ou PNG
   - Dimensions: 800x560px minimum
   - Compression optimisée

3. **Performance**
   - Les effets sont optimisés
   - Pas de lag sur hover
   - Transitions fluides

4. **Responsive**
   - Design adapté aux grandes fenêtres
   - Minimum recommandé: 1280x720px

## 📝 Notes Importantes

- Le FXML utilise `@../logo.png` pour le chemin du logo
- Les effets CSS sont compatibles JavaFX 17+
- Tous les gradients sont optimisés
- Les ombres utilisent gaussian blur

## 🚀 Prochaines Étapes

1. ✅ Tester l'affichage du logo
2. ✅ Vérifier les hover effects
3. ✅ Tester la navigation
4. ✅ Valider les filtres
5. ✅ Tester les réservations

---

**Version**: 2.0 Ultra Premium  
**Date**: 18 février 2026  
**Statut**: ✅ Production Ready
