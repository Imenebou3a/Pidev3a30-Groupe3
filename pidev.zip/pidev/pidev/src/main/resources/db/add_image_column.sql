-- Migration: Ajouter la colonne image_path à la table hebergement
-- Exécutez ce script dans votre base MySQL avant d'utiliser l'upload d'images

USE pidev;

ALTER TABLE hebergement
ADD COLUMN image_path VARCHAR(500) DEFAULT '' AFTER prix;
