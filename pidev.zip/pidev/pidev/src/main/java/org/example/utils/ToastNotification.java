package org.example.utils;

import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.animation.SequentialTransition;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

/**
 * Notifications toast style Android/Material Design
 */
public class ToastNotification {
    
    /**
     * Affiche une notification toast
     */
    public static void show(String message, Stage ownerStage) {
        show(message, ownerStage, 2000, ToastType.INFO);
    }
    
    /**
     * Affiche une notification toast avec durée personnalisée
     */
    public static void show(String message, Stage ownerStage, int durationMs, ToastType type) {
        Stage toastStage = new Stage();
        toastStage.initOwner(ownerStage);
        toastStage.initStyle(StageStyle.TRANSPARENT);
        
        Label label = new Label(message);
        label.setStyle(getStyleForType(type));
        
        StackPane root = new StackPane(label);
        root.setStyle("-fx-background-color: transparent;");
        root.setAlignment(Pos.BOTTOM_CENTER);
        
        Scene scene = new Scene(root);
        scene.setFill(javafx.scene.paint.Color.TRANSPARENT);
        toastStage.setScene(scene);
        
        // Position au bas de la fenêtre principale
        toastStage.setX(ownerStage.getX() + ownerStage.getWidth() / 2 - 150);
        toastStage.setY(ownerStage.getY() + ownerStage.getHeight() - 100);
        
        toastStage.show();
        
        // Animation: fade in -> pause -> fade out
        FadeTransition fadeIn = new FadeTransition(Duration.millis(300), root);
        fadeIn.setFromValue(0.0);
        fadeIn.setToValue(1.0);
        
        PauseTransition pause = new PauseTransition(Duration.millis(durationMs));
        
        FadeTransition fadeOut = new FadeTransition(Duration.millis(300), root);
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);
        fadeOut.setOnFinished(e -> toastStage.close());
        
        SequentialTransition animation = new SequentialTransition(fadeIn, pause, fadeOut);
        animation.play();
    }
    
    private static String getStyleForType(ToastType type) {
        String baseStyle = "-fx-background-color: %s; " +
                          "-fx-text-fill: white; " +
                          "-fx-padding: 15px 30px; " +
                          "-fx-background-radius: 25px; " +
                          "-fx-font-size: 14px; " +
                          "-fx-font-weight: bold; " +
                          "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 10, 0, 0, 2);";
        
        return switch (type) {
            case SUCCESS -> String.format(baseStyle, "#16A085");
            case ERROR -> String.format(baseStyle, "#E74C3C");
            case WARNING -> String.format(baseStyle, "#F39C12");
            case INFO -> String.format(baseStyle, "#3498DB");
        };
    }
    
    public enum ToastType {
        SUCCESS, ERROR, WARNING, INFO
    }
    
    private ToastNotification() {
        // Empêcher l'instanciation
    }
}
