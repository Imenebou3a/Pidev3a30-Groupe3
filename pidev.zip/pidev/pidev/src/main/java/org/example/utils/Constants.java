package org.example.utils;

/**
 * Classe contenant toutes les constantes de l'application
 */
public class Constants {
    
    // Database
    public static final String DB_URL = "jdbc:mysql://localhost:3306/lammetna";
    public static final String DB_USER = "root";
    public static final String DB_PASSWORD = "";
    
    // Validation
    public static final int MIN_PRICE = 0;
    public static final int MAX_PRICE = 10000;
    public static final int MIN_PERSONS = 1;
    public static final int MAX_PERSONS = 20;
    public static final int MIN_NIGHTS = 1;
    
    // File paths
    public static final String UPLOAD_DIR = "uploads/hebergements/";
    public static final String LOGO_PATH = "/logo.png";
    
    // UI
    public static final String APP_TITLE = "Lammetna - Gestion des Hébergements";
    public static final int WINDOW_WIDTH = 1400;
    public static final int WINDOW_HEIGHT = 800;
    
    // Messages
    public static final String SUCCESS_ADD = "Ajouté avec succès!";
    public static final String SUCCESS_UPDATE = "Modifié avec succès!";
    public static final String SUCCESS_DELETE = "Supprimé avec succès!";
    public static final String ERROR_EMPTY_FIELDS = "Veuillez remplir tous les champs obligatoires";
    public static final String ERROR_INVALID_PRICE = "Prix invalide";
    public static final String ERROR_INVALID_DATE = "Dates invalides";
    public static final String ERROR_NOT_AVAILABLE = "Hébergement non disponible pour ces dates";
    
    private Constants() {
        // Empêcher l'instanciation
    }
}
