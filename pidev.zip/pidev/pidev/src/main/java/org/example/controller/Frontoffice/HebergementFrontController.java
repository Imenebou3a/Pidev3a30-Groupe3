package org.example.controller.Frontoffice;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.shape.Rectangle;
import java.io.File;
import org.example.entities.Hebergement;
import org.example.entities.Reservation;
import org.example.services.HebergementService;
import org.example.services.ReservationService;

import java.sql.Date;
import java.time.LocalDate;

public class HebergementFrontController {

    @FXML
    private TextField txtRecherche;
    @FXML
    private ComboBox<String> comboType;
    @FXML
    private Slider sliderPrix;
    @FXML
    private Label lblPrixMax;
    @FXML
    private FlowPane hebergementsContainer;

    private HebergementService hebergementService;
    private ReservationService reservationService;
    private ObservableList<Hebergement> hebergementList;

    @FXML
    public void initialize() {
        hebergementService = new HebergementService();
        reservationService = new ReservationService();
        hebergementList = FXCollections.observableArrayList();

        // Configuration du slider prix
        sliderPrix.setMin(0);
        sliderPrix.setMax(1000);
        sliderPrix.setValue(1000);
        lblPrixMax.setText("1000 DT");

        sliderPrix.valueProperty().addListener((obs, oldVal, newVal) -> {
            lblPrixMax.setText(String.format("%.0f DT", newVal));
            filtrerHebergements();
        });

        // Configuration du ComboBox type
        comboType.getItems().addAll("Tous", "Villa", "Appartement", "Maison d'hôtes", "Studio", "Riad");
        comboType.setValue("Tous");
        comboType.setOnAction(e -> filtrerHebergements());

        // Listener recherche
        txtRecherche.textProperty().addListener((obs, oldVal, newVal) -> filtrerHebergements());

        // Charger les hébergements
        chargerHebergements();
    }

    private void chargerHebergements() {
        hebergementList.clear();
        hebergementList.addAll(hebergementService.afficherHebergements());
        afficherCartes(hebergementList);
    }

    private void filtrerHebergements() {
        ObservableList<Hebergement> filtered = FXCollections.observableArrayList();
        String recherche = txtRecherche.getText().toLowerCase();
        String typeSelectionne = comboType.getValue();
        double prixMax = sliderPrix.getValue();

        for (Hebergement h : hebergementList) {
            boolean matchRecherche = recherche.isEmpty() ||
                    h.getNom().toLowerCase().contains(recherche) ||
                    h.getAdresse().toLowerCase().contains(recherche);

            boolean matchType = typeSelectionne.equals("Tous") ||
                    h.getType().equals(typeSelectionne);

            boolean matchPrix = Double.parseDouble(h.getPrix()) <= prixMax;

            if (matchRecherche && matchType && matchPrix) {
                filtered.add(h);
            }
        }

        afficherCartes(filtered);
    }

    private void afficherCartes(ObservableList<Hebergement> hebergements) {
        hebergementsContainer.getChildren().clear();

        for (Hebergement h : hebergements) {
            VBox carte = creerCarteHebergement(h);
            hebergementsContainer.getChildren().add(carte);
        }

        if (hebergements.isEmpty()) {
            Label noResult = new Label("😕 Aucun hébergement trouvé");
            noResult.setStyle("-fx-font-size: 24px; -fx-text-fill: #64748b; -fx-padding: 80px; -fx-font-weight: bold;");
            hebergementsContainer.getChildren().add(noResult);
        }
    }

    private void afficherPlaceholderImage(VBox imageBox) {
        imageBox.setStyle("-fx-background-color: linear-gradient(135deg, #0B7A8F 0%, #14b8a6 100%); " +
                "-fx-background-radius: 18 18 0 0;");
        Label iconLabel = new Label("🏡");
        iconLabel.setStyle("-fx-font-size: 72px; -fx-text-fill: white;");
        imageBox.setAlignment(Pos.CENTER);
        imageBox.getChildren().add(iconLabel);
    }

    private VBox creerCarteHebergement(Hebergement h) {
        VBox carte = new VBox(15);
        carte.getStyleClass().add("hebergement-card");
        carte.setPrefWidth(380);
        carte.setPadding(new Insets(0));

        // Zone image : image réelle si disponible, sinon placeholder
        VBox imageBox = new VBox();
        imageBox.setPrefHeight(240);
        imageBox.setPrefWidth(380);
        imageBox.setStyle("-fx-background-radius: 18 18 0 0; -fx-background-color: #e2e8f0;");

        String imagePath = h.getImagePath();
        if (imagePath != null && !imagePath.trim().isEmpty()) {
            File imgFile = new File(imagePath);
            if (imgFile.exists()) {
                try {
                    ImageView imageView = new ImageView(new Image(imgFile.toURI().toString()));
                    imageView.setFitWidth(380);
                    imageView.setFitHeight(240);
                    imageView.setPreserveRatio(true);
                    Rectangle clip = new Rectangle(380, 240);
                    clip.setArcWidth(36);
                    clip.setArcHeight(36);
                    imageView.setClip(clip);
                    imageBox.getChildren().add(imageView);
                } catch (Exception e) {
                    afficherPlaceholderImage(imageBox);
                }
            } else {
                afficherPlaceholderImage(imageBox);
            }
        } else {
            afficherPlaceholderImage(imageBox);
        }

        // Contenu
        VBox content = new VBox(12);
        content.setPadding(new Insets(25));
        content.getStyleClass().add("hebergement-content");

        // Type badge
        Label typeBadge = new Label(h.getType());
        typeBadge.getStyleClass().add("hebergement-type-badge");

        // Nom
        Label nomLabel = new Label(h.getNom());
        nomLabel.getStyleClass().add("hebergement-nom");
        nomLabel.setWrapText(true);

        // Adresse
        HBox adresseBox = new HBox(8);
        adresseBox.setAlignment(javafx.geometry.Pos.CENTER_LEFT);
        Label iconAdresse = new Label("📍");
        iconAdresse.getStyleClass().add("hebergement-adresse-icon");
        Label adresseLabel = new Label(h.getAdresse());
        adresseLabel.getStyleClass().add("hebergement-adresse-text");
        adresseLabel.setWrapText(true);
        adresseBox.getChildren().addAll(iconAdresse, adresseLabel);

        // Prix
        HBox prixBox = new HBox(8);
        prixBox.setAlignment(javafx.geometry.Pos.CENTER_LEFT);
        Label prixLabel = new Label(h.getPrix() + " DT");
        prixLabel.getStyleClass().add("hebergement-prix");
        Label perNight = new Label("/ nuit");
        perNight.getStyleClass().add("hebergement-prix-unit");
        prixBox.getChildren().addAll(prixLabel, perNight);

        // Bouton réserver
        Button btnReserver = new Button("🏖️ Réserver maintenant");
        btnReserver.getStyleClass().add("btn-reserver");
        btnReserver.setMaxWidth(Double.MAX_VALUE);
        btnReserver.setOnAction(e -> ouvrirDialogueReservation(h));

        content.getChildren().addAll(typeBadge, nomLabel, adresseBox, prixBox, btnReserver);
        carte.getChildren().addAll(imageBox, content);

        return carte;
    }

    private void ouvrirDialogueReservation(Hebergement hebergement) {
        Dialog<Reservation> dialog = new Dialog<>();
        dialog.setTitle("Réserver - " + hebergement.getNom());
        dialog.setHeaderText("🏝️ Réservation pour " + hebergement.getNom());

        // Boutons
        ButtonType btnConfirmer = new ButtonType("Confirmer la réservation", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(btnConfirmer, ButtonType.CANCEL);

        // Formulaire
        GridPane grid = new GridPane();
        grid.setHgap(20);
        grid.setVgap(18);
        grid.setPadding(new Insets(25));
        grid.setStyle("-fx-background-color: white;");

        // Info hébergement
        VBox infoBox = new VBox(8);
        infoBox.setStyle("-fx-background-color: #f8fafc; -fx-padding: 18px; -fx-background-radius: 10px; " +
                "-fx-border-color: #e2e8f0; -fx-border-width: 2px; -fx-border-radius: 10px;");
        Label lblType = new Label("📍 " + hebergement.getType() + " - " + hebergement.getAdresse());
        lblType.setStyle("-fx-font-size: 14px; -fx-text-fill: #64748b;");
        Label lblPrix = new Label("💰 " + hebergement.getPrix() + " DT/nuit");
        lblPrix.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #D2691E;");
        infoBox.getChildren().addAll(lblType, lblPrix);

        // Labels pour les dates
        Label lblDateDebut = new Label("📅 Date d'arrivée *");
        lblDateDebut.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");
        DatePicker dateDebut = new DatePicker(LocalDate.now());
        dateDebut.setStyle("-fx-pref-width: 280px; -fx-pref-height: 45px; -fx-font-size: 14px;");
        Label lblErreurDateDebut = new Label();
        lblErreurDateDebut.setStyle("-fx-text-fill: #ef4444; -fx-font-size: 12px;");
        lblErreurDateDebut.setManaged(false);
        lblErreurDateDebut.setVisible(false);

        Label lblDateFin = new Label("📅 Date de départ *");
        lblDateFin.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");
        DatePicker dateFin = new DatePicker(LocalDate.now().plusDays(1));
        dateFin.setStyle("-fx-pref-width: 280px; -fx-pref-height: 45px; -fx-font-size: 14px;");
        Label lblErreurDateFin = new Label();
        lblErreurDateFin.setStyle("-fx-text-fill: #ef4444; -fx-font-size: 12px;");
        lblErreurDateFin.setManaged(false);
        lblErreurDateFin.setVisible(false);

        Label lblPersonnes = new Label("👥 Nombre de personnes *");
        lblPersonnes.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");
        Spinner<Integer> spinnerPersonnes = new Spinner<>(1, 20, 2);
        spinnerPersonnes.setStyle("-fx-pref-width: 280px; -fx-pref-height: 45px;");
        spinnerPersonnes.setEditable(true);
        Label lblErreurPersonnes = new Label();
        lblErreurPersonnes.setStyle("-fx-text-fill: #ef4444; -fx-font-size: 12px;");
        lblErreurPersonnes.setManaged(false);
        lblErreurPersonnes.setVisible(false);

        Label lblTotal = new Label("Total: 0 DT");
        lblTotal.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; -fx-text-fill: #0B7A8F;");

        Label lblDisponibilite = new Label();
        lblDisponibilite.setStyle("-fx-font-size: 13px; -fx-padding: 10px; -fx-background-radius: 8px;");
        lblDisponibilite.setManaged(false);
        lblDisponibilite.setVisible(false);

        // VALIDATION EN TEMPS RÉEL - Date Début
        dateDebut.setOnAction(e -> {
            LocalDate debut = dateDebut.getValue();
            LocalDate maintenant = LocalDate.now();

            if (debut == null) {
                afficherErreur(lblErreurDateDebut, "⚠️ Sélectionnez une date d'arrivée");
                dateDebut.setStyle("-fx-border-color: #ef4444; -fx-border-width: 2px; -fx-pref-width: 280px; -fx-pref-height: 45px;");
            } else if (debut.isBefore(maintenant)) {
                afficherErreur(lblErreurDateDebut, "❌ La date ne peut pas être dans le passé");
                dateDebut.setStyle("-fx-border-color: #ef4444; -fx-border-width: 2px; -fx-pref-width: 280px; -fx-pref-height: 45px;");
            } else {
                cacherErreur(lblErreurDateDebut);
                dateDebut.setStyle("-fx-border-color: #10b981; -fx-border-width: 2px; -fx-pref-width: 280px; -fx-pref-height: 45px;");
                validerDates(dateDebut, dateFin, lblErreurDateFin);
                calculerPrixTotal(hebergement, dateDebut, dateFin, lblTotal);
                verifierDisponibilite(hebergement, dateDebut, dateFin, lblDisponibilite);
            }
        });

        // VALIDATION EN TEMPS RÉEL - Date Fin
        dateFin.setOnAction(e -> {
            validerDates(dateDebut, dateFin, lblErreurDateFin);
            calculerPrixTotal(hebergement, dateDebut, dateFin, lblTotal);
            verifierDisponibilite(hebergement, dateDebut, dateFin, lblDisponibilite);
        });

        // VALIDATION EN TEMPS RÉEL - Nombre de personnes
        spinnerPersonnes.valueProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal == null || newVal < 1) {
                afficherErreur(lblErreurPersonnes, "⚠️ Minimum 1 personne");
                spinnerPersonnes.setStyle("-fx-border-color: #ef4444; -fx-border-width: 2px;");
            } else if (newVal > 20) {
                afficherErreur(lblErreurPersonnes, "⚠️ Maximum 20 personnes");
                spinnerPersonnes.setStyle("-fx-border-color: #f59e0b; -fx-border-width: 2px;");
            } else {
                cacherErreur(lblErreurPersonnes);
                spinnerPersonnes.setStyle("-fx-border-color: #10b981; -fx-border-width: 2px;");
            }
        });

        // Construction du grid
        int row = 0;
        grid.add(infoBox, 0, row++, 2, 1);

        grid.add(lblDateDebut, 0, row, 2, 1);
        grid.add(dateDebut, 0, ++row, 2, 1);
        grid.add(lblErreurDateDebut, 0, ++row, 2, 1);

        grid.add(lblDateFin, 0, ++row, 2, 1);
        grid.add(dateFin, 0, ++row, 2, 1);
        grid.add(lblErreurDateFin, 0, ++row, 2, 1);

        grid.add(lblPersonnes, 0, ++row, 2, 1);
        grid.add(spinnerPersonnes, 0, ++row, 2, 1);
        grid.add(lblErreurPersonnes, 0, ++row, 2, 1);

        grid.add(new Separator(), 0, ++row, 2, 1);
        grid.add(lblDisponibilite, 0, ++row, 2, 1);
        grid.add(lblTotal, 0, ++row, 2, 1);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().setStyle("-fx-background-color: white;");

        // Validation finale à la soumission
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == btnConfirmer) {
                // Validation complète
                LocalDate debut = dateDebut.getValue();
                LocalDate fin = dateFin.getValue();
                Integer personnes = spinnerPersonnes.getValue();

                if (debut == null) {
                    afficherAlert("Erreur de validation", "⚠️ Veuillez sélectionner une date d'arrivée!", Alert.AlertType.ERROR);
                    return null;
                }

                if (fin == null) {
                    afficherAlert("Erreur de validation", "⚠️ Veuillez sélectionner une date de départ!", Alert.AlertType.ERROR);
                    return null;
                }

                if (debut.isBefore(LocalDate.now())) {
                    afficherAlert("Date invalide", "❌ La date d'arrivée ne peut pas être dans le passé!", Alert.AlertType.ERROR);
                    return null;
                }

                if (fin.isBefore(debut) || fin.isEqual(debut)) {
                    afficherAlert("Dates invalides", "❌ La date de départ doit être après la date d'arrivée!", Alert.AlertType.ERROR);
                    return null;
                }

                if (personnes == null || personnes < 1 || personnes > 20) {
                    afficherAlert("Nombre invalide", "⚠️ Le nombre de personnes doit être entre 1 et 20!", Alert.AlertType.ERROR);
                    return null;
                }

                // Vérifier disponibilité finale
                Date sqlDebut = Date.valueOf(debut);
                Date sqlFin = Date.valueOf(fin);

                if (!reservationService.verifierDisponibilite(hebergement.getId(), sqlDebut, sqlFin)) {
                    afficherAlert("Non disponible",
                            "😔 Désolé, cet hébergement n'est pas disponible pour ces dates.\n\n" +
                                    "Veuillez choisir d'autres dates.",
                            Alert.AlertType.WARNING);
                    return null;
                }

                return new Reservation(
                        hebergement.getId(),
                        sqlDebut,
                        sqlFin,
                        personnes
                );
            }
            return null;
        });

        // Initialiser le calcul
        calculerPrixTotal(hebergement, dateDebut, dateFin, lblTotal);

        dialog.showAndWait().ifPresent(reservation -> {
            reservationService.ajouterReservation(reservation);

            // Calculer les détails
            long nuits = java.time.temporal.ChronoUnit.DAYS.between(
                    reservation.getDateDebut().toLocalDate(),
                    reservation.getDateFin().toLocalDate());
            double total = nuits * Double.parseDouble(hebergement.getPrix());

            afficherAlert("Réservation confirmée! 🎉",
                    String.format(
                            "✅ Votre réservation a été confirmée avec succès!\n\n" +
                                    "📍 Hébergement: %s\n" +
                                    "🏠 Type: %s\n" +
                                    "📅 Du %s au %s\n" +
                                    "🌙 Durée: %d nuits\n" +
                                    "👥 Personnes: %d\n" +
                                    "💰 Total: %.2f DT\n\n" +
                                    "Nous avons hâte de vous accueillir! 🏝️",
                            hebergement.getNom(),
                            hebergement.getType(),
                            reservation.getDateDebut().toString(),
                            reservation.getDateFin().toString(),
                            nuits,
                            reservation.getNbPersonnes(),
                            total
                    ),
                    Alert.AlertType.INFORMATION);
        });
    }

    // MÉTHODES DE VALIDATION
    private void validerDates(DatePicker dateDebut, DatePicker dateFin, Label lblErreur) {
        LocalDate debut = dateDebut.getValue();
        LocalDate fin = dateFin.getValue();

        if (debut != null && fin != null) {
            if (fin.isBefore(debut)) {
                afficherErreur(lblErreur, "❌ La date de départ doit être après l'arrivée");
                dateFin.setStyle("-fx-border-color: #ef4444; -fx-border-width: 2px; -fx-pref-width: 280px; -fx-pref-height: 45px;");
            } else if (fin.isEqual(debut)) {
                afficherErreur(lblErreur, "⚠️ Minimum 1 nuit de séjour");
                dateFin.setStyle("-fx-border-color: #f59e0b; -fx-border-width: 2px; -fx-pref-width: 280px; -fx-pref-height: 45px;");
            } else {
                cacherErreur(lblErreur);
                dateFin.setStyle("-fx-border-color: #10b981; -fx-border-width: 2px; -fx-pref-width: 280px; -fx-pref-height: 45px;");
            }
        }
    }

    private void calculerPrixTotal(Hebergement hebergement, DatePicker dateDebut, DatePicker dateFin, Label lblTotal) {
        if (dateDebut.getValue() != null && dateFin.getValue() != null) {
            LocalDate debut = dateDebut.getValue();
            LocalDate fin = dateFin.getValue();

            if (fin.isAfter(debut)) {
                long nuits = java.time.temporal.ChronoUnit.DAYS.between(debut, fin);
                double prixNuit = Double.parseDouble(hebergement.getPrix());
                double total = nuits * prixNuit;

                lblTotal.setText(String.format("💳 Total: %.2f DT (%d nuits × %.2f DT)",
                        total, nuits, prixNuit));
                lblTotal.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; -fx-text-fill: #0B7A8F;");
            }
        }
    }

    private void verifierDisponibilite(Hebergement hebergement, DatePicker dateDebut, DatePicker dateFin, Label lblDisponibilite) {
        if (dateDebut.getValue() != null && dateFin.getValue() != null) {
            LocalDate debut = dateDebut.getValue();
            LocalDate fin = dateFin.getValue();

            if (fin.isAfter(debut) && !debut.isBefore(LocalDate.now())) {
                Date sqlDebut = Date.valueOf(debut);
                Date sqlFin = Date.valueOf(fin);

                boolean disponible = reservationService.verifierDisponibilite(hebergement.getId(), sqlDebut, sqlFin);

                if (disponible) {
                    lblDisponibilite.setText("✅ Hébergement disponible pour ces dates");
                    lblDisponibilite.setStyle("-fx-font-size: 14px; -fx-padding: 12px; -fx-background-radius: 8px; " +
                            "-fx-background-color: #d1fae5; -fx-text-fill: #065f46; -fx-font-weight: bold;");
                } else {
                    lblDisponibilite.setText("❌ Hébergement non disponible pour ces dates");
                    lblDisponibilite.setStyle("-fx-font-size: 14px; -fx-padding: 12px; -fx-background-radius: 8px; " +
                            "-fx-background-color: #fee2e2; -fx-text-fill: #991b1b; -fx-font-weight: bold;");
                }
                lblDisponibilite.setManaged(true);
                lblDisponibilite.setVisible(true);
            }
        }
    }

    private void afficherErreur(Label label, String message) {
        if (label != null) {
            label.setText(message);
            label.setManaged(true);
            label.setVisible(true);
        }
    }

    private void cacherErreur(Label label) {
        if (label != null) {
            label.setManaged(false);
            label.setVisible(false);
        }
    }

    private void afficherAlert(String titre, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(titre);
        alert.setHeaderText(null);
        alert.setContentText(message);

        DialogPane dialogPane = alert.getDialogPane();
        dialogPane.setStyle("-fx-background-color: white;");

        alert.showAndWait();
    }
}