package org.example.services;

import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;
import org.example.entities.Hebergement;
import org.example.entities.Reservation;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class PdfService {

    // Couleurs Lammetna
    private static final DeviceRgb ORANGE = new DeviceRgb(230, 126, 34);
    private static final DeviceRgb TEAL = new DeviceRgb(22, 160, 133);
    private static final DeviceRgb BEIGE = new DeviceRgb(245, 230, 211);

    /**
     * Génère un PDF de la liste des hébergements
     */
    public String genererPdfHebergements(List<Hebergement> hebergements) {
        try {
            // Créer le dossier exports s'il n'existe pas
            File exportsDir = new File("exports");
            if (!exportsDir.exists()) {
                exportsDir.mkdirs();
            }

            // Nom du fichier avec timestamp
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            String fileName = "exports/hebergements_" + timestamp + ".pdf";

            // Créer le document PDF
            PdfWriter writer = new PdfWriter(fileName);
            PdfDocument pdf = new PdfDocument(writer);
            Document document = new Document(pdf);

            // En-tête
            Paragraph header = new Paragraph("LAMMETNA")
                    .setFontSize(28)
                    .setBold()
                    .setFontColor(TEAL)
                    .setTextAlignment(TextAlignment.CENTER);
            document.add(header);

            Paragraph subtitle = new Paragraph("Liste des Hébergements")
                    .setFontSize(18)
                    .setFontColor(ORANGE)
                    .setTextAlignment(TextAlignment.CENTER)
                    .setMarginBottom(10);
            document.add(subtitle);

            Paragraph date = new Paragraph("Généré le: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")))
                    .setFontSize(10)
                    .setTextAlignment(TextAlignment.CENTER)
                    .setMarginBottom(20);
            document.add(date);

            // Statistiques rapides
            Paragraph stats = new Paragraph("Total: " + hebergements.size() + " hébergements")
                    .setFontSize(12)
                    .setBold()
                    .setMarginBottom(15);
            document.add(stats);

            // Tableau
            float[] columnWidths = {1, 3, 2, 3, 2};
            Table table = new Table(UnitValue.createPercentArray(columnWidths));
            table.setWidth(UnitValue.createPercentValue(100));

            // En-têtes du tableau
            String[] headers = {"ID", "Nom", "Type", "Adresse", "Prix (DT/nuit)"};
            for (String headerText : headers) {
                Cell headerCell = new Cell()
                        .add(new Paragraph(headerText).setBold())
                        .setBackgroundColor(TEAL)
                        .setFontColor(ColorConstants.WHITE)
                        .setTextAlignment(TextAlignment.CENTER)
                        .setPadding(8);
                table.addHeaderCell(headerCell);
            }

            // Données
            for (Hebergement h : hebergements) {
                table.addCell(new Cell().add(new Paragraph(String.valueOf(h.getId()))).setPadding(5));
                table.addCell(new Cell().add(new Paragraph(h.getNom())).setPadding(5));
                table.addCell(new Cell().add(new Paragraph(h.getType())).setPadding(5));
                table.addCell(new Cell().add(new Paragraph(h.getAdresse())).setPadding(5));
                table.addCell(new Cell().add(new Paragraph(h.getPrix())).setPadding(5).setTextAlignment(TextAlignment.RIGHT));
            }

            document.add(table);

            // Pied de page
            Paragraph footer = new Paragraph("\n© 2024 Lammetna - Tous droits réservés")
                    .setFontSize(8)
                    .setTextAlignment(TextAlignment.CENTER)
                    .setMarginTop(20);
            document.add(footer);

            document.close();

            return fileName;
        } catch (Exception e) {
            System.err.println("Erreur lors de la génération du PDF: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Génère un PDF de la liste des réservations
     */
    public String genererPdfReservations(List<Reservation> reservations, HebergementService hebergementService) {
        try {
            File exportsDir = new File("exports");
            if (!exportsDir.exists()) {
                exportsDir.mkdirs();
            }

            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            String fileName = "exports/reservations_" + timestamp + ".pdf";

            PdfWriter writer = new PdfWriter(fileName);
            PdfDocument pdf = new PdfDocument(writer);
            Document document = new Document(pdf);

            // En-tête
            Paragraph header = new Paragraph("LAMMETNA")
                    .setFontSize(28)
                    .setBold()
                    .setFontColor(TEAL)
                    .setTextAlignment(TextAlignment.CENTER);
            document.add(header);

            Paragraph subtitle = new Paragraph("Liste des Réservations")
                    .setFontSize(18)
                    .setFontColor(ORANGE)
                    .setTextAlignment(TextAlignment.CENTER)
                    .setMarginBottom(10);
            document.add(subtitle);

            Paragraph date = new Paragraph("Généré le: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")))
                    .setFontSize(10)
                    .setTextAlignment(TextAlignment.CENTER)
                    .setMarginBottom(20);
            document.add(date);

            // Statistiques
            Paragraph stats = new Paragraph("Total: " + reservations.size() + " réservations")
                    .setFontSize(12)
                    .setBold()
                    .setMarginBottom(15);
            document.add(stats);

            // Tableau
            float[] columnWidths = {1, 3, 2, 2, 2};
            Table table = new Table(UnitValue.createPercentArray(columnWidths));
            table.setWidth(UnitValue.createPercentValue(100));

            // En-têtes
            String[] headers = {"ID", "Hébergement", "Date Début", "Date Fin", "Personnes"};
            for (String headerText : headers) {
                Cell headerCell = new Cell()
                        .add(new Paragraph(headerText).setBold())
                        .setBackgroundColor(TEAL)
                        .setFontColor(ColorConstants.WHITE)
                        .setTextAlignment(TextAlignment.CENTER)
                        .setPadding(8);
                table.addHeaderCell(headerCell);
            }

            // Données
            for (Reservation r : reservations) {
                Hebergement h = hebergementService.getHebergementById(r.getIdHebergement());
                String nomHeb = h != null ? h.getNom() : "ID: " + r.getIdHebergement();

                table.addCell(new Cell().add(new Paragraph(String.valueOf(r.getId()))).setPadding(5));
                table.addCell(new Cell().add(new Paragraph(nomHeb)).setPadding(5));
                table.addCell(new Cell().add(new Paragraph(r.getDateDebut().toString())).setPadding(5));
                table.addCell(new Cell().add(new Paragraph(r.getDateFin().toString())).setPadding(5));
                table.addCell(new Cell().add(new Paragraph(String.valueOf(r.getNbPersonnes()))).setPadding(5).setTextAlignment(TextAlignment.CENTER));
            }

            document.add(table);

            // Pied de page
            Paragraph footer = new Paragraph("\n© 2024 Lammetna - Tous droits réservés")
                    .setFontSize(8)
                    .setTextAlignment(TextAlignment.CENTER)
                    .setMarginTop(20);
            document.add(footer);

            document.close();

            return fileName;
        } catch (Exception e) {
            System.err.println("Erreur lors de la génération du PDF: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
}
