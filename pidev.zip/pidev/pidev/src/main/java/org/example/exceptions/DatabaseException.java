package org.example.exceptions;

/**
 * Exception personnalisée pour les erreurs de base de données
 */
public class DatabaseException extends RuntimeException {
    
    public DatabaseException(String message) {
        super(message);
    }
    
    public DatabaseException(String message, Throwable cause) {
        super(message, cause);
    }
}
