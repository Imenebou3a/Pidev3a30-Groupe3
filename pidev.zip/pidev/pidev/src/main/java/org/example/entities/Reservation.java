package org.example.entities;

import java.sql.Date;

public class Reservation {
    private int id;
    private int idHebergement;
    private Date dateDebut;
    private Date dateFin;
    private int nbPersonnes;

    // Constructeur vide
    public Reservation() {
    }

    // Constructeur sans id (pour l'ajout)
    public Reservation(int idHebergement, Date dateDebut, Date dateFin, int nbPersonnes) {
        this.idHebergement = idHebergement;
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
        this.nbPersonnes = nbPersonnes;
    }

    // Constructeur complet (avec id pour la modification)
    public Reservation(int id, int idHebergement, Date dateDebut, Date dateFin, int nbPersonnes) {
        this.id = id;
        this.idHebergement = idHebergement;
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
        this.nbPersonnes = nbPersonnes;
    }

    // Getters et Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdHebergement() {
        return idHebergement;
    }

    public void setIdHebergement(int idHebergement) {
        this.idHebergement = idHebergement;
    }

    public Date getDateDebut() {
        return dateDebut;
    }

    public void setDateDebut(Date dateDebut) {
        this.dateDebut = dateDebut;
    }

    public Date getDateFin() {
        return dateFin;
    }

    public void setDateFin(Date dateFin) {
        this.dateFin = dateFin;
    }

    public int getNbPersonnes() {
        return nbPersonnes;
    }

    public void setNbPersonnes(int nbPersonnes) {
        this.nbPersonnes = nbPersonnes;
    }

    @Override
    public String toString() {
        return "Reservation{" +
                "id=" + id +
                ", idHebergement=" + idHebergement +
                ", dateDebut=" + dateDebut +
                ", dateFin=" + dateFin +
                ", nbPersonnes=" + nbPersonnes +
                '}';
    }
}