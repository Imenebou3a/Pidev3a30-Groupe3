package org.example;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;

/**
 * APPLICATION FRONT-OFFICE (CLIENT)
 * Accès: Parcourir hébergements et Réserver uniquement
 * Rôle: Interface client pour les utilisateurs finaux
 */
public class FrontOfficeApp extends Application {

    private BorderPane root;
    private VBox sidebar;

    @Override
    public void start(Stage primaryStage) {
        root = new BorderPane();
        
        // Créer sidebar Front-Office
        createFrontOfficeSidebar();
        root.setLeft(sidebar);
        
        // Charger directement l'espace client
        showFrontOffice();
        
        Scene scene = new Scene(root, 1400, 800);
        
        // Charger CSS
        try {
            String mainCss = getClass().getResource("/styles/main-theme.css").toExternalForm();
            scene.getStylesheets().add(mainCss);
        } catch (Exception e) {
            System.err.println("CSS non chargé: " + e.getMessage());
        }
        
        primaryStage.setTitle("Lammetna - Réservez votre hébergement");
        primaryStage.setScene(scene);
        primaryStage.setMaximized(true);
        primaryStage.show();
        
        System.out.println("✅ Front-Office lancé avec succès!");
    }
    
    private void createFrontOfficeSidebar() {
        sidebar = new VBox(15);
        sidebar.setPadding(new Insets(20));
        sidebar.setPrefWidth(280);
        // Couleur différente pour Front-Office
        sidebar.setStyle("-fx-background-color: linear-gradient(to bottom, #3498DB, #2980B9);");
        
        // Header
        VBox header = new VBox(10);
        header.setAlignment(Pos.CENTER);
        header.setPadding(new Insets(20, 0, 30, 0));
        
        Label logo = new Label("🏖️");
        logo.setStyle("-fx-font-size: 64px;");
        
        Label appName = new Label("LAMMETNA");
        appName.setStyle("-fx-text-fill: white; -fx-font-size: 32px; -fx-font-weight: bold;");
        
        Label tagline = new Label("FRONT-OFFICE");
        tagline.setStyle("-fx-text-fill: #F4D03F; -fx-font-size: 14px; -fx-font-weight: bold; -fx-letter-spacing: 2px;");
        
        Label role = new Label("👤 Espace Client");
        role.setStyle("-fx-text-fill: rgba(255,255,255,0.8); -fx-font-size: 12px;");
        
        header.getChildren().addAll(logo, appName, tagline, role);
        
        // Welcome message
        VBox welcomeBox = new VBox(10);
        welcomeBox.setPadding(new Insets(20, 15, 20, 15));
        welcomeBox.setStyle("-fx-background-color: rgba(255,255,255,0.15); -fx-background-radius: 10;");
        
        Label welcomeTitle = new Label("👋 Bienvenue!");
        welcomeTitle.setStyle("-fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold;");
        
        Label welcomeText = new Label("Découvrez nos hébergements et réservez en quelques clics.");
        welcomeText.setWrapText(true);
        welcomeText.setStyle("-fx-text-fill: rgba(255,255,255,0.95); -fx-font-size: 12px;");
        
        welcomeBox.getChildren().addAll(welcomeTitle, welcomeText);
        
        // Features
        VBox featuresBox = new VBox(12);
        featuresBox.setPadding(new Insets(20, 15, 20, 15));
        featuresBox.setStyle("-fx-background-color: rgba(0,0,0,0.15); -fx-background-radius: 10;");
        
        Label featuresTitle = new Label("✨ Fonctionnalités");
        featuresTitle.setStyle("-fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold;");
        
        Label feature1 = new Label("🏡 Parcourir les hébergements");
        feature1.setStyle("-fx-text-fill: rgba(255,255,255,0.9); -fx-font-size: 11px;");
        
        Label feature2 = new Label("📅 Réserver en ligne");
        feature2.setStyle("-fx-text-fill: rgba(255,255,255,0.9); -fx-font-size: 11px;");
        
        Label feature3 = new Label("💰 Prix transparents");
        feature3.setStyle("-fx-text-fill: rgba(255,255,255,0.9); -fx-font-size: 11px;");
        
        Label feature4 = new Label("⭐ Hébergements vérifiés");
        feature4.setStyle("-fx-text-fill: rgba(255,255,255,0.9); -fx-font-size: 11px;");
        
        featuresBox.getChildren().addAll(featuresTitle, feature1, feature2, feature3, feature4);
        
        // Footer
        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);
        
        VBox footer = new VBox(5);
        footer.setAlignment(Pos.CENTER);
        footer.setPadding(new Insets(20, 0, 0, 0));
        Label copyright = new Label("© 2026 Lammetna");
        copyright.setStyle("-fx-text-fill: rgba(255,255,255,0.7); -fx-font-size: 11px;");
        Label version = new Label("Front-Office v1.0");
        version.setStyle("-fx-text-fill: rgba(255,255,255,0.7); -fx-font-size: 11px;");
        footer.getChildren().addAll(copyright, version);
        
        // Bouton pour ouvrir Back-Office dans nouvelle fenêtre (si admin)
        Button btnOpenBack = new Button();
        btnOpenBack.setMaxWidth(Double.MAX_VALUE);
        btnOpenBack.setStyle("-fx-background-color: rgba(22,160,133,0.2); -fx-text-fill: white; " +
                    "-fx-font-size: 14px; -fx-padding: 14 20; -fx-alignment: center; " +
                    "-fx-border-width: 2; -fx-border-color: #16A085; -fx-border-radius: 8; -fx-background-radius: 8;");
        
        HBox openBackContent = new HBox(10);
        openBackContent.setAlignment(Pos.CENTER);
        Label openBackIcon = new Label("👨‍💼");
        openBackIcon.setStyle("-fx-font-size: 20px;");
        Label openBackText = new Label("Ouvrir Back-Office");
        openBackText.setStyle("-fx-font-size: 13px; -fx-font-weight: bold;");
        openBackContent.getChildren().addAll(openBackIcon, openBackText);
        btnOpenBack.setGraphic(openBackContent);
        
        btnOpenBack.setOnAction(e -> openBackOfficeWindow());
        btnOpenBack.setOnMouseEntered(e -> 
            btnOpenBack.setStyle("-fx-background-color: rgba(22,160,133,0.4); -fx-text-fill: white; " +
                        "-fx-font-size: 14px; -fx-padding: 14 20; -fx-alignment: center; " +
                        "-fx-border-width: 2; -fx-border-color: #16A085; -fx-border-radius: 8; -fx-background-radius: 8;"));
        btnOpenBack.setOnMouseExited(e -> 
            btnOpenBack.setStyle("-fx-background-color: rgba(22,160,133,0.2); -fx-text-fill: white; " +
                        "-fx-font-size: 14px; -fx-padding: 14 20; -fx-alignment: center; " +
                        "-fx-border-width: 2; -fx-border-color: #16A085; -fx-border-radius: 8; -fx-background-radius: 8;"));
        
        sidebar.getChildren().addAll(header, welcomeBox, featuresBox, btnOpenBack, spacer, footer);
    }
    
    private void showFrontOffice() {
        try {
            BorderPane content = new BorderPane();
            content.setStyle("-fx-background-color: #F5F5F5;");
            
            // Header spécifique Front-Office
            HBox header = createHeader("Nos Hébergements", "Trouvez l'hébergement parfait pour votre séjour");
            content.setTop(header);
            
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Frontoffice/hebergement-front.fxml"));
            BorderPane frontPane = loader.load();
            content.setCenter(frontPane);
            
            root.setCenter(content);
            System.out.println("✅ Espace Client chargé");
        } catch (Exception e) {
            System.err.println("❌ Erreur Espace Client: " + e.getMessage());
            e.printStackTrace();
            showErrorPage("Espace Client", e.getMessage());
        }
    }
    
    private HBox createHeader(String title, String subtitle) {
        HBox header = new HBox();
        header.setPadding(new Insets(25, 40, 25, 40));
        header.setStyle("-fx-background-color: white; -fx-border-width: 0 0 1 0; -fx-border-color: #E5E7EB;");
        
        VBox titleBox = new VBox(5);
        Label titleLabel = new Label(title);
        titleLabel.setStyle("-fx-font-size: 36px; -fx-font-weight: bold; -fx-text-fill: #3498DB;");
        
        Label subtitleLabel = new Label(subtitle);
        subtitleLabel.setStyle("-fx-font-size: 15px; -fx-text-fill: #666;");
        
        titleBox.getChildren().addAll(titleLabel, subtitleLabel);
        header.getChildren().add(titleBox);
        
        return header;
    }
    
    private void showErrorPage(String pageName, String error) {
        VBox errorContent = new VBox(20);
        errorContent.setAlignment(Pos.CENTER);
        errorContent.setPadding(new Insets(50));
        errorContent.setStyle("-fx-background-color: #F5F5F5;");
        
        Label errorIcon = new Label("⚠️");
        errorIcon.setStyle("-fx-font-size: 64px;");
        
        Label errorTitle = new Label("Erreur de chargement: " + pageName);
        errorTitle.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #E67E22;");
        
        Label errorMsg = new Label(error);
        errorMsg.setStyle("-fx-font-size: 14px; -fx-text-fill: #666;");
        errorMsg.setWrapText(true);
        errorMsg.setMaxWidth(600);
        
        Label solution = new Label("Contactez l'administrateur si le problème persiste.");
        solution.setStyle("-fx-font-size: 12px; -fx-text-fill: #999; -fx-font-style: italic;");
        
        errorContent.getChildren().addAll(errorIcon, errorTitle, errorMsg, solution);
        root.setCenter(errorContent);
    }
    
    private void openBackOfficeWindow() {
        // Demander confirmation (car accès admin)
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Accès Administration");
        confirm.setHeaderText("Ouvrir le Back-Office?");
        confirm.setContentText("Vous allez accéder à l'interface d'administration.\nContinuer?");
        
        confirm.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                try {
                    Stage backStage = new Stage();
                    BackOfficeApp backApp = new BackOfficeApp();
                    backApp.start(backStage);
                    System.out.println("✅ Back-Office ouvert dans nouvelle fenêtre");
                } catch (Exception e) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Erreur");
                    alert.setHeaderText("Impossible d'ouvrir le Back-Office");
                    alert.setContentText(e.getMessage());
                    alert.showAndWait();
                    e.printStackTrace();
                }
            }
        });
    }

    public static void main(String[] args) {
        launch(args);
    }
}
