package org.example.services;

import org.example.entities.Hebergement;
import org.example.utils.MyDataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HebergementService {
    private Connection connection;

    public HebergementService() {
        this.connection = MyDataBase.getConnection();
    }

    // CREATE - Ajouter un hébergement
    public void ajouterHebergement(Hebergement hebergement) {
        String query = "INSERT INTO hebergement (nom, type, adresse, prix, image_path) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, hebergement.getNom());
            ps.setString(2, hebergement.getType());
            ps.setString(3, hebergement.getAdresse());
            ps.setString(4, hebergement.getPrix());
            ps.setString(5, hebergement.getImagePath() != null ? hebergement.getImagePath() : "");
            ps.executeUpdate();
            System.out.println("Hébergement ajouté avec succès!");
        } catch (SQLException e) {
            System.err.println("Erreur lors de l'ajout: " + e.getMessage());
        }
    }

    // READ - Afficher tous les hébergements
    public List<Hebergement> afficherHebergements() {
        List<Hebergement> hebergements = new ArrayList<>();
        String query = "SELECT * FROM hebergement";
        try (Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery(query)) {
            while (rs.next()) {
                Hebergement h = new Hebergement(
                        rs.getInt("id"),
                        rs.getString("nom"),
                        rs.getString("type"),
                        rs.getString("adresse"),
                        rs.getString("prix"),
                        rs.getString("image_path")
                );
                hebergements.add(h);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la récupération: " + e.getMessage());
        }
        return hebergements;
    }

    // READ - Récupérer un hébergement par ID
    public Hebergement getHebergementById(int id) {
        String query = "SELECT * FROM hebergement WHERE id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Hebergement(
                        rs.getInt("id"),
                        rs.getString("nom"),
                        rs.getString("type"),
                        rs.getString("adresse"),
                        rs.getString("prix"),
                        rs.getString("image_path")
                );
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la récupération: " + e.getMessage());
        }
        return null;
    }

    // UPDATE - Modifier un hébergement
    public void modifierHebergement(Hebergement hebergement) {
        String query = "UPDATE hebergement SET nom=?, type=?, adresse=?, prix=?, image_path=? WHERE id=?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, hebergement.getNom());
            ps.setString(2, hebergement.getType());
            ps.setString(3, hebergement.getAdresse());
            ps.setString(4, hebergement.getPrix());
            ps.setString(5, hebergement.getImagePath() != null ? hebergement.getImagePath() : "");
            ps.setInt(6, hebergement.getId());
            ps.executeUpdate();
            System.out.println("Hébergement modifié avec succès!");
        } catch (SQLException e) {
            System.err.println("Erreur lors de la modification: " + e.getMessage());
        }
    }

    // DELETE - Supprimer un hébergement
    public void supprimerHebergement(int id) {
        String query = "DELETE FROM hebergement WHERE id=?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Hébergement supprimé avec succès!");
        } catch (SQLException e) {
            System.err.println("Erreur lors de la suppression: " + e.getMessage());
        }
    }
}