package org.example.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Utilitaire simple pour logger les messages
 */
public class Logger {
    
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static boolean debugMode = true;
    
    /**
     * Log un message d'information
     */
    public static void info(String message) {
        log("INFO", message);
    }
    
    /**
     * Log un message d'erreur
     */
    public static void error(String message) {
        log("ERROR", message);
    }
    
    /**
     * Log un message d'erreur avec exception
     */
    public static void error(String message, Throwable throwable) {
        log("ERROR", message + " - " + throwable.getMessage());
        if (debugMode) {
            throwable.printStackTrace();
        }
    }
    
    /**
     * Log un message de debug
     */
    public static void debug(String message) {
        if (debugMode) {
            log("DEBUG", message);
        }
    }
    
    /**
     * Log un message d'avertissement
     */
    public static void warning(String message) {
        log("WARNING", message);
    }
    
    private static void log(String level, String message) {
        String timestamp = LocalDateTime.now().format(formatter);
        System.out.println("[" + timestamp + "] [" + level + "] " + message);
    }
    
    public static void setDebugMode(boolean enabled) {
        debugMode = enabled;
    }
    
    private Logger() {
        // Empêcher l'instanciation
    }
}
