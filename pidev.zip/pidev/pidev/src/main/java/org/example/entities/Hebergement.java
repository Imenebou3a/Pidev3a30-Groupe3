package org.example.entities;

public class Hebergement {
    private int id;
    private String nom;
    private String type;
    private String adresse;
    private String prix;
    private String imagePath;

    // Constructeur vide
    public Hebergement() {
    }

    // Constructeur sans id (pour l'ajout)
    public Hebergement(String nom, String type, String adresse, String prix) {
        this.nom = nom;
        this.type = type;
        this.adresse = adresse;
        this.prix = prix;
    }

    // Constructeur sans id avec image
    public Hebergement(String nom, String type, String adresse, String prix, String imagePath) {
        this.nom = nom;
        this.type = type;
        this.adresse = adresse;
        this.prix = prix;
        this.imagePath = imagePath;
    }

    // Constructeur complet (avec id pour la modification)
    public Hebergement(int id, String nom, String type, String adresse, String prix) {
        this.id = id;
        this.nom = nom;
        this.type = type;
        this.adresse = adresse;
        this.prix = prix;
    }

    // Constructeur complet avec image
    public Hebergement(int id, String nom, String type, String adresse, String prix, String imagePath) {
        this.id = id;
        this.nom = nom;
        this.type = type;
        this.adresse = adresse;
        this.prix = prix;
        this.imagePath = imagePath;
    }

    // Getters et Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getPrix() {
        return prix;
    }

    public void setPrix(String prix) {
        this.prix = prix;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    @Override
    public String toString() {
        return nom + " - " + adresse + " (" + prix + " DT/nuit)";
    }
}