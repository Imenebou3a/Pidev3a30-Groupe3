package org.example.utils;

import org.example.entities.Hebergement;
import org.example.services.HebergementService;
import org.example.utils.MyDataBase;

import java.sql.Connection;
import java.util.List;

/**
 * Classe de test pour vérifier les opérations CRUD sur les hébergements
 * Affiche tous les résultats et erreurs dans la console
 */
public class TestHebergementConsole {

    public static void main(String[] args) {
        System.out.println("=".repeat(80));
        System.out.println("🏠 TEST DES HÉBERGEMENTS - AFFICHAGE CONSOLE");
        System.out.println("=".repeat(80));
        System.out.println();

        HebergementService service = new HebergementService();

        // Test 1: Connexion à la base de données
        testConnexion();

        // Test 2: Afficher tous les hébergements
        testAfficherHebergements(service);

        // Test 3: Ajouter un hébergement
        testAjouterHebergement(service);

        // Test 4: Modifier un hébergement
        testModifierHebergement(service);

        // Test 5: Rechercher un hébergement par ID
        testRechercherParId(service);

        // Test 6: Supprimer un hébergement
        testSupprimerHebergement(service);

        System.out.println();
        System.out.println("=".repeat(80));
        System.out.println("✅ TESTS TERMINÉS");
        System.out.println("=".repeat(80));
    }

    private static void testConnexion() {
        System.out.println("📡 TEST 1: Connexion à la base de données");
        System.out.println("-".repeat(80));
        try {
            Connection cnx = MyDataBase.getConnection();
            if (cnx != null && !cnx.isClosed()) {
                System.out.println("✅ Connexion réussie!");
                System.out.println("   URL: " + cnx.getMetaData().getURL());
                System.out.println("   User: " + cnx.getMetaData().getUserName());
            } else {
                System.err.println("❌ ERREUR: Connexion fermée ou nulle");
            }
        } catch (Exception e) {
            System.err.println("❌ ERREUR lors de la connexion:");
            e.printStackTrace();
        }
        System.out.println();
    }

    private static void testAfficherHebergements(HebergementService service) {
        System.out.println("📋 TEST 2: Afficher tous les hébergements");
        System.out.println("-".repeat(80));
        try {
            List<Hebergement> hebergements = service.afficherHebergements();
            
            if (hebergements.isEmpty()) {
                System.out.println("⚠️  Aucun hébergement trouvé dans la base de données");
            } else {
                System.out.println("✅ " + hebergements.size() + " hébergement(s) trouvé(s):");
                System.out.println();
                
                for (Hebergement h : hebergements) {
                    System.out.println("   🏠 ID: " + h.getId());
                    System.out.println("      Nom: " + h.getNom());
                    System.out.println("      Type: " + h.getType());
                    System.out.println("      Adresse: " + h.getAdresse());
                    System.out.println("      Prix: " + h.getPrix() + " DT/nuit");
                    System.out.println("      Image: " + (h.getImagePath() != null ? h.getImagePath() : "Aucune"));
                    System.out.println();
                }
            }
        } catch (Exception e) {
            System.err.println("❌ ERREUR lors de l'affichage:");
            e.printStackTrace();
        }
        System.out.println();
    }

    private static void testAjouterHebergement(HebergementService service) {
        System.out.println("➕ TEST 3: Ajouter un hébergement");
        System.out.println("-".repeat(80));
        try {
            Hebergement nouveau = new Hebergement(
                "Villa Test Console",
                "Villa",
                "123 Rue de Test, Tunis",
                "250.00",
                null
            );
            
            System.out.println("   Tentative d'ajout:");
            System.out.println("   - Nom: " + nouveau.getNom());
            System.out.println("   - Type: " + nouveau.getType());
            System.out.println("   - Adresse: " + nouveau.getAdresse());
            System.out.println("   - Prix: " + nouveau.getPrix() + " DT");
            
            service.ajouterHebergement(nouveau);
            System.out.println("✅ Hébergement ajouté avec succès!");
            
            // Vérifier l'ajout
            List<Hebergement> liste = service.afficherHebergements();
            System.out.println("   Total d'hébergements maintenant: " + liste.size());
            
        } catch (Exception e) {
            System.err.println("❌ ERREUR lors de l'ajout:");
            e.printStackTrace();
        }
        System.out.println();
    }

    private static void testModifierHebergement(HebergementService service) {
        System.out.println("✏️  TEST 4: Modifier un hébergement");
        System.out.println("-".repeat(80));
        try {
            List<Hebergement> hebergements = service.afficherHebergements();
            
            if (hebergements.isEmpty()) {
                System.out.println("⚠️  Aucun hébergement à modifier");
            } else {
                Hebergement aModifier = hebergements.get(0);
                System.out.println("   Modification de l'hébergement ID: " + aModifier.getId());
                System.out.println("   Ancien nom: " + aModifier.getNom());
                
                String nouveauNom = aModifier.getNom() + " (Modifié)";
                aModifier.setNom(nouveauNom);
                aModifier.setPrix("299.99");
                
                service.modifierHebergement(aModifier);
                System.out.println("✅ Hébergement modifié avec succès!");
                System.out.println("   Nouveau nom: " + nouveauNom);
                System.out.println("   Nouveau prix: 299.99 DT");
            }
        } catch (Exception e) {
            System.err.println("❌ ERREUR lors de la modification:");
            e.printStackTrace();
        }
        System.out.println();
    }

    private static void testRechercherParId(HebergementService service) {
        System.out.println("🔍 TEST 5: Rechercher un hébergement par ID");
        System.out.println("-".repeat(80));
        try {
            List<Hebergement> hebergements = service.afficherHebergements();
            
            if (hebergements.isEmpty()) {
                System.out.println("⚠️  Aucun hébergement à rechercher");
            } else {
                int idRecherche = hebergements.get(0).getId();
                System.out.println("   Recherche de l'hébergement ID: " + idRecherche);
                
                Hebergement trouve = service.getHebergementById(idRecherche);
                
                if (trouve != null) {
                    System.out.println("✅ Hébergement trouvé:");
                    System.out.println("   - ID: " + trouve.getId());
                    System.out.println("   - Nom: " + trouve.getNom());
                    System.out.println("   - Type: " + trouve.getType());
                    System.out.println("   - Prix: " + trouve.getPrix() + " DT");
                } else {
                    System.err.println("❌ Hébergement non trouvé!");
                }
            }
        } catch (Exception e) {
            System.err.println("❌ ERREUR lors de la recherche:");
            e.printStackTrace();
        }
        System.out.println();
    }

    private static void testSupprimerHebergement(HebergementService service) {
        System.out.println("🗑️  TEST 6: Supprimer un hébergement");
        System.out.println("-".repeat(80));
        try {
            List<Hebergement> hebergements = service.afficherHebergements();
            int nombreAvant = hebergements.size();
            System.out.println("   Nombre d'hébergements avant suppression: " + nombreAvant);
            
            if (hebergements.isEmpty()) {
                System.out.println("⚠️  Aucun hébergement à supprimer");
            } else {
                // Supprimer le dernier hébergement ajouté
                Hebergement aSupprimer = hebergements.get(hebergements.size() - 1);
                int idSupprimer = aSupprimer.getId();
                
                System.out.println("   Suppression de l'hébergement:");
                System.out.println("   - ID: " + idSupprimer);
                System.out.println("   - Nom: " + aSupprimer.getNom());
                
                service.supprimerHebergement(idSupprimer);
                System.out.println("✅ Hébergement supprimé avec succès!");
                
                // Vérifier la suppression
                List<Hebergement> apres = service.afficherHebergements();
                System.out.println("   Nombre d'hébergements après suppression: " + apres.size());
                
                if (apres.size() == nombreAvant - 1) {
                    System.out.println("✅ Vérification: La suppression est confirmée");
                } else {
                    System.err.println("⚠️  Attention: Le nombre d'hébergements ne correspond pas");
                }
            }
        } catch (Exception e) {
            System.err.println("❌ ERREUR lors de la suppression:");
            e.printStackTrace();
        }
        System.out.println();
    }
}
