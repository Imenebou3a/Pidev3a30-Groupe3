package org.example.services;

import org.example.entities.Reservation;
import org.example.utils.MyDataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReservationService {
    private Connection connection;

    public ReservationService() {
        this.connection = MyDataBase.getConnection();
    }

    // CREATE - Ajouter une réservation
    public void ajouterReservation(Reservation reservation) {
        String query = "INSERT INTO reservation (id_hebergement, date_debut, date_fin, nb_personnes) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, reservation.getIdHebergement());
            ps.setDate(2, reservation.getDateDebut());
            ps.setDate(3, reservation.getDateFin());
            ps.setInt(4, reservation.getNbPersonnes());
            ps.executeUpdate();
            System.out.println("Réservation ajoutée avec succès!");
        } catch (SQLException e) {
            System.err.println("Erreur lors de l'ajout: " + e.getMessage());
        }
    }

    // READ - Afficher toutes les réservations
    public List<Reservation> afficherReservations() {
        List<Reservation> reservations = new ArrayList<>();
        String query = "SELECT * FROM reservation";
        try (Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery(query)) {
            while (rs.next()) {
                Reservation r = new Reservation(
                        rs.getInt("id"),
                        rs.getInt("id_hebergement"),
                        rs.getDate("date_debut"),
                        rs.getDate("date_fin"),
                        rs.getInt("nb_personnes")
                );
                reservations.add(r);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la récupération: " + e.getMessage());
        }
        return reservations;
    }

    // READ - Récupérer les réservations par hébergement
    public List<Reservation> getReservationsByHebergement(int idHebergement) {
        List<Reservation> reservations = new ArrayList<>();
        String query = "SELECT * FROM reservation WHERE id_hebergement = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, idHebergement);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Reservation r = new Reservation(
                        rs.getInt("id"),
                        rs.getInt("id_hebergement"),
                        rs.getDate("date_debut"),
                        rs.getDate("date_fin"),
                        rs.getInt("nb_personnes")
                );
                reservations.add(r);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la récupération: " + e.getMessage());
        }
        return reservations;
    }

    // UPDATE - Modifier une réservation
    public void modifierReservation(Reservation reservation) {
        String query = "UPDATE reservation SET id_hebergement=?, date_debut=?, date_fin=?, nb_personnes=? WHERE id=?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, reservation.getIdHebergement());
            ps.setDate(2, reservation.getDateDebut());
            ps.setDate(3, reservation.getDateFin());
            ps.setInt(4, reservation.getNbPersonnes());
            ps.setInt(5, reservation.getId());
            ps.executeUpdate();
            System.out.println("Réservation modifiée avec succès!");
        } catch (SQLException e) {
            System.err.println("Erreur lors de la modification: " + e.getMessage());
        }
    }

    // DELETE - Supprimer une réservation
    public void supprimerReservation(int id) {
        String query = "DELETE FROM reservation WHERE id=?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Réservation supprimée avec succès!");
        } catch (SQLException e) {
            System.err.println("Erreur lors de la suppression: " + e.getMessage());
        }
    }

    // Vérifier la disponibilité d'un hébergement
    public boolean verifierDisponibilite(int idHebergement, Date dateDebut, Date dateFin) {
        String query = "SELECT COUNT(*) FROM reservation WHERE id_hebergement = ? AND " +
                "((date_debut <= ? AND date_fin >= ?) OR (date_debut <= ? AND date_fin >= ?) OR " +
                "(date_debut >= ? AND date_fin <= ?))";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, idHebergement);
            ps.setDate(2, dateFin);
            ps.setDate(3, dateDebut);
            ps.setDate(4, dateDebut);
            ps.setDate(5, dateFin);
            ps.setDate(6, dateDebut);
            ps.setDate(7, dateFin);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) == 0; // Disponible si aucune réservation trouvée
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la vérification: " + e.getMessage());
        }
        return false;
    }
}