package org.example.utils;

import org.example.exceptions.ValidationException;

import java.sql.Date;
import java.time.LocalDate;

/**
 * Utilitaires pour la validation des données
 */
public class ValidationUtils {
    
    /**
     * Valide qu'une chaîne n'est pas vide
     */
    public static void validateNotEmpty(String value, String fieldName) {
        if (value == null || value.trim().isEmpty()) {
            throw new ValidationException(fieldName + " ne peut pas être vide");
        }
    }
    
    /**
     * Valide un prix
     */
    public static void validatePrice(String priceStr) {
        try {
            double price = Double.parseDouble(priceStr);
            if (price < Constants.MIN_PRICE || price > Constants.MAX_PRICE) {
                throw new ValidationException("Le prix doit être entre " + 
                    Constants.MIN_PRICE + " et " + Constants.MAX_PRICE + " DT");
            }
        } catch (NumberFormatException e) {
            throw new ValidationException("Prix invalide: " + priceStr);
        }
    }
    
    /**
     * Valide le nombre de personnes
     */
    public static void validatePersons(int persons) {
        if (persons < Constants.MIN_PERSONS || persons > Constants.MAX_PERSONS) {
            throw new ValidationException("Le nombre de personnes doit être entre " + 
                Constants.MIN_PERSONS + " et " + Constants.MAX_PERSONS);
        }
    }
    
    /**
     * Valide les dates de réservation
     */
    public static void validateDates(Date dateDebut, Date dateFin) {
        if (dateDebut == null || dateFin == null) {
            throw new ValidationException("Les dates ne peuvent pas être nulles");
        }
        
        LocalDate debut = dateDebut.toLocalDate();
        LocalDate fin = dateFin.toLocalDate();
        LocalDate today = LocalDate.now();
        
        // La date de début doit être dans le futur
        if (debut.isBefore(today)) {
            throw new ValidationException("La date de début doit être dans le futur");
        }
        
        // La date de fin doit être après la date de début
        if (!fin.isAfter(debut)) {
            throw new ValidationException("La date de fin doit être après la date de début");
        }
        
        // Durée minimum
        long nights = java.time.temporal.ChronoUnit.DAYS.between(debut, fin);
        if (nights < Constants.MIN_NIGHTS) {
            throw new ValidationException("La durée minimum est de " + Constants.MIN_NIGHTS + " nuit(s)");
        }
    }
    
    /**
     * Valide un email
     */
    public static void validateEmail(String email) {
        if (email == null || !email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            throw new ValidationException("Email invalide: " + email);
        }
    }
    
    /**
     * Valide un numéro de téléphone
     */
    public static void validatePhone(String phone) {
        if (phone == null || !phone.matches("^[0-9]{8}$")) {
            throw new ValidationException("Numéro de téléphone invalide (8 chiffres requis)");
        }
    }
    
    private ValidationUtils() {
        // Empêcher l'instanciation
    }
}
