package org.example;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;

/**
 * APPLICATION BACK-OFFICE (ADMIN)
 * Accès: Dashboard, Hébergements, Réservations
 * Rôle: Gestion complète de la plateforme
 */
public class BackOfficeApp extends Application {

    private BorderPane root;
    private VBox sidebar;
    private Button btnDashboard, btnHebergements, btnReservations;

    @Override
    public void start(Stage primaryStage) {
        root = new BorderPane();
        
        // Créer sidebar Back-Office
        createBackOfficeSidebar();
        root.setLeft(sidebar);
        
        // Démarrer sur Dashboard
        showDashboard();
        
        Scene scene = new Scene(root, 1400, 800);
        
        // Charger CSS
        try {
            String mainCss = getClass().getResource("/styles/main-theme.css").toExternalForm();
            scene.getStylesheets().add(mainCss);
        } catch (Exception e) {
            System.err.println("CSS non chargé: " + e.getMessage());
        }
        
        primaryStage.setTitle("Lammetna - Back-Office (Administration)");
        primaryStage.setScene(scene);
        primaryStage.setMaximized(true);
        primaryStage.show();
        
        System.out.println("✅ Back-Office lancé avec succès!");
    }
    
    private void createBackOfficeSidebar() {
        sidebar = new VBox(10);
        sidebar.setPadding(new Insets(20));
        sidebar.setPrefWidth(280);
        sidebar.setStyle("-fx-background-color: linear-gradient(to bottom, #16A085, #138D75);");
        
        // Header
        VBox header = new VBox(10);
        header.setAlignment(Pos.CENTER);
        header.setPadding(new Insets(20, 0, 30, 0));
        
        Label logo = new Label("🏝️");
        logo.setStyle("-fx-font-size: 64px;");
        
        Label appName = new Label("LAMMETNA");
        appName.setStyle("-fx-text-fill: white; -fx-font-size: 32px; -fx-font-weight: bold;");
        
        Label tagline = new Label("BACK-OFFICE");
        tagline.setStyle("-fx-text-fill: #F4D03F; -fx-font-size: 14px; -fx-font-weight: bold; -fx-letter-spacing: 2px;");
        
        Label role = new Label("👨‍💼 Administration");
        role.setStyle("-fx-text-fill: rgba(255,255,255,0.8); -fx-font-size: 12px;");
        
        header.getChildren().addAll(logo, appName, tagline, role);
        
        // Menu buttons - BACK-OFFICE ONLY
        btnDashboard = createSidebarButton("📊", "Dashboard");
        btnDashboard.setOnAction(e -> {
            setActiveButton(btnDashboard);
            showDashboard();
        });
        
        btnHebergements = createSidebarButton("🏡", "Hébergements");
        btnHebergements.setOnAction(e -> {
            setActiveButton(btnHebergements);
            showHebergements();
        });
        
        btnReservations = createSidebarButton("📅", "Réservations");
        btnReservations.setOnAction(e -> {
            setActiveButton(btnReservations);
            showReservations();
        });
        
        // Info section
        VBox infoBox = new VBox(8);
        infoBox.setPadding(new Insets(20, 15, 20, 15));
        infoBox.setStyle("-fx-background-color: rgba(0,0,0,0.2); -fx-background-radius: 10;");
        
        Label infoTitle = new Label("ℹ️ Accès Admin");
        infoTitle.setStyle("-fx-text-fill: white; -fx-font-size: 13px; -fx-font-weight: bold;");
        
        Label infoText = new Label("Vous avez accès à toutes les fonctionnalités de gestion.");
        infoText.setWrapText(true);
        infoText.setStyle("-fx-text-fill: rgba(255,255,255,0.9); -fx-font-size: 11px;");
        
        infoBox.getChildren().addAll(infoTitle, infoText);
        
        // Footer
        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);
        
        VBox footer = new VBox(5);
        footer.setAlignment(Pos.CENTER);
        footer.setPadding(new Insets(20, 0, 0, 0));
        Label copyright = new Label("© 2026 Lammetna");
        copyright.setStyle("-fx-text-fill: rgba(255,255,255,0.7); -fx-font-size: 11px;");
        Label version = new Label("Back-Office v1.0");
        version.setStyle("-fx-text-fill: rgba(255,255,255,0.7); -fx-font-size: 11px;");
        footer.getChildren().addAll(copyright, version);
        
        // Bouton pour ouvrir Front-Office dans nouvelle fenêtre
        Button btnOpenFront = new Button();
        btnOpenFront.setMaxWidth(Double.MAX_VALUE);
        btnOpenFront.setStyle("-fx-background-color: rgba(52,152,219,0.2); -fx-text-fill: white; " +
                    "-fx-font-size: 14px; -fx-padding: 14 20; -fx-alignment: center; " +
                    "-fx-border-width: 2; -fx-border-color: #3498DB; -fx-border-radius: 8; -fx-background-radius: 8;");
        
        HBox openFrontContent = new HBox(10);
        openFrontContent.setAlignment(Pos.CENTER);
        Label openFrontIcon = new Label("🏖️");
        openFrontIcon.setStyle("-fx-font-size: 20px;");
        Label openFrontText = new Label("Ouvrir Front-Office");
        openFrontText.setStyle("-fx-font-size: 13px; -fx-font-weight: bold;");
        openFrontContent.getChildren().addAll(openFrontIcon, openFrontText);
        btnOpenFront.setGraphic(openFrontContent);
        
        btnOpenFront.setOnAction(e -> openFrontOfficeWindow());
        btnOpenFront.setOnMouseEntered(e -> 
            btnOpenFront.setStyle("-fx-background-color: rgba(52,152,219,0.4); -fx-text-fill: white; " +
                        "-fx-font-size: 14px; -fx-padding: 14 20; -fx-alignment: center; " +
                        "-fx-border-width: 2; -fx-border-color: #3498DB; -fx-border-radius: 8; -fx-background-radius: 8;"));
        btnOpenFront.setOnMouseExited(e -> 
            btnOpenFront.setStyle("-fx-background-color: rgba(52,152,219,0.2); -fx-text-fill: white; " +
                        "-fx-font-size: 14px; -fx-padding: 14 20; -fx-alignment: center; " +
                        "-fx-border-width: 2; -fx-border-color: #3498DB; -fx-border-radius: 8; -fx-background-radius: 8;"));
        
        sidebar.getChildren().addAll(header, btnDashboard, btnHebergements, btnReservations, infoBox, btnOpenFront, spacer, footer);
    }
    
    private Button createSidebarButton(String icon, String text) {
        Button btn = new Button();
        btn.setMaxWidth(Double.MAX_VALUE);
        btn.setStyle("-fx-background-color: transparent; -fx-text-fill: white; " +
                    "-fx-font-size: 15px; -fx-padding: 16 25; -fx-alignment: center-left; " +
                    "-fx-border-width: 0 0 0 4; -fx-border-color: transparent;");
        
        HBox content = new HBox(12);
        content.setAlignment(Pos.CENTER_LEFT);
        Label iconLabel = new Label(icon);
        iconLabel.setStyle("-fx-font-size: 22px;");
        Label textLabel = new Label(text);
        textLabel.setStyle("-fx-font-size: 15px;");
        content.getChildren().addAll(iconLabel, textLabel);
        btn.setGraphic(content);
        
        btn.setOnMouseEntered(e -> 
            btn.setStyle("-fx-background-color: rgba(230,126,34,0.2); -fx-text-fill: white; " +
                        "-fx-font-size: 15px; -fx-padding: 16 25; -fx-alignment: center-left; " +
                        "-fx-border-width: 0 0 0 4; -fx-border-color: #E67E22;"));
        btn.setOnMouseExited(e -> {
            if (!btn.getStyleClass().contains("active")) {
                btn.setStyle("-fx-background-color: transparent; -fx-text-fill: white; " +
                            "-fx-font-size: 15px; -fx-padding: 16 25; -fx-alignment: center-left; " +
                            "-fx-border-width: 0 0 0 4; -fx-border-color: transparent;");
            }
        });
        
        return btn;
    }
    
    private void setActiveButton(Button activeBtn) {
        btnDashboard.setStyle("-fx-background-color: transparent; -fx-text-fill: white; " +
                    "-fx-font-size: 15px; -fx-padding: 16 25; -fx-alignment: center-left; " +
                    "-fx-border-width: 0 0 0 4; -fx-border-color: transparent;");
        btnHebergements.setStyle("-fx-background-color: transparent; -fx-text-fill: white; " +
                    "-fx-font-size: 15px; -fx-padding: 16 25; -fx-alignment: center-left; " +
                    "-fx-border-width: 0 0 0 4; -fx-border-color: transparent;");
        btnReservations.setStyle("-fx-background-color: transparent; -fx-text-fill: white; " +
                    "-fx-font-size: 15px; -fx-padding: 16 25; -fx-alignment: center-left; " +
                    "-fx-border-width: 0 0 0 4; -fx-border-color: transparent;");
        
        activeBtn.setStyle("-fx-background-color: rgba(230,126,34,0.3); -fx-text-fill: white; " +
                          "-fx-font-size: 15px; -fx-padding: 16 25; -fx-alignment: center-left; " +
                          "-fx-border-width: 0 0 0 4; -fx-border-color: #E67E22; -fx-font-weight: bold;");
        activeBtn.getStyleClass().add("active");
    }
    
    private void showDashboard() {
        try {
            BorderPane content = new BorderPane();
            content.setStyle("-fx-background-color: #F5F5F5;");
            
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Backoffice/dashboard.fxml"));
            BorderPane dashPane = loader.load();
            content.setCenter(dashPane);
            
            root.setCenter(content);
            System.out.println("✅ Dashboard chargé");
        } catch (Exception e) {
            System.err.println("❌ Erreur Dashboard: " + e.getMessage());
            e.printStackTrace();
            showErrorPage("Dashboard", e.getMessage());
        }
    }
    
    private void showHebergements() {
        try {
            BorderPane content = new BorderPane();
            content.setStyle("-fx-background-color: #F5F5F5;");
            
            HBox header = createHeader("Gestion des Hébergements", "Créer, modifier et supprimer des hébergements");
            content.setTop(header);
            
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Backoffice/hebergement_back.fxml"));
            BorderPane hebPane = loader.load();
            content.setCenter(hebPane);
            
            root.setCenter(content);
            System.out.println("✅ Hébergements chargé");
        } catch (Exception e) {
            System.err.println("❌ Erreur Hébergements: " + e.getMessage());
            e.printStackTrace();
            showErrorPage("Hébergements", e.getMessage());
        }
    }
    
    private void showReservations() {
        try {
            BorderPane content = new BorderPane();
            content.setStyle("-fx-background-color: #F5F5F5;");
            
            HBox header = createHeader("Gestion des Réservations", "Afficher, modifier et supprimer des réservations");
            content.setTop(header);
            
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Backoffice/reservation_back.fxml"));
            BorderPane resPane = loader.load();
            content.setCenter(resPane);
            
            root.setCenter(content);
            System.out.println("✅ Réservations chargé");
        } catch (Exception e) {
            System.err.println("❌ Erreur Réservations: " + e.getMessage());
            e.printStackTrace();
            showErrorPage("Réservations", e.getMessage());
        }
    }
    
    private HBox createHeader(String title, String subtitle) {
        HBox header = new HBox();
        header.setPadding(new Insets(25, 40, 25, 40));
        header.setStyle("-fx-background-color: white; -fx-border-width: 0 0 1 0; -fx-border-color: #E5E7EB;");
        
        VBox titleBox = new VBox(5);
        Label titleLabel = new Label(title);
        titleLabel.setStyle("-fx-font-size: 36px; -fx-font-weight: bold; -fx-text-fill: #16A085;");
        
        Label subtitleLabel = new Label(subtitle);
        subtitleLabel.setStyle("-fx-font-size: 15px; -fx-text-fill: #666;");
        
        titleBox.getChildren().addAll(titleLabel, subtitleLabel);
        header.getChildren().add(titleBox);
        
        return header;
    }
    
    private void showErrorPage(String pageName, String error) {
        VBox errorContent = new VBox(20);
        errorContent.setAlignment(Pos.CENTER);
        errorContent.setPadding(new Insets(50));
        errorContent.setStyle("-fx-background-color: #F5F5F5;");
        
        Label errorIcon = new Label("⚠️");
        errorIcon.setStyle("-fx-font-size: 64px;");
        
        Label errorTitle = new Label("Erreur de chargement: " + pageName);
        errorTitle.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #E67E22;");
        
        Label errorMsg = new Label(error);
        errorMsg.setStyle("-fx-font-size: 14px; -fx-text-fill: #666;");
        errorMsg.setWrapText(true);
        errorMsg.setMaxWidth(600);
        
        errorContent.getChildren().addAll(errorIcon, errorTitle, errorMsg);
        root.setCenter(errorContent);
    }
    
    private void openFrontOfficeWindow() {
        try {
            Stage frontStage = new Stage();
            FrontOfficeApp frontApp = new FrontOfficeApp();
            frontApp.start(frontStage);
            System.out.println("✅ Front-Office ouvert dans nouvelle fenêtre");
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText("Impossible d'ouvrir le Front-Office");
            alert.setContentText(e.getMessage());
            alert.showAndWait();
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
