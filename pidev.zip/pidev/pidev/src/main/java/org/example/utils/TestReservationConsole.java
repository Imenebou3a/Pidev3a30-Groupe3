package org.example.utils;

import org.example.entities.Hebergement;
import org.example.entities.Reservation;
import org.example.services.HebergementService;
import org.example.services.ReservationService;
import org.example.utils.MyDataBase;

import java.sql.Connection;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

/**
 * Classe de test pour vérifier les opérations CRUD sur les réservations
 * Affiche tous les résultats et erreurs dans la console
 */
public class TestReservationConsole {

    public static void main(String[] args) {
        System.out.println("=".repeat(80));
        System.out.println("📅 TEST DES RÉSERVATIONS - AFFICHAGE CONSOLE");
        System.out.println("=".repeat(80));
        System.out.println();

        ReservationService reservationService = new ReservationService();
        HebergementService hebergementService = new HebergementService();

        // Test 1: Connexion
        testConnexion();

        // Test 2: Afficher toutes les réservations
        testAfficherReservations(reservationService, hebergementService);

        // Test 3: Ajouter une réservation
        testAjouterReservation(reservationService, hebergementService);

        // Test 4: Vérifier disponibilité
        testVerifierDisponibilite(reservationService, hebergementService);

        // Test 5: Modifier une réservation
        testModifierReservation(reservationService);

        // Test 6: Supprimer une réservation
        testSupprimerReservation(reservationService);

        System.out.println();
        System.out.println("=".repeat(80));
        System.out.println("✅ TESTS TERMINÉS");
        System.out.println("=".repeat(80));
    }

    private static void testConnexion() {
        System.out.println("📡 TEST 1: Connexion à la base de données");
        System.out.println("-".repeat(80));
        try {
            Connection cnx = MyDataBase.getConnection();
            if (cnx != null && !cnx.isClosed()) {
                System.out.println("✅ Connexion réussie!");
                System.out.println("   URL: " + cnx.getMetaData().getURL());
            } else {
                System.err.println("❌ ERREUR: Connexion fermée ou nulle");
            }
        } catch (Exception e) {
            System.err.println("❌ ERREUR lors de la connexion:");
            e.printStackTrace();
        }
        System.out.println();
    }

    private static void testAfficherReservations(ReservationService reservationService, 
                                                  HebergementService hebergementService) {
        System.out.println("📋 TEST 2: Afficher toutes les réservations");
        System.out.println("-".repeat(80));
        try {
            List<Reservation> reservations = reservationService.afficherReservations();
            
            if (reservations.isEmpty()) {
                System.out.println("⚠️  Aucune réservation trouvée dans la base de données");
            } else {
                System.out.println("✅ " + reservations.size() + " réservation(s) trouvée(s):");
                System.out.println();
                
                for (Reservation r : reservations) {
                    Hebergement h = hebergementService.getHebergementById(r.getIdHebergement());
                    
                    System.out.println("   📅 ID Réservation: " + r.getId());
                    System.out.println("      Hébergement: " + (h != null ? h.getNom() : "ID " + r.getIdHebergement()));
                    System.out.println("      Date début: " + r.getDateDebut());
                    System.out.println("      Date fin: " + r.getDateFin());
                    System.out.println("      Nombre de personnes: " + r.getNbPersonnes());
                    
                    // Calculer la durée
                    long nuits = java.time.temporal.ChronoUnit.DAYS.between(
                        r.getDateDebut().toLocalDate(), 
                        r.getDateFin().toLocalDate()
                    );
                    System.out.println("      Durée: " + nuits + " nuit(s)");
                    
                    // Calculer le prix total
                    if (h != null) {
                        double total = nuits * Double.parseDouble(h.getPrix());
                        System.out.println("      Prix total: " + total + " DT");
                    }
                    
                    System.out.println();
                }
            }
        } catch (Exception e) {
            System.err.println("❌ ERREUR lors de l'affichage:");
            e.printStackTrace();
        }
        System.out.println();
    }

    private static void testAjouterReservation(ReservationService reservationService,
                                                HebergementService hebergementService) {
        System.out.println("➕ TEST 3: Ajouter une réservation");
        System.out.println("-".repeat(80));
        try {
            List<Hebergement> hebergements = hebergementService.afficherHebergements();
            
            if (hebergements.isEmpty()) {
                System.out.println("⚠️  Aucun hébergement disponible pour créer une réservation");
            } else {
                Hebergement h = hebergements.get(0);
                LocalDate debut = LocalDate.now().plusDays(7);
                LocalDate fin = debut.plusDays(3);
                
                Reservation nouvelle = new Reservation(
                    h.getId(),
                    Date.valueOf(debut),
                    Date.valueOf(fin),
                    2
                );
                
                System.out.println("   Tentative d'ajout:");
                System.out.println("   - Hébergement: " + h.getNom());
                System.out.println("   - Date début: " + debut);
                System.out.println("   - Date fin: " + fin);
                System.out.println("   - Personnes: 2");
                
                reservationService.ajouterReservation(nouvelle);
                System.out.println("✅ Réservation ajoutée avec succès!");
                
                // Vérifier l'ajout
                List<Reservation> liste = reservationService.afficherReservations();
                System.out.println("   Total de réservations maintenant: " + liste.size());
            }
        } catch (Exception e) {
            System.err.println("❌ ERREUR lors de l'ajout:");
            e.printStackTrace();
        }
        System.out.println();
    }

    private static void testVerifierDisponibilite(ReservationService reservationService,
                                                    HebergementService hebergementService) {
        System.out.println("🔍 TEST 4: Vérifier la disponibilité");
        System.out.println("-".repeat(80));
        try {
            List<Hebergement> hebergements = hebergementService.afficherHebergements();
            
            if (hebergements.isEmpty()) {
                System.out.println("⚠️  Aucun hébergement pour tester la disponibilité");
            } else {
                Hebergement h = hebergements.get(0);
                LocalDate debut = LocalDate.now().plusDays(30);
                LocalDate fin = debut.plusDays(2);
                
                System.out.println("   Vérification pour:");
                System.out.println("   - Hébergement: " + h.getNom());
                System.out.println("   - Du: " + debut);
                System.out.println("   - Au: " + fin);
                
                boolean disponible = reservationService.verifierDisponibilite(
                    h.getId(), 
                    Date.valueOf(debut), 
                    Date.valueOf(fin)
                );
                
                if (disponible) {
                    System.out.println("✅ Hébergement DISPONIBLE pour ces dates");
                } else {
                    System.out.println("❌ Hébergement NON DISPONIBLE pour ces dates");
                }
            }
        } catch (Exception e) {
            System.err.println("❌ ERREUR lors de la vérification:");
            e.printStackTrace();
        }
        System.out.println();
    }

    private static void testModifierReservation(ReservationService reservationService) {
        System.out.println("✏️  TEST 5: Modifier une réservation");
        System.out.println("-".repeat(80));
        try {
            List<Reservation> reservations = reservationService.afficherReservations();
            
            if (reservations.isEmpty()) {
                System.out.println("⚠️  Aucune réservation à modifier");
            } else {
                Reservation aModifier = reservations.get(0);
                System.out.println("   Modification de la réservation ID: " + aModifier.getId());
                System.out.println("   Ancien nombre de personnes: " + aModifier.getNbPersonnes());
                
                int nouveauNombre = aModifier.getNbPersonnes() + 1;
                aModifier.setNbPersonnes(nouveauNombre);
                
                reservationService.modifierReservation(aModifier);
                System.out.println("✅ Réservation modifiée avec succès!");
                System.out.println("   Nouveau nombre de personnes: " + nouveauNombre);
            }
        } catch (Exception e) {
            System.err.println("❌ ERREUR lors de la modification:");
            e.printStackTrace();
        }
        System.out.println();
    }

    private static void testSupprimerReservation(ReservationService reservationService) {
        System.out.println("🗑️  TEST 6: Supprimer une réservation");
        System.out.println("-".repeat(80));
        try {
            List<Reservation> reservations = reservationService.afficherReservations();
            int nombreAvant = reservations.size();
            System.out.println("   Nombre de réservations avant suppression: " + nombreAvant);
            
            if (reservations.isEmpty()) {
                System.out.println("⚠️  Aucune réservation à supprimer");
            } else {
                // Supprimer la dernière réservation
                Reservation aSupprimer = reservations.get(reservations.size() - 1);
                int idSupprimer = aSupprimer.getId();
                
                System.out.println("   Suppression de la réservation:");
                System.out.println("   - ID: " + idSupprimer);
                System.out.println("   - Hébergement ID: " + aSupprimer.getIdHebergement());
                System.out.println("   - Dates: " + aSupprimer.getDateDebut() + " au " + aSupprimer.getDateFin());
                
                reservationService.supprimerReservation(idSupprimer);
                System.out.println("✅ Réservation supprimée avec succès!");
                
                // Vérifier la suppression
                List<Reservation> apres = reservationService.afficherReservations();
                System.out.println("   Nombre de réservations après suppression: " + apres.size());
                
                if (apres.size() == nombreAvant - 1) {
                    System.out.println("✅ Vérification: La suppression est confirmée");
                } else {
                    System.err.println("⚠️  Attention: Le nombre de réservations ne correspond pas");
                }
            }
        } catch (Exception e) {
            System.err.println("❌ ERREUR lors de la suppression:");
            e.printStackTrace();
        }
        System.out.println();
    }
}
