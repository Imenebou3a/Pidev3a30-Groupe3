package org.example.controller.Backoffice;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.entities.Hebergement;
import org.example.entities.Reservation;
import org.example.services.HebergementService;
import org.example.services.ReservationService;

import java.sql.Date;
import java.time.LocalDate;

public class ReservationBackController {

    // ============================================
    // TAB 1: LISTE
    // ============================================
    @FXML
    private TextField txtRechercheList;
    @FXML
    private ComboBox<Hebergement> comboFiltreHebergement;
    @FXML
    private DatePicker dateFiltreDebut;
    @FXML
    private DatePicker dateFiltreFin;
    @FXML
    private TableView<Reservation> tableReservation;
    @FXML
    private TableColumn<Reservation, Integer> colId;
    @FXML
    private TableColumn<Reservation, Integer> colIdHebergement;
    @FXML
    private TableColumn<Reservation, Date> colDateDebut;
    @FXML
    private TableColumn<Reservation, Date> colDateFin;
    @FXML
    private TableColumn<Reservation, Integer> colNbPersonnes;
    @FXML
    private TableColumn<Reservation, Void> colActions;

    // ============================================
    // TAB 2: AJOUTER
    // ============================================
    @FXML
    private ComboBox<Hebergement> comboHebergementAjout;
    @FXML
    private DatePicker dateDebutAjout;
    @FXML
    private DatePicker dateFinAjout;
    @FXML
    private Spinner<Integer> spinnerPersonnesAjout;
    @FXML
    private Label lblErreurHebergementAjout;
    @FXML
    private Label lblErreurDateDebutAjout;
    @FXML
    private Label lblErreurDateFinAjout;
    @FXML
    private Label lblErreurPersonnesAjout;
    @FXML
    private Label lblMessageAjout;
    @FXML
    private Label lblPrixTotal;

    // ============================================
    // TAB 3: MODIFIER
    // ============================================
    @FXML
    private ComboBox<Reservation> comboReservationModif;
    @FXML
    private ComboBox<Hebergement> comboHebergementModif;
    @FXML
    private DatePicker dateDebutModif;
    @FXML
    private DatePicker dateFinModif;
    @FXML
    private Spinner<Integer> spinnerPersonnesModif;
    @FXML
    private Label lblErreurHebergementModif;
    @FXML
    private Label lblErreurDateDebutModif;
    @FXML
    private Label lblErreurDateFinModif;
    @FXML
    private Label lblErreurPersonnesModif;
    @FXML
    private Label lblMessageModif;
    @FXML
    private Label lblPrixTotalModif;

    // ============================================
    // TAB 4: SUPPRIMER
    // ============================================
    @FXML
    private ComboBox<Reservation> comboReservationSuppr;
    @FXML
    private javafx.scene.layout.VBox detailsSuppressionBox;
    @FXML
    private Label lblHebergementSuppr;
    @FXML
    private Label lblDateDebutSuppr;
    @FXML
    private Label lblDateFinSuppr;
    @FXML
    private Label lblPersonnesSuppr;
    @FXML
    private Label lblDureeSuppr;
    @FXML
    private Label lblMessageSuppr;

    private ReservationService reservationService;
    private HebergementService hebergementService;
    private ObservableList<Reservation> reservationList;
    private ObservableList<Hebergement> hebergementList;

    @FXML
    public void initialize() {
        reservationService = new ReservationService();
        hebergementService = new HebergementService();
        reservationList = FXCollections.observableArrayList();
        hebergementList = FXCollections.observableArrayList();

        // Configuration des colonnes du tableau
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colIdHebergement.setCellValueFactory(new PropertyValueFactory<>("idHebergement"));
        colDateDebut.setCellValueFactory(new PropertyValueFactory<>("dateDebut"));
        colDateFin.setCellValueFactory(new PropertyValueFactory<>("dateFin"));
        colNbPersonnes.setCellValueFactory(new PropertyValueFactory<>("nbPersonnes"));

        // Ajouter boutons actions dans la colonne
        ajouterBoutonsActions();

        // Charger les données
        chargerHebergements();
        chargerReservations();

        // Configuration des Spinners
        SpinnerValueFactory<Integer> valueFactoryAjout =
                new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 20, 2);
        spinnerPersonnesAjout.setValueFactory(valueFactoryAjout);

        SpinnerValueFactory<Integer> valueFactoryModif =
                new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 20, 2);
        spinnerPersonnesModif.setValueFactory(valueFactoryModif);

        // Listeners recherche et filtres
        txtRechercheList.textProperty().addListener((obs, old, newVal) -> filtrerReservations());
        comboFiltreHebergement.setOnAction(e -> filtrerReservations());
        dateFiltreDebut.setOnAction(e -> filtrerReservations());
        dateFiltreFin.setOnAction(e -> filtrerReservations());

        // Validation en temps réel - TAB AJOUT
        setupValidationAjout();

        // Validation en temps réel - TAB MODIFICATION
        setupValidationModif();

        // Listeners pour les ComboBox de sélection
        comboReservationModif.setOnAction(e -> chargerReservationPourModification());
        comboReservationSuppr.setOnAction(e -> afficherDetailsSuppr());

        // Calcul prix total
        dateDebutAjout.setOnAction(e -> calculerPrixTotal());
        dateFinAjout.setOnAction(e -> calculerPrixTotal());
        comboHebergementAjout.setOnAction(e -> calculerPrixTotal());

        dateDebutModif.setOnAction(e -> calculerPrixTotalModif());
        dateFinModif.setOnAction(e -> calculerPrixTotalModif());
        comboHebergementModif.setOnAction(e -> calculerPrixTotalModif());
    }

    private void ajouterBoutonsActions() {
        colActions.setCellFactory(param -> new TableCell<>() {
            private final Button btnModifier = new Button("✏️");
            private final Button btnSupprimer = new Button("🗑️");

            {
                btnModifier.getStyleClass().add("btn-primary");
                btnSupprimer.getStyleClass().add("btn-danger");
                btnModifier.setStyle("-fx-font-size: 14px; -fx-padding: 5 10;");
                btnSupprimer.setStyle("-fx-font-size: 14px; -fx-padding: 5 10;");

                btnModifier.setOnAction(e -> {
                    Reservation r = getTableView().getItems().get(getIndex());
                    comboReservationModif.setValue(r);
                    chargerReservationPourModification();
                });

                btnSupprimer.setOnAction(e -> {
                    Reservation r = getTableView().getItems().get(getIndex());
                    supprimerDepuisTable(r);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    javafx.scene.layout.HBox buttons = new javafx.scene.layout.HBox(5, btnModifier, btnSupprimer);
                    setGraphic(buttons);
                }
            }
        });
    }

    // ============================================
    // VALIDATION TAB AJOUT
    // ============================================
    private void setupValidationAjout() {
        // Validation Hébergement
        comboHebergementAjout.setOnAction(e -> {
            if (comboHebergementAjout.getValue() == null) {
                afficherErreur(lblErreurHebergementAjout, "Sélectionnez un hébergement");
            } else {
                cacherErreur(lblErreurHebergementAjout);
            }
        });

        // Validation Date Début
        dateDebutAjout.setOnAction(e -> {
            LocalDate debut = dateDebutAjout.getValue();
            if (debut == null) {
                afficherErreur(lblErreurDateDebutAjout, "Sélectionnez la date d'arrivée");
            } else if (debut.isBefore(LocalDate.now())) {
                afficherErreur(lblErreurDateDebutAjout, "La date ne peut pas être dans le passé");
            } else {
                cacherErreur(lblErreurDateDebutAjout);
                validerDates();
            }
        });

        // Validation Date Fin
        dateFinAjout.setOnAction(e -> {
            LocalDate fin = dateFinAjout.getValue();
            if (fin == null) {
                afficherErreur(lblErreurDateFinAjout, "Sélectionnez la date de départ");
            } else {
                cacherErreur(lblErreurDateFinAjout);
                validerDates();
            }
        });
    }

    private void validerDates() {
        LocalDate debut = dateDebutAjout.getValue();
        LocalDate fin = dateFinAjout.getValue();

        if (debut != null && fin != null) {
            if (fin.isBefore(debut) || fin.isEqual(debut)) {
                afficherErreur(lblErreurDateFinAjout, "La date de départ doit être après l'arrivée");
            } else {
                cacherErreur(lblErreurDateFinAjout);
            }
        }
    }

    // ============================================
    // VALIDATION TAB MODIFICATION
    // ============================================
    private void setupValidationModif() {
        comboHebergementModif.setOnAction(e -> {
            if (comboHebergementModif.getValue() == null) {
                afficherErreur(lblErreurHebergementModif, "Sélectionnez un hébergement");
            } else {
                cacherErreur(lblErreurHebergementModif);
            }
        });

        dateDebutModif.setOnAction(e -> {
            LocalDate debut = dateDebutModif.getValue();
            if (debut == null) {
                afficherErreur(lblErreurDateDebutModif, "Sélectionnez la date d'arrivée");
            } else if (debut.isBefore(LocalDate.now())) {
                afficherErreur(lblErreurDateDebutModif, "La date ne peut pas être dans le passé");
            } else {
                cacherErreur(lblErreurDateDebutModif);
                validerDatesModif();
            }
        });

        dateFinModif.setOnAction(e -> {
            LocalDate fin = dateFinModif.getValue();
            if (fin == null) {
                afficherErreur(lblErreurDateFinModif, "Sélectionnez la date de départ");
            } else {
                cacherErreur(lblErreurDateFinModif);
                validerDatesModif();
            }
        });
    }

    private void validerDatesModif() {
        LocalDate debut = dateDebutModif.getValue();
        LocalDate fin = dateFinModif.getValue();

        if (debut != null && fin != null) {
            if (fin.isBefore(debut) || fin.isEqual(debut)) {
                afficherErreur(lblErreurDateFinModif, "La date de départ doit être après l'arrivée");
            } else {
                cacherErreur(lblErreurDateFinModif);
            }
        }
    }

    // ============================================
    // CALCUL PRIX TOTAL
    // ============================================
    private void calculerPrixTotal() {
        if (comboHebergementAjout.getValue() != null &&
                dateDebutAjout.getValue() != null &&
                dateFinAjout.getValue() != null) {

            LocalDate debut = dateDebutAjout.getValue();
            LocalDate fin = dateFinAjout.getValue();

            if (fin.isAfter(debut)) {
                long nuits = java.time.temporal.ChronoUnit.DAYS.between(debut, fin);
                double prixNuit = Double.parseDouble(comboHebergementAjout.getValue().getPrix());
                double total = nuits * prixNuit;

                if (lblPrixTotal != null) {
                    lblPrixTotal.setText(String.format("Total: %.2f DT (%d nuits × %.2f DT)",
                            total, nuits, prixNuit));
                    lblPrixTotal.setStyle("-fx-text-fill: #0B7A8F; -fx-font-weight: bold; -fx-font-size: 16px;");
                }
            }
        }
    }

    private void calculerPrixTotalModif() {
        if (comboHebergementModif.getValue() != null &&
                dateDebutModif.getValue() != null &&
                dateFinModif.getValue() != null) {

            LocalDate debut = dateDebutModif.getValue();
            LocalDate fin = dateFinModif.getValue();

            if (fin.isAfter(debut)) {
                long nuits = java.time.temporal.ChronoUnit.DAYS.between(debut, fin);
                double prixNuit = Double.parseDouble(comboHebergementModif.getValue().getPrix());
                double total = nuits * prixNuit;

                if (lblPrixTotalModif != null) {
                    lblPrixTotalModif.setText(String.format("Total: %.2f DT (%d nuits × %.2f DT)",
                            total, nuits, prixNuit));
                    lblPrixTotalModif.setStyle("-fx-text-fill: #0B7A8F; -fx-font-weight: bold; -fx-font-size: 16px;");
                }
            }
        }
    }

    // ============================================
    // MÉTHODES UTILITAIRES
    // ============================================
    private void afficherErreur(Label label, String message) {
        if (label != null) {
            label.setText("⚠️ " + message);
            label.setManaged(true);
            label.setVisible(true);
        }
    }

    private void cacherErreur(Label label) {
        if (label != null) {
            label.setManaged(false);
            label.setVisible(false);
        }
    }

    private void afficherMessage(Label label, String message, boolean success) {
        if (label != null) {
            label.setText(success ? "✓ " + message : "✗ " + message);
            label.setStyle(success ?
                    "-fx-text-fill: #10b981; -fx-background-color: #d1fae5; -fx-padding: 10; -fx-background-radius: 5;" :
                    "-fx-text-fill: #ef4444; -fx-background-color: #fee2e2; -fx-padding: 10; -fx-background-radius: 5;");
            label.setManaged(true);
            label.setVisible(true);
        }
    }

    // ============================================
    // CRUD OPERATIONS
    // ============================================
    private void chargerHebergements() {
        hebergementList.clear();
        hebergementList.addAll(hebergementService.afficherHebergements());

        comboHebergementAjout.setItems(hebergementList);
        comboHebergementModif.setItems(hebergementList);

        ObservableList<Hebergement> hebergementsFiltres = FXCollections.observableArrayList();
        hebergementsFiltres.add(null); // Option "Tous"
        hebergementsFiltres.addAll(hebergementList);
        comboFiltreHebergement.setItems(hebergementsFiltres);
    }

    private void chargerReservations() {
        reservationList.clear();
        reservationList.addAll(reservationService.afficherReservations());
        tableReservation.setItems(reservationList);

        comboReservationModif.setItems(FXCollections.observableArrayList(reservationList));
        comboReservationSuppr.setItems(FXCollections.observableArrayList(reservationList));
    }

    private void filtrerReservations() {
        String recherche = txtRechercheList.getText().toLowerCase();
        Hebergement hebergementFiltre = comboFiltreHebergement.getValue();
        LocalDate debutFiltre = dateFiltreDebut.getValue();
        LocalDate finFiltre = dateFiltreFin.getValue();

        ObservableList<Reservation> filtered = FXCollections.observableArrayList();

        for (Reservation r : reservationList) {
            boolean matchRecherche = recherche.isEmpty() ||
                    String.valueOf(r.getId()).contains(recherche) ||
                    String.valueOf(r.getIdHebergement()).contains(recherche);

            boolean matchHebergement = hebergementFiltre == null ||
                    r.getIdHebergement() == hebergementFiltre.getId();

            boolean matchDates = true;
            if (debutFiltre != null) {
                matchDates = !r.getDateDebut().toLocalDate().isBefore(debutFiltre);
            }
            if (finFiltre != null && matchDates) {
                matchDates = !r.getDateFin().toLocalDate().isAfter(finFiltre);
            }

            if (matchRecherche && matchHebergement && matchDates) {
                filtered.add(r);
            }
        }

        tableReservation.setItems(filtered);
    }

    @FXML
    private void resetFiltres() {
        txtRechercheList.clear();
        comboFiltreHebergement.setValue(null);
        dateFiltreDebut.setValue(null);
        dateFiltreFin.setValue(null);
        tableReservation.setItems(reservationList);
    }

    @FXML
    private void ajouterReservation() {
        // Validation finale
        if (!validerFormulaireAjout()) {
            afficherMessage(lblMessageAjout, "Veuillez corriger les erreurs", false);
            return;
        }

        Date debut = Date.valueOf(dateDebutAjout.getValue());
        Date fin = Date.valueOf(dateFinAjout.getValue());

        // Vérifier disponibilité
        if (!reservationService.verifierDisponibilite(
                comboHebergementAjout.getValue().getId(), debut, fin)) {
            afficherMessage(lblMessageAjout,
                    "Cet hébergement n'est pas disponible pour ces dates", false);
            return;
        }

        Reservation reservation = new Reservation(
                comboHebergementAjout.getValue().getId(),
                debut,
                fin,
                spinnerPersonnesAjout.getValue()
        );

        reservationService.ajouterReservation(reservation);
        chargerReservations();
        resetFormulaireAjout();
        afficherMessage(lblMessageAjout, "Réservation ajoutée avec succès!", true);
    }

    private boolean validerFormulaireAjout() {
        boolean valid = true;

        if (comboHebergementAjout.getValue() == null) {
            afficherErreur(lblErreurHebergementAjout, "Sélectionnez un hébergement");
            valid = false;
        }

        LocalDate debut = dateDebutAjout.getValue();
        LocalDate fin = dateFinAjout.getValue();

        if (debut == null) {
            afficherErreur(lblErreurDateDebutAjout, "Sélectionnez la date d'arrivée");
            valid = false;
        } else if (debut.isBefore(LocalDate.now())) {
            afficherErreur(lblErreurDateDebutAjout, "La date ne peut pas être dans le passé");
            valid = false;
        }

        if (fin == null) {
            afficherErreur(lblErreurDateFinAjout, "Sélectionnez la date de départ");
            valid = false;
        } else if (debut != null && (fin.isBefore(debut) || fin.isEqual(debut))) {
            afficherErreur(lblErreurDateFinAjout, "La date de départ doit être après l'arrivée");
            valid = false;
        }

        return valid;
    }

    @FXML
    private void resetFormulaireAjout() {
        comboHebergementAjout.setValue(null);
        dateDebutAjout.setValue(null);
        dateFinAjout.setValue(null);
        spinnerPersonnesAjout.getValueFactory().setValue(2);

        if (lblPrixTotal != null) {
            lblPrixTotal.setText("");
        }

        cacherErreur(lblErreurHebergementAjout);
        cacherErreur(lblErreurDateDebutAjout);
        cacherErreur(lblErreurDateFinAjout);
        cacherErreur(lblErreurPersonnesAjout);

        if (lblMessageAjout != null) {
            lblMessageAjout.setManaged(false);
            lblMessageAjout.setVisible(false);
        }
    }

    private void chargerReservationPourModification() {
        Reservation r = comboReservationModif.getValue();
        if (r != null) {
            // Trouver l'hébergement correspondant
            for (Hebergement h : hebergementList) {
                if (h.getId() == r.getIdHebergement()) {
                    comboHebergementModif.setValue(h);
                    break;
                }
            }

            dateDebutModif.setValue(r.getDateDebut().toLocalDate());
            dateFinModif.setValue(r.getDateFin().toLocalDate());
            spinnerPersonnesModif.getValueFactory().setValue(r.getNbPersonnes());

            calculerPrixTotalModif();
        }
    }

    @FXML
    private void modifierReservation() {
        Reservation r = comboReservationModif.getValue();
        if (r == null) {
            afficherMessage(lblMessageModif, "Sélectionnez une réservation", false);
            return;
        }

        if (!validerFormulaireModif()) {
            afficherMessage(lblMessageModif, "Veuillez corriger les erreurs", false);
            return;
        }

        r.setIdHebergement(comboHebergementModif.getValue().getId());
        r.setDateDebut(Date.valueOf(dateDebutModif.getValue()));
        r.setDateFin(Date.valueOf(dateFinModif.getValue()));
        r.setNbPersonnes(spinnerPersonnesModif.getValue());

        reservationService.modifierReservation(r);
        chargerReservations();
        afficherMessage(lblMessageModif, "Réservation modifiée avec succès!", true);
    }

    private boolean validerFormulaireModif() {
        boolean valid = true;

        if (comboHebergementModif.getValue() == null) {
            afficherErreur(lblErreurHebergementModif, "Sélectionnez un hébergement");
            valid = false;
        }

        LocalDate debut = dateDebutModif.getValue();
        LocalDate fin = dateFinModif.getValue();

        if (debut == null) {
            afficherErreur(lblErreurDateDebutModif, "Sélectionnez la date d'arrivée");
            valid = false;
        }

        if (fin == null) {
            afficherErreur(lblErreurDateFinModif, "Sélectionnez la date de départ");
            valid = false;
        } else if (debut != null && (fin.isBefore(debut) || fin.isEqual(debut))) {
            afficherErreur(lblErreurDateFinModif, "La date de départ doit être après l'arrivée");
            valid = false;
        }

        return valid;
    }

    @FXML
    private void annulerModification() {
        comboReservationModif.setValue(null);
        comboHebergementModif.setValue(null);
        dateDebutModif.setValue(null);
        dateFinModif.setValue(null);
        spinnerPersonnesModif.getValueFactory().setValue(2);

        if (lblPrixTotalModif != null) {
            lblPrixTotalModif.setText("");
        }

        cacherErreur(lblErreurHebergementModif);
        cacherErreur(lblErreurDateDebutModif);
        cacherErreur(lblErreurDateFinModif);
        cacherErreur(lblErreurPersonnesModif);

        if (lblMessageModif != null) {
            lblMessageModif.setManaged(false);
            lblMessageModif.setVisible(false);
        }
    }

    private void afficherDetailsSuppr() {
        Reservation r = comboReservationSuppr.getValue();
        if (r != null && detailsSuppressionBox != null) {
            // Trouver l'hébergement
            Hebergement h = hebergementService.getHebergementById(r.getIdHebergement());

            lblHebergementSuppr.setText(h != null ? h.getNom() : "ID: " + r.getIdHebergement());
            lblDateDebutSuppr.setText(r.getDateDebut().toString());
            lblDateFinSuppr.setText(r.getDateFin().toString());
            lblPersonnesSuppr.setText(String.valueOf(r.getNbPersonnes()));

            long nuits = java.time.temporal.ChronoUnit.DAYS.between(
                    r.getDateDebut().toLocalDate(), r.getDateFin().toLocalDate());
            lblDureeSuppr.setText(nuits + " nuits");

            detailsSuppressionBox.setManaged(true);
            detailsSuppressionBox.setVisible(true);
        }
    }

    @FXML
    private void supprimerReservation() {
        Reservation r = comboReservationSuppr.getValue();
        if (r == null) {
            afficherMessage(lblMessageSuppr, "Sélectionnez une réservation", false);
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation");
        alert.setHeaderText("Supprimer la réservation");
        alert.setContentText("Êtes-vous sûr de vouloir supprimer cette réservation ?");

        if (alert.showAndWait().get() == ButtonType.OK) {
            reservationService.supprimerReservation(r.getId());
            chargerReservations();
            comboReservationSuppr.setValue(null);

            if (detailsSuppressionBox != null) {
                detailsSuppressionBox.setManaged(false);
                detailsSuppressionBox.setVisible(false);
            }

            afficherMessage(lblMessageSuppr, "Réservation supprimée avec succès!", true);
        }
    }

    private void supprimerDepuisTable(Reservation r) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation");
        alert.setHeaderText("Supprimer la réservation");
        alert.setContentText("Êtes-vous sûr de vouloir supprimer cette réservation ?");

        if (alert.showAndWait().get() == ButtonType.OK) {
            reservationService.supprimerReservation(r.getId());
            chargerReservations();
        }
    }
}
