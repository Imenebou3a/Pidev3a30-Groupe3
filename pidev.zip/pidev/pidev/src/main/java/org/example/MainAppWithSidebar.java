package org.example;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;

public class MainAppWithSidebar extends Application {

    private BorderPane root;
    private Scene scene;
    private VBox sidebar;
    private Button btnDashboard, btnHebergements, btnReservations, btnFrontOffice;
    
    // Constantes pour les dimensions
    private static final double SIDEBAR_WIDTH = 280;
    private static final double WINDOW_WIDTH = 1400;
    private static final double WINDOW_HEIGHT = 800;
    private static final String APP_TITLE = "Lammetna - Gestion des Hébergements et Réservations";
    private static final String APP_VERSION = "Version 1.0";
    private static final String COPYRIGHT = "© 2026 Lammetna";

    @Override
    public void start(Stage primaryStage) {
        try {
            initializeUI(primaryStage);
        } catch (Exception e) {
            showError("Erreur d'initialisation", "Impossible de démarrer l'application: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void initializeUI(Stage primaryStage) {
        root = new BorderPane();
        
        // Créer la sidebar
        createSidebar();
        root.setLeft(sidebar);

        // Démarrer sur Hébergements (Dashboard a des problèmes)
        showHebergementsManagement();
        setActiveButton(btnHebergements);
        
        // Créer la scène avec le CSS
        scene = new Scene(root, WINDOW_WIDTH, WINDOW_HEIGHT);
        loadStylesheets();

        primaryStage.setTitle(APP_TITLE);
        primaryStage.setScene(scene);
        primaryStage.setMaximized(true);
        primaryStage.show();
    }
    
    private void loadStylesheets() {
        try {
            String mainCss = getClass().getResource("/styles/main-theme.css").toExternalForm();
            String animCss = getClass().getResource("/styles/animations.css").toExternalForm();
            scene.getStylesheets().addAll(mainCss, animCss);
        } catch (Exception e) {
            System.err.println("⚠️ Impossible de charger le CSS: " + e.getMessage());
        }
    }

    private void createSidebar() {
        sidebar = new VBox();
        sidebar.getStyleClass().addAll("sidebar", "slide-in-left");
        sidebar.setPrefWidth(SIDEBAR_WIDTH);
        sidebar.setMinWidth(SIDEBAR_WIDTH);
        sidebar.setMaxWidth(SIDEBAR_WIDTH);

        // Header avec logo
        VBox header = createSidebarHeader();

        // Menu
        VBox menu = createSidebarMenu();

        // Spacer
        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);

        // Footer
        VBox footer = createSidebarFooter();

        sidebar.getChildren().addAll(header, menu, spacer, footer);
    }
    
    private VBox createSidebarHeader() {
        VBox header = new VBox(15);
        header.getStyleClass().addAll("sidebar-header", "fade-in");
        header.setAlignment(Pos.CENTER);

        // Logo
        Label logoText = new Label("🏝️");
        logoText.setStyle("-fx-font-size: 64px;");

        Label title = new Label("Lammetna");
        title.getStyleClass().add("sidebar-title");

        Label subtitle = new Label("STAYS • EXPERIENCES • EVENTS");
        subtitle.getStyleClass().add("sidebar-subtitle");

        header.getChildren().addAll(logoText, title, subtitle);
        return header;
    }
    
    private VBox createSidebarMenu() {
        VBox menu = new VBox(8);
        menu.getStyleClass().add("sidebar-menu");
        menu.setPadding(new Insets(20, 0, 0, 0));

        // Boutons du menu
        btnDashboard = createSidebarButton("📊", "Dashboard");
        btnDashboard.setOnAction(e -> {
            setActiveButton(btnDashboard);
            showDashboard();
        });

        btnHebergements = createSidebarButton("🏡", "Hébergements");
        btnHebergements.setOnAction(e -> {
            setActiveButton(btnHebergements);
            showHebergementsManagement();
        });

        btnReservations = createSidebarButton("📅", "Réservations");
        btnReservations.setOnAction(e -> {
            setActiveButton(btnReservations);
            showReservationsManagement();
        });

        Separator sep1 = new Separator();
        sep1.setStyle("-fx-background-color: rgba(255,255,255,0.2);");

        btnFrontOffice = createSidebarButton("🏖️", "Espace Client");
        btnFrontOffice.setOnAction(e -> {
            setActiveButton(btnFrontOffice);
            showFrontOffice();
        });

        menu.getChildren().addAll(
            btnDashboard,
            btnHebergements,
            btnReservations,
            sep1,
            btnFrontOffice
        );
        
        return menu;
    }
    
    private VBox createSidebarFooter() {
        VBox footer = new VBox(5);
        footer.getStyleClass().add("sidebar-footer");
        footer.setAlignment(Pos.CENTER);

        Label footerText = new Label(COPYRIGHT);
        footerText.getStyleClass().add("sidebar-footer-text");

        Label version = new Label(APP_VERSION);
        version.getStyleClass().add("sidebar-footer-text");

        footer.getChildren().addAll(footerText, version);
        return footer;
    }

    private Button createSidebarButton(String icon, String text) {
        Button btn = new Button();
        btn.getStyleClass().addAll("sidebar-button", "smooth-transition", "lift-on-hover");
        btn.setMaxWidth(Double.MAX_VALUE);

        HBox content = new HBox(12);
        content.setAlignment(Pos.CENTER_LEFT);

        Label iconLabel = new Label(icon);
        iconLabel.getStyleClass().add("sidebar-icon");

        Label textLabel = new Label(text);
        textLabel.setStyle("-fx-font-size: 15px;");

        content.getChildren().addAll(iconLabel, textLabel);
        btn.setGraphic(content);

        return btn;
    }

    private void setActiveButton(Button activeBtn) {
        btnDashboard.getStyleClass().remove("active");
        btnHebergements.getStyleClass().remove("active");
        btnReservations.getStyleClass().remove("active");
        btnFrontOffice.getStyleClass().remove("active");

        activeBtn.getStyleClass().add("active");
    }

    private VBox createStatCard(String icon, String value, String label, String badge) {
        VBox card = new VBox(15);
        card.getStyleClass().addAll("stat-card", "fade-in", "lift-on-hover");
        card.setAlignment(Pos.CENTER);
        card.setPrefWidth(280);
        card.setPrefHeight(200);

        Label iconLabel = new Label(icon);
        iconLabel.getStyleClass().add("stat-icon");

        Label valueLabel = new Label(value);
        valueLabel.getStyleClass().add("stat-value");

        Label labelText = new Label(label);
        labelText.getStyleClass().add("stat-label");

        Label badgeLabel = new Label(badge);
        badgeLabel.getStyleClass().addAll("stat-badge", "pulse");

        card.getChildren().addAll(iconLabel, valueLabel, labelText, badgeLabel);

        return card;
    }

    private void showDashboard() {
        loadFXMLContent("/Backoffice/dashboard.fxml", "Erreur lors du chargement du dashboard");
    }

    private void showHebergementsManagement() {
        loadFXMLContentWithHeader(
            "/Backoffice/hebergement_back.fxml",
            "Gestion des Hébergements",
            "Créer, modifier et supprimer des hébergements",
            "Erreur lors du chargement des hébergements"
        );
    }

    private void showReservationsManagement() {
        loadFXMLContentWithHeader(
            "/Backoffice/reservation_back.fxml",
            "Gestion des Réservations",
            "Afficher, modifier et supprimer des réservations",
            "Erreur lors du chargement des réservations"
        );
    }

    private void showFrontOffice() {
        loadFXMLContentWithHeader(
            "/Frontoffice/hebergement-front.fxml",
            "Espace Client",
            "Parcourir et réserver des hébergements",
            "Erreur lors du chargement de l'espace client"
        );
    }
    
    private void loadFXMLContent(String fxmlPath, String errorMessage) {
        try {
            BorderPane content = new BorderPane();
            content.getStyleClass().addAll("main-content", "fade-in");

            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            BorderPane loadedPane = loader.load();
            content.setCenter(loadedPane);

            root.setCenter(content);
        } catch (Exception e) {
            showError(errorMessage, e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void loadFXMLContentWithHeader(String fxmlPath, String title, String subtitle, String errorMessage) {
        try {
            BorderPane content = new BorderPane();
            content.getStyleClass().addAll("main-content", "fade-in");

            HBox header = createContentHeader(title, subtitle);
            content.setTop(header);

            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            BorderPane loadedPane = loader.load();
            content.setCenter(loadedPane);

            root.setCenter(content);
        } catch (Exception e) {
            showError(errorMessage, e.getMessage());
            e.printStackTrace();
        }
    }

    private HBox createContentHeader(String title, String subtitle) {
        HBox header = new HBox();
        header.getStyleClass().add("content-header");
        header.setPadding(new Insets(25, 40, 25, 40));

        VBox titleBox = new VBox(5);
        Label titleLabel = new Label(title);
        titleLabel.getStyleClass().add("content-title");

        Label subtitleLabel = new Label(subtitle);
        subtitleLabel.getStyleClass().add("content-subtitle");

        titleBox.getChildren().addAll(titleLabel, subtitleLabel);
        header.getChildren().add(titleBox);

        return header;
    }

    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
