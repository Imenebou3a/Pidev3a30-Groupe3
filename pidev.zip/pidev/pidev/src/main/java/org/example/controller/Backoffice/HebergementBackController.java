package org.example.controller.Backoffice;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import org.example.entities.Hebergement;
import org.example.services.HebergementService;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class HebergementBackController {

    // ============================================
    // TAB 1: LISTE
    // ============================================
    @FXML
    private TextField txtRechercheList;
    @FXML
    private ComboBox<String> comboFiltreType;
    @FXML
    private TextField txtFiltrePrix;
    @FXML
    private TableView<Hebergement> tableHebergement;
    @FXML
    private TableColumn<Hebergement, Integer> colId;
    @FXML
    private TableColumn<Hebergement, String> colNom;
    @FXML
    private TableColumn<Hebergement, String> colType;
    @FXML
    private TableColumn<Hebergement, String> colAdresse;
    @FXML
    private TableColumn<Hebergement, String> colPrix;
    @FXML
    private TableColumn<Hebergement, Void> colActions;

    // ============================================
    // TAB 2: AJOUTER
    // ============================================
    @FXML
    private TextField txtNomAjout;
    @FXML
    private ComboBox<String> comboTypeAjout;
    @FXML
    private TextField txtAdresseAjout;
    @FXML
    private TextField txtPrixAjout;
    @FXML
    private Label lblErreurNomAjout;
    @FXML
    private Label lblErreurTypeAjout;
    @FXML
    private Label lblErreurAdresseAjout;
    @FXML
    private Label lblErreurPrixAjout;
    @FXML
    private Label lblMessageAjout;
    @FXML
    private Button btnChoisirImageAjout;
    @FXML
    private Label lblNomFichierAjout;
    @FXML
    private ImageView imgPreviewAjout;

    // ============================================
    // TAB 3: MODIFIER
    // ============================================
    @FXML
    private ComboBox<Hebergement> comboHebergementModif;
    @FXML
    private TextField txtNomModif;
    @FXML
    private ComboBox<String> comboTypeModif;
    @FXML
    private TextField txtAdresseModif;
    @FXML
    private TextField txtPrixModif;
    @FXML
    private Label lblErreurNomModif;
    @FXML
    private Label lblErreurTypeModif;
    @FXML
    private Label lblErreurAdresseModif;
    @FXML
    private Label lblErreurPrixModif;
    @FXML
    private Label lblMessageModif;
    @FXML
    private Button btnChoisirImageModif;
    @FXML
    private Label lblNomFichierModif;
    @FXML
    private ImageView imgPreviewModif;

    // ============================================
    // TAB 4: SUPPRIMER
    // ============================================
    @FXML
    private ComboBox<Hebergement> comboHebergementSuppr;
    @FXML
    private javafx.scene.layout.VBox detailsSuppressionBox;
    @FXML
    private Label lblNomSuppr;
    @FXML
    private Label lblTypeSuppr;
    @FXML
    private Label lblAdresseSuppr;
    @FXML
    private Label lblPrixSuppr;
    @FXML
    private Label lblMessageSuppr;

    private HebergementService hebergementService;
    private ObservableList<Hebergement> hebergementList;

    // Chemin de l'image sélectionnée pour l'ajout
    private String imagePathAjout;

    @FXML
    public void initialize() {
        hebergementService = new HebergementService();
        hebergementList = FXCollections.observableArrayList();

        // Configuration des colonnes du tableau
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        colType.setCellValueFactory(new PropertyValueFactory<>("type"));
        colAdresse.setCellValueFactory(new PropertyValueFactory<>("adresse"));
        colPrix.setCellValueFactory(new PropertyValueFactory<>("prix"));

        // Ajouter boutons actions dans la colonne
        ajouterBoutonsActions();

        // Charger les données
        chargerHebergements();

        // Configuration des ComboBox types
        ObservableList<String> types = FXCollections.observableArrayList(
                "Villa", "Appartement", "Maison d'hôtes", "Studio", "Riad"
        );
        comboTypeAjout.setItems(types);
        comboTypeModif.setItems(types);

        // Filtre type pour la liste
        ObservableList<String> typesFiltre = FXCollections.observableArrayList("Tous");
        typesFiltre.addAll(types);
        comboFiltreType.setItems(typesFiltre);
        comboFiltreType.setValue("Tous");

        // Listeners recherche et filtres
        txtRechercheList.textProperty().addListener((obs, old, newVal) -> filtrerHebergements());
        comboFiltreType.setOnAction(e -> filtrerHebergements());
        txtFiltrePrix.textProperty().addListener((obs, old, newVal) -> filtrerHebergements());

        // Validation en temps réel - TAB AJOUT
        setupValidationAjout();

        // Validation en temps réel - TAB MODIFICATION
        setupValidationModif();

        // Listeners pour les ComboBox de sélection
        comboHebergementModif.setOnAction(e -> chargerHebergementPourModification());
        comboHebergementSuppr.setOnAction(e -> afficherDetailsSuppr());
    }

    private void ajouterBoutonsActions() {
        colActions.setCellFactory(param -> new TableCell<>() {
            private final Button btnModifier = new Button("✏️");
            private final Button btnSupprimer = new Button("🗑️");

            {
                btnModifier.getStyleClass().add("btn-primary");
                btnSupprimer.getStyleClass().add("btn-danger");
                btnModifier.setStyle("-fx-font-size: 14px; -fx-padding: 5 10;");
                btnSupprimer.setStyle("-fx-font-size: 14px; -fx-padding: 5 10;");

                btnModifier.setOnAction(e -> {
                    Hebergement h = getTableView().getItems().get(getIndex());
                    comboHebergementModif.setValue(h);
                    chargerHebergementPourModification();
                });

                btnSupprimer.setOnAction(e -> {
                    Hebergement h = getTableView().getItems().get(getIndex());
                    supprimerDepuisTable(h);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    javafx.scene.layout.HBox buttons = new javafx.scene.layout.HBox(5, btnModifier, btnSupprimer);
                    setGraphic(buttons);
                }
            }
        });
    }

    // ============================================
    // VALIDATION TAB AJOUT
    // ============================================
    private void setupValidationAjout() {
        // Validation Nom
        txtNomAjout.textProperty().addListener((obs, old, newVal) -> {
            if (newVal == null || newVal.trim().isEmpty()) {
                afficherErreur(lblErreurNomAjout, "Le nom est obligatoire");
                txtNomAjout.setStyle("-fx-border-color: #ef4444; -fx-border-width: 2px;");
            } else if (newVal.length() < 3) {
                afficherErreur(lblErreurNomAjout, "Minimum 3 caractères");
                txtNomAjout.setStyle("-fx-border-color: #f59e0b; -fx-border-width: 2px;");
            } else if (!newVal.matches("[a-zA-ZÀ-ÿ0-9\\s'-]+")) {
                afficherErreur(lblErreurNomAjout, "Caractères invalides");
                txtNomAjout.setStyle("-fx-border-color: #ef4444; -fx-border-width: 2px;");
            } else {
                cacherErreur(lblErreurNomAjout);
                txtNomAjout.setStyle("-fx-border-color: #10b981; -fx-border-width: 2px;");
            }
        });

        // Validation Prix
        txtPrixAjout.textProperty().addListener((obs, old, newVal) -> {
            if (newVal == null || newVal.trim().isEmpty()) {
                afficherErreur(lblErreurPrixAjout, "Le prix est obligatoire");
                txtPrixAjout.setStyle("-fx-border-color: #ef4444; -fx-border-width: 2px;");
            } else {
                try {
                    double prix = Double.parseDouble(newVal);
                    if (prix <= 0) {
                        afficherErreur(lblErreurPrixAjout, "Le prix doit être positif");
                        txtPrixAjout.setStyle("-fx-border-color: #ef4444; -fx-border-width: 2px;");
                    } else if (prix > 10000) {
                        afficherErreur(lblErreurPrixAjout, "Prix très élevé");
                        txtPrixAjout.setStyle("-fx-border-color: #f59e0b; -fx-border-width: 2px;");
                    } else {
                        cacherErreur(lblErreurPrixAjout);
                        txtPrixAjout.setStyle("-fx-border-color: #10b981; -fx-border-width: 2px;");
                    }
                } catch (NumberFormatException e) {
                    afficherErreur(lblErreurPrixAjout, "Format invalide");
                    txtPrixAjout.setStyle("-fx-border-color: #ef4444; -fx-border-width: 2px;");
                }
            }
        });

        // Validation Adresse
        txtAdresseAjout.textProperty().addListener((obs, old, newVal) -> {
            if (newVal == null || newVal.trim().isEmpty()) {
                afficherErreur(lblErreurAdresseAjout, "L'adresse est obligatoire");
                txtAdresseAjout.setStyle("-fx-border-color: #ef4444; -fx-border-width: 2px;");
            } else if (newVal.length() < 5) {
                afficherErreur(lblErreurAdresseAjout, "Adresse trop courte");
                txtAdresseAjout.setStyle("-fx-border-color: #f59e0b; -fx-border-width: 2px;");
            } else {
                cacherErreur(lblErreurAdresseAjout);
                txtAdresseAjout.setStyle("-fx-border-color: #10b981; -fx-border-width: 2px;");
            }
        });

        // Validation Type
        comboTypeAjout.setOnAction(e -> {
            if (comboTypeAjout.getValue() == null) {
                afficherErreur(lblErreurTypeAjout, "Sélectionnez un type");
            } else {
                cacherErreur(lblErreurTypeAjout);
            }
        });
    }

    // ============================================
    // VALIDATION TAB MODIFICATION
    // ============================================
    private void setupValidationModif() {
        txtNomModif.textProperty().addListener((obs, old, newVal) -> {
            if (newVal == null || newVal.trim().isEmpty()) {
                afficherErreur(lblErreurNomModif, "Le nom est obligatoire");
                txtNomModif.setStyle("-fx-border-color: #ef4444; -fx-border-width: 2px;");
            } else if (newVal.length() < 3) {
                afficherErreur(lblErreurNomModif, "Minimum 3 caractères");
                txtNomModif.setStyle("-fx-border-color: #f59e0b; -fx-border-width: 2px;");
            } else {
                cacherErreur(lblErreurNomModif);
                txtNomModif.setStyle("-fx-border-color: #10b981; -fx-border-width: 2px;");
            }
        });

        txtPrixModif.textProperty().addListener((obs, old, newVal) -> {
            if (newVal == null || newVal.trim().isEmpty()) {
                afficherErreur(lblErreurPrixModif, "Le prix est obligatoire");
                txtPrixModif.setStyle("-fx-border-color: #ef4444; -fx-border-width: 2px;");
            } else {
                try {
                    double prix = Double.parseDouble(newVal);
                    if (prix <= 0) {
                        afficherErreur(lblErreurPrixModif, "Le prix doit être positif");
                        txtPrixModif.setStyle("-fx-border-color: #ef4444; -fx-border-width: 2px;");
                    } else {
                        cacherErreur(lblErreurPrixModif);
                        txtPrixModif.setStyle("-fx-border-color: #10b981; -fx-border-width: 2px;");
                    }
                } catch (NumberFormatException e) {
                    afficherErreur(lblErreurPrixModif, "Format invalide");
                    txtPrixModif.setStyle("-fx-border-color: #ef4444; -fx-border-width: 2px;");
                }
            }
        });

        txtAdresseModif.textProperty().addListener((obs, old, newVal) -> {
            if (newVal == null || newVal.trim().isEmpty()) {
                afficherErreur(lblErreurAdresseModif, "L'adresse est obligatoire");
                txtAdresseModif.setStyle("-fx-border-color: #ef4444; -fx-border-width: 2px;");
            } else {
                cacherErreur(lblErreurAdresseModif);
                txtAdresseModif.setStyle("-fx-border-color: #10b981; -fx-border-width: 2px;");
            }
        });
    }

    // ============================================
    // MÉTHODES UTILITAIRES
    // ============================================
    private void afficherErreur(Label label, String message) {
        if (label != null) {
            label.setText("⚠️ " + message);
            label.setManaged(true);
            label.setVisible(true);
        }
    }

    private void cacherErreur(Label label) {
        if (label != null) {
            label.setManaged(false);
            label.setVisible(false);
        }
    }

    private void afficherMessage(Label label, String message, boolean success) {
        if (label != null) {
            label.setText(success ? "✓ " + message : "✗ " + message);
            label.setStyle(success ?
                    "-fx-text-fill: #10b981; -fx-background-color: #d1fae5; -fx-padding: 10; -fx-background-radius: 5;" :
                    "-fx-text-fill: #ef4444; -fx-background-color: #fee2e2; -fx-padding: 10; -fx-background-radius: 5;");
            label.setManaged(true);
            label.setVisible(true);
        }
    }

    // ============================================
    // CRUD OPERATIONS
    // ============================================
    private void chargerHebergements() {
        hebergementList.clear();
        hebergementList.addAll(hebergementService.afficherHebergements());
        tableHebergement.setItems(hebergementList);

        // Mettre à jour les ComboBox
        comboHebergementModif.setItems(FXCollections.observableArrayList(hebergementList));
        comboHebergementSuppr.setItems(FXCollections.observableArrayList(hebergementList));
    }

    private void filtrerHebergements() {
        String recherche = txtRechercheList.getText().toLowerCase();
        String typeFiltre = comboFiltreType.getValue();
        String prixMax = txtFiltrePrix.getText();

        ObservableList<Hebergement> filtered = FXCollections.observableArrayList();

        for (Hebergement h : hebergementList) {
            boolean matchRecherche = recherche.isEmpty() ||
                    h.getNom().toLowerCase().contains(recherche) ||
                    h.getAdresse().toLowerCase().contains(recherche);

            boolean matchType = typeFiltre == null || typeFiltre.equals("Tous") ||
                    h.getType().equals(typeFiltre);

            boolean matchPrix = true;
            if (!prixMax.isEmpty()) {
                try {
                    double max = Double.parseDouble(prixMax);
                    matchPrix = Double.parseDouble(h.getPrix()) <= max;
                } catch (NumberFormatException e) {
                    matchPrix = true;
                }
            }

            if (matchRecherche && matchType && matchPrix) {
                filtered.add(h);
            }
        }

        tableHebergement.setItems(filtered);
    }

    @FXML
    private void choisirImageAjout() {
        File file = ouvrirFileChooserImage(btnChoisirImageAjout);
        if (file != null) {
            try {
                String pathStored = copierImageDansUploads(file);
                imagePathAjout = pathStored;
                lblNomFichierAjout.setText(file.getName());
                afficherPreviewImage(imgPreviewAjout, file.getAbsolutePath());
            } catch (IOException e) {
                afficherMessage(lblMessageAjout, "Erreur lors de la copie de l'image: " + e.getMessage(), false);
            }
        }
    }

    @FXML
    private void choisirImageModif() {
        File file = ouvrirFileChooserImage(btnChoisirImageModif);
        if (file != null) {
            try {
                String pathStored = copierImageDansUploads(file);
                Hebergement h = comboHebergementModif.getValue();
                if (h != null) {
                    h.setImagePath(pathStored);
                }
                lblNomFichierModif.setText(file.getName());
                afficherPreviewImage(imgPreviewModif, file.getAbsolutePath());
            } catch (IOException e) {
                afficherMessage(lblMessageModif, "Erreur lors de la copie de l'image: " + e.getMessage(), false);
            }
        }
    }

    private File ouvrirFileChooserImage(Node node) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Choisir une image");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Images", "*.png", "*.jpg", "*.jpeg", "*.gif", "*.bmp"),
                new FileChooser.ExtensionFilter("Tous les fichiers", "*.*")
        );
        return fileChooser.showOpenDialog(node != null ? node.getScene().getWindow() : null);
    }

    private String copierImageDansUploads(File sourceFile) throws IOException {
        Path uploadsDir = Paths.get("uploads", "hebergements");
        Files.createDirectories(uploadsDir);

        String extension = "";
        String name = sourceFile.getName();
        int i = name.lastIndexOf('.');
        if (i > 0) {
            extension = name.substring(i);
        }
        String newFileName = "hebergement_" + System.currentTimeMillis() + extension;
        Path destPath = uploadsDir.resolve(newFileName);
        Files.copy(sourceFile.toPath(), destPath, StandardCopyOption.REPLACE_EXISTING);

        return "uploads/hebergements/" + newFileName;
    }

    private void afficherPreviewImage(ImageView imageView, String path) {
        if (imageView != null && path != null) {
            try {
                File f = new File(path);
                if (f.exists()) {
                    imageView.setImage(new Image(f.toURI().toString()));
                    imageView.setVisible(true);
                    imageView.setManaged(true);
                }
            } catch (Exception e) {
                System.err.println("Erreur chargement preview: " + e.getMessage());
            }
        }
    }

    @FXML
    private void resetFiltres() {
        txtRechercheList.clear();
        comboFiltreType.setValue("Tous");
        txtFiltrePrix.clear();
        tableHebergement.setItems(hebergementList);
    }

    @FXML
    private void ajouterHebergement() {
        // Validation finale
        if (!validerFormulaireAjout()) {
            afficherMessage(lblMessageAjout, "Veuillez corriger les erreurs", false);
            return;
        }

        Hebergement hebergement = new Hebergement(
                txtNomAjout.getText().trim(),
                comboTypeAjout.getValue(),
                txtAdresseAjout.getText().trim(),
                txtPrixAjout.getText().trim(),
                imagePathAjout != null ? imagePathAjout : ""
        );

        hebergementService.ajouterHebergement(hebergement);
        chargerHebergements();
        resetFormulaireAjout();
        afficherMessage(lblMessageAjout, "Hébergement ajouté avec succès!", true);
    }

    private boolean validerFormulaireAjout() {
        boolean valid = true;

        if (txtNomAjout.getText() == null || txtNomAjout.getText().trim().length() < 3) {
            valid = false;
        }
        if (comboTypeAjout.getValue() == null) {
            afficherErreur(lblErreurTypeAjout, "Sélectionnez un type");
            valid = false;
        }
        if (txtAdresseAjout.getText() == null || txtAdresseAjout.getText().trim().length() < 5) {
            valid = false;
        }
        if (txtPrixAjout.getText() == null || txtPrixAjout.getText().trim().isEmpty()) {
            valid = false;
        } else {
            try {
                double prix = Double.parseDouble(txtPrixAjout.getText().trim());
                if (prix <= 0) valid = false;
            } catch (NumberFormatException e) {
                valid = false;
            }
        }

        return valid;
    }

    @FXML
    private void resetFormulaireAjout() {
        txtNomAjout.clear();
        comboTypeAjout.setValue(null);
        txtAdresseAjout.clear();
        txtPrixAjout.clear();
        imagePathAjout = null;
        lblNomFichierAjout.setText("Aucune image sélectionnée");
        imgPreviewAjout.setImage(null);
        imgPreviewAjout.setVisible(false);
        imgPreviewAjout.setManaged(false);

        txtNomAjout.setStyle("");
        txtAdresseAjout.setStyle("");
        txtPrixAjout.setStyle("");

        cacherErreur(lblErreurNomAjout);
        cacherErreur(lblErreurTypeAjout);
        cacherErreur(lblErreurAdresseAjout);
        cacherErreur(lblErreurPrixAjout);

        if (lblMessageAjout != null) {
            lblMessageAjout.setManaged(false);
            lblMessageAjout.setVisible(false);
        }
    }

    private void chargerHebergementPourModification() {
        Hebergement h = comboHebergementModif.getValue();
        if (h != null) {
            txtNomModif.setText(h.getNom());
            comboTypeModif.setValue(h.getType());
            txtAdresseModif.setText(h.getAdresse());
            txtPrixModif.setText(h.getPrix());
            // Charger l'image existante si présente
            String imgPath = h.getImagePath();
            if (imgPath != null && !imgPath.isEmpty()) {
                File imgFile = new File(imgPath);
                if (imgFile.exists()) {
                    lblNomFichierModif.setText(imgFile.getName());
                    afficherPreviewImage(imgPreviewModif, imgFile.getAbsolutePath());
                } else {
                    lblNomFichierModif.setText("Image existante (fichier non trouvé)");
                    imgPreviewModif.setVisible(false);
                    imgPreviewModif.setManaged(false);
                }
            } else {
                lblNomFichierModif.setText("Aucune image");
                imgPreviewModif.setImage(null);
                imgPreviewModif.setVisible(false);
                imgPreviewModif.setManaged(false);
            }
        }
    }

    @FXML
    private void modifierHebergement() {
        Hebergement h = comboHebergementModif.getValue();
        if (h == null) {
            afficherMessage(lblMessageModif, "Sélectionnez un hébergement", false);
            return;
        }

        if (!validerFormulaireModif()) {
            afficherMessage(lblMessageModif, "Veuillez corriger les erreurs", false);
            return;
        }

        h.setNom(txtNomModif.getText().trim());
        h.setType(comboTypeModif.getValue());
        h.setAdresse(txtAdresseModif.getText().trim());
        h.setPrix(txtPrixModif.getText().trim());

        hebergementService.modifierHebergement(h);
        chargerHebergements();
        afficherMessage(lblMessageModif, "Hébergement modifié avec succès!", true);
    }

    private boolean validerFormulaireModif() {
        boolean valid = true;

        if (txtNomModif.getText() == null || txtNomModif.getText().trim().length() < 3) {
            valid = false;
        }
        if (comboTypeModif.getValue() == null) {
            afficherErreur(lblErreurTypeModif, "Sélectionnez un type");
            valid = false;
        }
        if (txtAdresseModif.getText() == null || txtAdresseModif.getText().trim().length() < 5) {
            valid = false;
        }
        if (txtPrixModif.getText() == null || txtPrixModif.getText().trim().isEmpty()) {
            valid = false;
        } else {
            try {
                double prix = Double.parseDouble(txtPrixModif.getText().trim());
                if (prix <= 0) valid = false;
            } catch (NumberFormatException e) {
                valid = false;
            }
        }

        return valid;
    }

    @FXML
    private void annulerModification() {
        comboHebergementModif.setValue(null);
        txtNomModif.clear();
        comboTypeModif.setValue(null);
        txtAdresseModif.clear();
        txtPrixModif.clear();

        txtNomModif.setStyle("");
        txtAdresseModif.setStyle("");
        txtPrixModif.setStyle("");

        cacherErreur(lblErreurNomModif);
        cacherErreur(lblErreurTypeModif);
        cacherErreur(lblErreurAdresseModif);
        cacherErreur(lblErreurPrixModif);

        if (lblMessageModif != null) {
            lblMessageModif.setManaged(false);
            lblMessageModif.setVisible(false);
        }
    }

    private void afficherDetailsSuppr() {
        Hebergement h = comboHebergementSuppr.getValue();
        if (h != null && detailsSuppressionBox != null) {
            lblNomSuppr.setText(h.getNom());
            lblTypeSuppr.setText(h.getType());
            lblAdresseSuppr.setText(h.getAdresse());
            lblPrixSuppr.setText(h.getPrix() + " DT/nuit");

            detailsSuppressionBox.setManaged(true);
            detailsSuppressionBox.setVisible(true);
        }
    }

    @FXML
    private void supprimerHebergement() {
        Hebergement h = comboHebergementSuppr.getValue();
        if (h == null) {
            afficherMessage(lblMessageSuppr, "Sélectionnez un hébergement", false);
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation");
        alert.setHeaderText("Supprimer l'hébergement");
        alert.setContentText("Êtes-vous sûr de vouloir supprimer \"" + h.getNom() + "\" ?");

        if (alert.showAndWait().get() == ButtonType.OK) {
            hebergementService.supprimerHebergement(h.getId());
            chargerHebergements();
            comboHebergementSuppr.setValue(null);

            if (detailsSuppressionBox != null) {
                detailsSuppressionBox.setManaged(false);
                detailsSuppressionBox.setVisible(false);
            }

            afficherMessage(lblMessageSuppr, "Hébergement supprimé avec succès!", true);
        }
    }

    private void supprimerDepuisTable(Hebergement h) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation");
        alert.setHeaderText("Supprimer l'hébergement");
        alert.setContentText("Êtes-vous sûr de vouloir supprimer \"" + h.getNom() + "\" ?");

        if (alert.showAndWait().get() == ButtonType.OK) {
            hebergementService.supprimerHebergement(h.getId());
            chargerHebergements();
        }
    }
}
