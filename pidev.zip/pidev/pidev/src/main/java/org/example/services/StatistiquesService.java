package org.example.services;

import org.example.entities.Hebergement;
import org.example.entities.Reservation;

import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

public class StatistiquesService {

    private HebergementService hebergementService;
    private ReservationService reservationService;

    public StatistiquesService() {
        this.hebergementService = new HebergementService();
        this.reservationService = new ReservationService();
    }

    /**
     * Statistiques générales des hébergements
     */
    public Map<String, Object> getStatistiquesHebergements() {
        Map<String, Object> stats = new HashMap<>();
        List<Hebergement> hebergements = hebergementService.afficherHebergements();

        // Nombre total
        stats.put("total", hebergements.size());

        // Répartition par type
        Map<String, Long> parType = hebergements.stream()
                .collect(Collectors.groupingBy(Hebergement::getType, Collectors.counting()));
        stats.put("parType", parType);

        // Prix moyen
        double prixMoyen = hebergements.stream()
                .mapToDouble(h -> Double.parseDouble(h.getPrix()))
                .average()
                .orElse(0.0);
        stats.put("prixMoyen", prixMoyen);

        // Prix min et max
        double prixMin = hebergements.stream()
                .mapToDouble(h -> Double.parseDouble(h.getPrix()))
                .min()
                .orElse(0.0);
        double prixMax = hebergements.stream()
                .mapToDouble(h -> Double.parseDouble(h.getPrix()))
                .max()
                .orElse(0.0);
        stats.put("prixMin", prixMin);
        stats.put("prixMax", prixMax);

        // Type le plus populaire
        String typePlusPopulaire = parType.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse("N/A");
        stats.put("typePlusPopulaire", typePlusPopulaire);

        return stats;
    }

    /**
     * Statistiques générales des réservations
     */
    public Map<String, Object> getStatistiquesReservations() {
        Map<String, Object> stats = new HashMap<>();
        List<Reservation> reservations = reservationService.afficherReservations();

        // Nombre total
        stats.put("total", reservations.size());

        // Réservations actives (date fin >= aujourd'hui)
        long actives = reservations.stream()
                .filter(r -> !r.getDateFin().toLocalDate().isBefore(LocalDate.now()))
                .count();
        stats.put("actives", actives);

        // Réservations passées
        long passees = reservations.size() - actives;
        stats.put("passees", passees);

        // Nombre total de personnes
        int totalPersonnes = reservations.stream()
                .mapToInt(Reservation::getNbPersonnes)
                .sum();
        stats.put("totalPersonnes", totalPersonnes);

        // Moyenne de personnes par réservation
        double moyennePersonnes = reservations.stream()
                .mapToInt(Reservation::getNbPersonnes)
                .average()
                .orElse(0.0);
        stats.put("moyennePersonnes", moyennePersonnes);

        // Durée moyenne de séjour (en nuits)
        double dureeeMoyenne = reservations.stream()
                .mapToLong(r -> ChronoUnit.DAYS.between(
                        r.getDateDebut().toLocalDate(),
                        r.getDateFin().toLocalDate()))
                .average()
                .orElse(0.0);
        stats.put("dureeMoyenne", dureeeMoyenne);

        // Hébergement le plus réservé
        Map<Integer, Long> reservationsParHeb = reservations.stream()
                .collect(Collectors.groupingBy(Reservation::getIdHebergement, Collectors.counting()));
        
        Integer hebPlusReserve = reservationsParHeb.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(null);
        
        if (hebPlusReserve != null) {
            Hebergement heb = hebergementService.getHebergementById(hebPlusReserve);
            stats.put("hebPlusReserve", heb != null ? heb.getNom() : "ID: " + hebPlusReserve);
            stats.put("hebPlusReserveCount", reservationsParHeb.get(hebPlusReserve));
        } else {
            stats.put("hebPlusReserve", "N/A");
            stats.put("hebPlusReserveCount", 0);
        }

        return stats;
    }

    /**
     * Statistiques par mois (pour graphiques)
     */
    public Map<String, Integer> getReservationsParMois() {
        List<Reservation> reservations = reservationService.afficherReservations();
        Map<String, Integer> parMois = new LinkedHashMap<>();

        // Initialiser les 12 derniers mois
        LocalDate now = LocalDate.now();
        for (int i = 11; i >= 0; i--) {
            LocalDate date = now.minusMonths(i);
            String mois = date.getMonth().toString() + " " + date.getYear();
            parMois.put(mois, 0);
        }

        // Compter les réservations par mois
        for (Reservation r : reservations) {
            LocalDate dateDebut = r.getDateDebut().toLocalDate();
            String mois = dateDebut.getMonth().toString() + " " + dateDebut.getYear();
            if (parMois.containsKey(mois)) {
                parMois.put(mois, parMois.get(mois) + 1);
            }
        }

        return parMois;
    }

    /**
     * Taux d'occupation par hébergement
     */
    public Map<String, Double> getTauxOccupation() {
        List<Hebergement> hebergements = hebergementService.afficherHebergements();
        List<Reservation> reservations = reservationService.afficherReservations();
        Map<String, Double> tauxOccupation = new HashMap<>();

        LocalDate debut = LocalDate.now().minusMonths(3); // 3 derniers mois
        LocalDate fin = LocalDate.now();
        long joursTotal = ChronoUnit.DAYS.between(debut, fin);

        for (Hebergement h : hebergements) {
            List<Reservation> resHeb = reservations.stream()
                    .filter(r -> r.getIdHebergement() == h.getId())
                    .filter(r -> !r.getDateFin().toLocalDate().isBefore(debut))
                    .filter(r -> !r.getDateDebut().toLocalDate().isAfter(fin))
                    .collect(Collectors.toList());

            long joursReserves = resHeb.stream()
                    .mapToLong(r -> {
                        LocalDate dDebut = r.getDateDebut().toLocalDate().isBefore(debut) ? debut : r.getDateDebut().toLocalDate();
                        LocalDate dFin = r.getDateFin().toLocalDate().isAfter(fin) ? fin : r.getDateFin().toLocalDate();
                        return ChronoUnit.DAYS.between(dDebut, dFin);
                    })
                    .sum();

            double taux = (joursReserves * 100.0) / joursTotal;
            tauxOccupation.put(h.getNom(), Math.round(taux * 100.0) / 100.0);
        }

        return tauxOccupation;
    }

    /**
     * Revenu estimé par hébergement
     */
    public Map<String, Double> getRevenuParHebergement() {
        List<Hebergement> hebergements = hebergementService.afficherHebergements();
        List<Reservation> reservations = reservationService.afficherReservations();
        Map<String, Double> revenus = new HashMap<>();

        for (Hebergement h : hebergements) {
            double revenu = reservations.stream()
                    .filter(r -> r.getIdHebergement() == h.getId())
                    .mapToDouble(r -> {
                        long nuits = ChronoUnit.DAYS.between(
                                r.getDateDebut().toLocalDate(),
                                r.getDateFin().toLocalDate());
                        return nuits * Double.parseDouble(h.getPrix());
                    })
                    .sum();
            revenus.put(h.getNom(), Math.round(revenu * 100.0) / 100.0);
        }

        return revenus;
    }

    /**
     * Revenu total
     */
    public double getRevenuTotal() {
        return getRevenuParHebergement().values().stream()
                .mapToDouble(Double::doubleValue)
                .sum();
    }
}
