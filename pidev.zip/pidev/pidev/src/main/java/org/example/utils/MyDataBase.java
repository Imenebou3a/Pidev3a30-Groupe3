package org.example.utils;

import org.example.exceptions.DatabaseException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Classe singleton pour gérer la connexion à la base de données
 */
public class MyDataBase {
    private static final String URL = "jdbc:mysql://localhost:3306/pidev";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    private static Connection connection;

    private MyDataBase() {
        // Empêcher l'instanciation
    }

    /**
     * Retourne la connexion à la base de données (singleton)
     */
    public static Connection getConnection() {
        if (connection == null) {
            try {
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
                Logger.info("Connexion à la base de données établie avec succès");
            } catch (SQLException e) {
                Logger.error("Erreur de connexion à la base de données", e);
                throw new DatabaseException("Impossible de se connecter à la base de données", e);
            }
        }
        return connection;
    }
    
    /**
     * Ferme la connexion à la base de données
     */
    public static void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                connection = null;
                Logger.info("Connexion à la base de données fermée");
            } catch (SQLException e) {
                Logger.error("Erreur lors de la fermeture de la connexion", e);
            }
        }
    }
}