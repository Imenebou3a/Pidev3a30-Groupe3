package org.example.utils;

import javafx.animation.*;
import javafx.scene.Node;
import javafx.util.Duration;

/**
 * Utilitaires pour les animations JavaFX
 */
public class AnimationUtils {
    
    /**
     * Animation de fondu entrant
     */
    public static void fadeIn(Node node, double duration) {
        FadeTransition fade = new FadeTransition(Duration.millis(duration), node);
        fade.setFromValue(0.0);
        fade.setToValue(1.0);
        fade.play();
    }
    
    /**
     * Animation de fondu sortant
     */
    public static void fadeOut(Node node, double duration) {
        FadeTransition fade = new FadeTransition(Duration.millis(duration), node);
        fade.setFromValue(1.0);
        fade.setToValue(0.0);
        fade.play();
    }
    
    /**
     * Animation de glissement depuis la gauche
     */
    public static void slideInFromLeft(Node node, double duration) {
        TranslateTransition slide = new TranslateTransition(Duration.millis(duration), node);
        slide.setFromX(-node.getBoundsInParent().getWidth());
        slide.setToX(0);
        slide.play();
    }
    
    /**
     * Animation de zoom
     */
    public static void zoomIn(Node node, double duration) {
        ScaleTransition scale = new ScaleTransition(Duration.millis(duration), node);
        scale.setFromX(0.8);
        scale.setFromY(0.8);
        scale.setToX(1.0);
        scale.setToY(1.0);
        scale.play();
    }
    
    /**
     * Animation de rebond au survol
     */
    public static void addHoverBounce(Node node) {
        node.setOnMouseEntered(e -> {
            ScaleTransition scale = new ScaleTransition(Duration.millis(200), node);
            scale.setToX(1.05);
            scale.setToY(1.05);
            scale.play();
        });
        
        node.setOnMouseExited(e -> {
            ScaleTransition scale = new ScaleTransition(Duration.millis(200), node);
            scale.setToX(1.0);
            scale.setToY(1.0);
            scale.play();
        });
    }
    
    /**
     * Animation de rotation
     */
    public static void rotate(Node node, double angle, double duration) {
        RotateTransition rotate = new RotateTransition(Duration.millis(duration), node);
        rotate.setByAngle(angle);
        rotate.play();
    }
    
    private AnimationUtils() {
        // Empêcher l'instanciation
    }
}
