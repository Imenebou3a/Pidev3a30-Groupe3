package org.example.controller.Backoffice;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import org.example.services.*;

import java.awt.Desktop;
import java.io.File;
import java.util.Map;

public class DashboardController {

    // Statistiques Hébergements
    @FXML
    private Label lblTotalHebergements;
    @FXML
    private Label lblPrixMoyen;
    @FXML
    private Label lblTypePlusPopulaire;
    @FXML
    private Label lblPrixMin;
    @FXML
    private Label lblPrixMax;

    // Statistiques Réservations
    @FXML
    private Label lblTotalReservations;
    @FXML
    private Label lblReservationsActives;
    @FXML
    private Label lblReservationsPassees;
    @FXML
    private Label lblMoyennePersonnes;
    @FXML
    private Label lblDureeMoyenne;
    @FXML
    private Label lblHebPlusReserve;

    // Statistiques Financières
    @FXML
    private Label lblRevenuTotal;
    @FXML
    private Label lblTauxOccupationMoyen;

    // Boutons Export
    @FXML
    private Button btnExportHebergementsPdf;
    @FXML
    private Button btnExportReservationsPdf;
    @FXML
    private Button btnRafraichir;

    // Conteneur de statistiques détaillées
    @FXML
    private VBox statsDetailsContainer;

    private StatistiquesService statistiquesService;
    private PdfService pdfService;
    private HebergementService hebergementService;
    private ReservationService reservationService;

    @FXML
    public void initialize() {
        initializeServices();
        chargerStatistiques();
        applyButtonStyles();
    }
    
    private void initializeServices() {
        statistiquesService = new StatistiquesService();
        pdfService = new PdfService();
        hebergementService = new HebergementService();
        reservationService = new ReservationService();
    }
    
    private void applyButtonStyles() {
        if (btnExportHebergementsPdf != null) {
            btnExportHebergementsPdf.getStyleClass().addAll("btn-primary", "smooth-transition");
        }
        if (btnExportReservationsPdf != null) {
            btnExportReservationsPdf.getStyleClass().addAll("btn-secondary", "smooth-transition");
        }
        if (btnRafraichir != null) {
            btnRafraichir.getStyleClass().addAll("btn-outline", "smooth-transition");
        }
    }

    private void chargerStatistiques() {
        chargerStatistiquesHebergements();
        chargerStatistiquesReservations();
        chargerStatistiquesFinancieres();
    }
    
    private void chargerStatistiquesHebergements() {
        Map<String, Object> statsHeb = statistiquesService.getStatistiquesHebergements();
        updateLabel(lblTotalHebergements, String.valueOf(statsHeb.get("total")));
        updateLabel(lblPrixMoyen, String.format("%.2f DT", statsHeb.get("prixMoyen")));
        updateLabel(lblTypePlusPopulaire, String.valueOf(statsHeb.get("typePlusPopulaire")));
        updateLabel(lblPrixMin, String.format("%.2f DT", statsHeb.get("prixMin")));
        updateLabel(lblPrixMax, String.format("%.2f DT", statsHeb.get("prixMax")));
    }
    
    private void chargerStatistiquesReservations() {
        Map<String, Object> statsRes = statistiquesService.getStatistiquesReservations();
        updateLabel(lblTotalReservations, String.valueOf(statsRes.get("total")));
        updateLabel(lblReservationsActives, String.valueOf(statsRes.get("actives")));
        updateLabel(lblReservationsPassees, String.valueOf(statsRes.get("passees")));
        updateLabel(lblMoyennePersonnes, String.format("%.1f", statsRes.get("moyennePersonnes")));
        updateLabel(lblDureeMoyenne, String.format("%.1f nuits", statsRes.get("dureeMoyenne")));
        updateLabel(lblHebPlusReserve, String.format("%s (%d fois)",
                statsRes.get("hebPlusReserve"),
                statsRes.get("hebPlusReserveCount")));
    }
    
    private void chargerStatistiquesFinancieres() {
        double revenuTotal = statistiquesService.getRevenuTotal();
        updateLabel(lblRevenuTotal, String.format("%.2f DT", revenuTotal));

        Map<String, Double> tauxOccupation = statistiquesService.getTauxOccupation();
        double tauxMoyen = tauxOccupation.values().stream()
                .mapToDouble(Double::doubleValue)
                .average()
                .orElse(0.0);
        updateLabel(lblTauxOccupationMoyen, String.format("%.1f%%", tauxMoyen));
    }
    
    private void updateLabel(Label label, String text) {
        if (label != null) {
            label.setText(text);
        }
    }

    @FXML
    private void rafraichirStatistiques() {
        chargerStatistiques();
        afficherMessage("Statistiques rafraîchies!", Alert.AlertType.INFORMATION);
    }

    @FXML
    private void exporterHebergementsPdf() {
        exporterPdf(
            () -> pdfService.genererPdfHebergements(hebergementService.afficherHebergements()),
            "Hébergements"
        );
    }

    @FXML
    private void exporterReservationsPdf() {
        exporterPdf(
            () -> pdfService.genererPdfReservations(
                reservationService.afficherReservations(),
                hebergementService
            ),
            "Réservations"
        );
    }
    
    private void exporterPdf(PdfGenerator generator, String type) {
        try {
            if (pdfService == null) {
                afficherMessage("Service PDF non disponible. Vérifiez les dépendances iText.", Alert.AlertType.WARNING);
                return;
            }
            
            String fileName = generator.generate();
            if (fileName != null) {
                proposerOuverturePdf(fileName, type);
            } else {
                afficherMessage("Erreur lors de la génération du PDF", Alert.AlertType.ERROR);
            }
        } catch (NoClassDefFoundError e) {
            afficherMessage("Bibliothèque iText manquante. Veuillez recharger le projet Maven.", Alert.AlertType.ERROR);
            e.printStackTrace();
        } catch (Exception e) {
            afficherMessage("Erreur: " + e.getMessage(), Alert.AlertType.ERROR);
            e.printStackTrace();
        }
    }
    
    private void proposerOuverturePdf(String fileName, String type) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("PDF Généré");
        alert.setHeaderText("Le PDF " + type + " a été généré avec succès!");
        alert.setContentText("Voulez-vous ouvrir le fichier?\n" + fileName);
        
        alert.showAndWait().ifPresent(response -> {
            if (response.getButtonData().isDefaultButton()) {
                ouvrirFichier(fileName);
            }
        });
    }
    
    @FunctionalInterface
    private interface PdfGenerator {
        String generate() throws Exception;
    }
    
    private void ouvrirFichier(String fileName) {
        try {
            File file = new File(fileName);
            if (file.exists()) {
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(file);
                } else {
                    // Fallback pour Windows
                    Runtime.getRuntime().exec("cmd /c start \"\" \"" + file.getAbsolutePath() + "\"");
                }
            } else {
                afficherMessage("Fichier introuvable: " + fileName, Alert.AlertType.WARNING);
            }
        } catch (Exception e) {
            afficherMessage("Impossible d'ouvrir le fichier: " + e.getMessage(), Alert.AlertType.WARNING);
        }
    }

    private void afficherMessage(String message, Alert.AlertType type) {
        Platform.runLater(() -> {
            Alert alert = new Alert(type);
            alert.setTitle(type == Alert.AlertType.ERROR ? "Erreur" : "Information");
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }
}
