package org.example.tests.service;

import org.example.entities.Hebergement;
import org.example.services.HebergementService;
import org.junit.jupiter.api.*;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests unitaires pour HebergementService
 * Teste toutes les opérations CRUD
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class HebergementServiceTest {

    private static HebergementService service;
    private static int testHebergementId;

    @BeforeAll
    public static void setUp() {
        System.out.println("=".repeat(80));
        System.out.println("🧪 TESTS UNITAIRES - HEBERGEMENT SERVICE");
        System.out.println("=".repeat(80));
        service = new HebergementService();
    }

    @Test
    @Order(1)
    @DisplayName("Test 1: Connexion à la base de données")
    public void testConnexion() {
        System.out.println("\n📡 Test 1: Connexion à la base de données");
        assertNotNull(service, "Le service ne doit pas être null");
        System.out.println("✅ Service initialisé avec succès");
    }

    @Test
    @Order(2)
    @DisplayName("Test 2: Afficher tous les hébergements")
    public void testAfficherHebergements() {
        System.out.println("\n📋 Test 2: Afficher tous les hébergements");
        
        List<Hebergement> hebergements = service.afficherHebergements();
        
        assertNotNull(hebergements, "La liste ne doit pas être null");
        System.out.println("✅ " + hebergements.size() + " hébergement(s) trouvé(s)");
        
        if (!hebergements.isEmpty()) {
            Hebergement premier = hebergements.get(0);
            assertNotNull(premier.getNom(), "Le nom ne doit pas être null");
            assertNotNull(premier.getType(), "Le type ne doit pas être null");
            System.out.println("   Premier hébergement: " + premier.getNom());
        }
    }

    @Test
    @Order(3)
    @DisplayName("Test 3: Ajouter un hébergement")
    public void testAjouterHebergement() {
        System.out.println("\n➕ Test 3: Ajouter un hébergement");
        
        Hebergement nouveau = new Hebergement(
            "Villa Test JUnit",
            "Villa",
            "123 Rue Test, Tunis",
            "350.00",
            null
        );
        
        service.ajouterHebergement(nouveau);
        
        // Vérifier que l'hébergement a été ajouté
        List<Hebergement> hebergements = service.afficherHebergements();
        boolean trouve = hebergements.stream()
            .anyMatch(h -> h.getNom().equals("Villa Test JUnit"));
        
        assertTrue(trouve, "L'hébergement doit être dans la liste");
        System.out.println("✅ Hébergement ajouté avec succès");
        
        // Sauvegarder l'ID pour les tests suivants
        testHebergementId = hebergements.stream()
            .filter(h -> h.getNom().equals("Villa Test JUnit"))
            .findFirst()
            .map(Hebergement::getId)
            .orElse(0);
        
        System.out.println("   ID de test: " + testHebergementId);
    }

    @Test
    @Order(4)
    @DisplayName("Test 4: Rechercher un hébergement par ID")
    public void testGetHebergementById() {
        System.out.println("\n🔍 Test 4: Rechercher un hébergement par ID");
        
        if (testHebergementId == 0) {
            // Récupérer un ID existant
            List<Hebergement> hebergements = service.afficherHebergements();
            if (!hebergements.isEmpty()) {
                testHebergementId = hebergements.get(0).getId();
            }
        }
        
        Hebergement trouve = service.getHebergementById(testHebergementId);
        
        assertNotNull(trouve, "L'hébergement doit être trouvé");
        assertEquals(testHebergementId, trouve.getId(), "L'ID doit correspondre");
        System.out.println("✅ Hébergement trouvé: " + trouve.getNom());
    }

    @Test
    @Order(5)
    @DisplayName("Test 5: Modifier un hébergement")
    public void testModifierHebergement() {
        System.out.println("\n✏️  Test 5: Modifier un hébergement");
        
        if (testHebergementId == 0) {
            List<Hebergement> hebergements = service.afficherHebergements();
            if (!hebergements.isEmpty()) {
                testHebergementId = hebergements.get(0).getId();
            }
        }
        
        Hebergement aModifier = service.getHebergementById(testHebergementId);
        assertNotNull(aModifier, "L'hébergement doit exister");
        
        String ancienNom = aModifier.getNom();
        String nouveauNom = ancienNom + " (Modifié)";
        aModifier.setNom(nouveauNom);
        aModifier.setPrix("399.99");
        
        service.modifierHebergement(aModifier);
        
        // Vérifier la modification
        Hebergement modifie = service.getHebergementById(testHebergementId);
        assertEquals(nouveauNom, modifie.getNom(), "Le nom doit être modifié");
        assertEquals("399.99", modifie.getPrix(), "Le prix doit être modifié");
        
        System.out.println("✅ Hébergement modifié avec succès");
        System.out.println("   Ancien nom: " + ancienNom);
        System.out.println("   Nouveau nom: " + nouveauNom);
    }

    @Test
    @Order(6)
    @DisplayName("Test 6: Validation des données")
    public void testValidationDonnees() {
        System.out.println("\n🔒 Test 6: Validation des données");
        
        // Test avec nom vide
        Hebergement invalide = new Hebergement("", "Villa", "Adresse", "100", null);
        assertNotNull(invalide, "L'objet doit être créé");
        assertTrue(invalide.getNom().isEmpty(), "Le nom est vide");
        System.out.println("✅ Validation: nom vide détecté");
        
        // Test avec prix négatif
        Hebergement prixNegatif = new Hebergement("Test", "Villa", "Adresse", "-100", null);
        assertNotNull(prixNegatif, "L'objet doit être créé");
        System.out.println("✅ Validation: prix négatif détecté");
    }

    @Test
    @Order(7)
    @DisplayName("Test 7: Supprimer un hébergement")
    public void testSupprimerHebergement() {
        System.out.println("\n🗑️  Test 7: Supprimer un hébergement");
        
        if (testHebergementId == 0) {
            System.out.println("⚠️  Aucun hébergement de test à supprimer");
            return;
        }
        
        int nombreAvant = service.afficherHebergements().size();
        System.out.println("   Nombre avant suppression: " + nombreAvant);
        
        service.supprimerHebergement(testHebergementId);
        
        int nombreApres = service.afficherHebergements().size();
        System.out.println("   Nombre après suppression: " + nombreApres);
        
        assertEquals(nombreAvant - 1, nombreApres, "Le nombre doit diminuer de 1");
        
        // Vérifier que l'hébergement n'existe plus
        Hebergement supprime = service.getHebergementById(testHebergementId);
        assertNull(supprime, "L'hébergement ne doit plus exister");
        
        System.out.println("✅ Hébergement supprimé avec succès");
    }

    @AfterAll
    public static void tearDown() {
        System.out.println("\n" + "=".repeat(80));
        System.out.println("✅ TOUS LES TESTS TERMINÉS");
        System.out.println("=".repeat(80));
    }
}
