package org.example.tests.service;

import org.example.entities.Hebergement;
import org.example.entities.Reservation;
import org.example.services.HebergementService;
import org.example.services.ReservationService;
import org.junit.jupiter.api.*;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests unitaires pour ReservationService
 * Teste toutes les opérations CRUD et la vérification de disponibilité
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ReservationServiceTest {

    private static ReservationService reservationService;
    private static HebergementService hebergementService;
    private static int testReservationId;
    private static int testHebergementId;

    @BeforeAll
    public static void setUp() {
        System.out.println("=".repeat(80));
        System.out.println("🧪 TESTS UNITAIRES - RESERVATION SERVICE");
        System.out.println("=".repeat(80));
        
        reservationService = new ReservationService();
        hebergementService = new HebergementService();
        
        // Récupérer un hébergement existant pour les tests
        List<Hebergement> hebergements = hebergementService.afficherHebergements();
        if (!hebergements.isEmpty()) {
            testHebergementId = hebergements.get(0).getId();
            System.out.println("📍 Hébergement de test: ID " + testHebergementId);
        }
    }

    @Test
    @Order(1)
    @DisplayName("Test 1: Connexion à la base de données")
    public void testConnexion() {
        System.out.println("\n📡 Test 1: Connexion à la base de données");
        assertNotNull(reservationService, "Le service ne doit pas être null");
        assertNotNull(hebergementService, "Le service hébergement ne doit pas être null");
        System.out.println("✅ Services initialisés avec succès");
    }

    @Test
    @Order(2)
    @DisplayName("Test 2: Afficher toutes les réservations")
    public void testAfficherReservations() {
        System.out.println("\n📋 Test 2: Afficher toutes les réservations");
        
        List<Reservation> reservations = reservationService.afficherReservations();
        
        assertNotNull(reservations, "La liste ne doit pas être null");
        System.out.println("✅ " + reservations.size() + " réservation(s) trouvée(s)");
        
        if (!reservations.isEmpty()) {
            Reservation premiere = reservations.get(0);
            assertNotNull(premiere.getDateDebut(), "La date début ne doit pas être null");
            assertNotNull(premiere.getDateFin(), "La date fin ne doit pas être null");
            assertTrue(premiere.getNbPersonnes() > 0, "Le nombre de personnes doit être positif");
            System.out.println("   Première réservation: ID " + premiere.getId());
        }
    }

    @Test
    @Order(3)
    @DisplayName("Test 3: Ajouter une réservation")
    public void testAjouterReservation() {
        System.out.println("\n➕ Test 3: Ajouter une réservation");
        
        if (testHebergementId == 0) {
            System.out.println("⚠️  Aucun hébergement disponible pour le test");
            return;
        }
        
        LocalDate debut = LocalDate.now().plusDays(10);
        LocalDate fin = debut.plusDays(3);
        
        Reservation nouvelle = new Reservation(
            testHebergementId,
            Date.valueOf(debut),
            Date.valueOf(fin),
            2
        );
        
        System.out.println("   Hébergement ID: " + testHebergementId);
        System.out.println("   Du: " + debut + " au: " + fin);
        System.out.println("   Personnes: 2");
        
        reservationService.ajouterReservation(nouvelle);
        
        // Vérifier que la réservation a été ajoutée
        List<Reservation> reservations = reservationService.afficherReservations();
        boolean trouve = reservations.stream()
            .anyMatch(r -> r.getIdHebergement() == testHebergementId 
                && r.getDateDebut().equals(Date.valueOf(debut)));
        
        assertTrue(trouve, "La réservation doit être dans la liste");
        System.out.println("✅ Réservation ajoutée avec succès");
        
        // Sauvegarder l'ID pour les tests suivants
        testReservationId = reservations.stream()
            .filter(r -> r.getIdHebergement() == testHebergementId 
                && r.getDateDebut().equals(Date.valueOf(debut)))
            .findFirst()
            .map(Reservation::getId)
            .orElse(0);
        
        System.out.println("   ID de test: " + testReservationId);
    }

    @Test
    @Order(4)
    @DisplayName("Test 4: Vérifier la disponibilité")
    public void testVerifierDisponibilite() {
        System.out.println("\n🔍 Test 4: Vérifier la disponibilité");
        
        if (testHebergementId == 0) {
            System.out.println("⚠️  Aucun hébergement disponible pour le test");
            return;
        }
        
        // Test 1: Dates disponibles (dans le futur lointain)
        LocalDate debut1 = LocalDate.now().plusDays(60);
        LocalDate fin1 = debut1.plusDays(2);
        
        boolean disponible1 = reservationService.verifierDisponibilite(
            testHebergementId,
            Date.valueOf(debut1),
            Date.valueOf(fin1)
        );
        
        System.out.println("   Test dates futures: " + (disponible1 ? "✅ Disponible" : "❌ Non disponible"));
        
        // Test 2: Dates qui chevauchent une réservation existante
        if (testReservationId != 0) {
            LocalDate debut2 = LocalDate.now().plusDays(11);
            LocalDate fin2 = debut2.plusDays(2);
            
            boolean disponible2 = reservationService.verifierDisponibilite(
                testHebergementId,
                Date.valueOf(debut2),
                Date.valueOf(fin2)
            );
            
            System.out.println("   Test chevauchement: " + (disponible2 ? "✅ Disponible" : "❌ Non disponible"));
        }
        
        System.out.println("✅ Tests de disponibilité terminés");
    }

    @Test
    @Order(5)
    @DisplayName("Test 5: Modifier une réservation")
    public void testModifierReservation() {
        System.out.println("\n✏️  Test 5: Modifier une réservation");
        
        if (testReservationId == 0) {
            List<Reservation> reservations = reservationService.afficherReservations();
            if (!reservations.isEmpty()) {
                testReservationId = reservations.get(0).getId();
            } else {
                System.out.println("⚠️  Aucune réservation à modifier");
                return;
            }
        }
        
        List<Reservation> reservations = reservationService.afficherReservations();
        Reservation aModifier = reservations.stream()
            .filter(r -> r.getId() == testReservationId)
            .findFirst()
            .orElse(null);
        
        assertNotNull(aModifier, "La réservation doit exister");
        
        int ancienNbPersonnes = aModifier.getNbPersonnes();
        int nouveauNbPersonnes = ancienNbPersonnes + 1;
        aModifier.setNbPersonnes(nouveauNbPersonnes);
        
        reservationService.modifierReservation(aModifier);
        
        // Vérifier la modification
        List<Reservation> apresModif = reservationService.afficherReservations();
        Reservation modifiee = apresModif.stream()
            .filter(r -> r.getId() == testReservationId)
            .findFirst()
            .orElse(null);
        
        assertNotNull(modifiee, "La réservation doit toujours exister");
        assertEquals(nouveauNbPersonnes, modifiee.getNbPersonnes(), 
            "Le nombre de personnes doit être modifié");
        
        System.out.println("✅ Réservation modifiée avec succès");
        System.out.println("   Ancien nombre: " + ancienNbPersonnes);
        System.out.println("   Nouveau nombre: " + nouveauNbPersonnes);
    }

    @Test
    @Order(6)
    @DisplayName("Test 6: Validation des dates")
    public void testValidationDates() {
        System.out.println("\n🔒 Test 6: Validation des dates");
        
        LocalDate debut = LocalDate.now().plusDays(5);
        LocalDate fin = debut.plusDays(3);
        
        // Test: Date fin après date début
        assertTrue(fin.isAfter(debut), "La date fin doit être après la date début");
        System.out.println("✅ Validation: date fin > date début");
        
        // Test: Durée minimum
        long nuits = java.time.temporal.ChronoUnit.DAYS.between(debut, fin);
        assertTrue(nuits >= 1, "La durée doit être d'au moins 1 nuit");
        System.out.println("✅ Validation: durée minimum respectée (" + nuits + " nuits)");
        
        // Test: Date dans le futur
        assertTrue(debut.isAfter(LocalDate.now()), "La date doit être dans le futur");
        System.out.println("✅ Validation: date dans le futur");
    }

    @Test
    @Order(7)
    @DisplayName("Test 7: Calcul du prix total")
    public void testCalculPrixTotal() {
        System.out.println("\n💰 Test 7: Calcul du prix total");
        
        if (testHebergementId == 0) {
            System.out.println("⚠️  Aucun hébergement disponible pour le test");
            return;
        }
        
        Hebergement hebergement = hebergementService.getHebergementById(testHebergementId);
        assertNotNull(hebergement, "L'hébergement doit exister");
        
        LocalDate debut = LocalDate.now().plusDays(7);
        LocalDate fin = debut.plusDays(3);
        
        long nuits = java.time.temporal.ChronoUnit.DAYS.between(debut, fin);
        double prixNuit = Double.parseDouble(hebergement.getPrix());
        double total = nuits * prixNuit;
        
        System.out.println("   Prix/nuit: " + prixNuit + " DT");
        System.out.println("   Nombre de nuits: " + nuits);
        System.out.println("   Total: " + total + " DT");
        
        assertTrue(total > 0, "Le prix total doit être positif");
        assertEquals(nuits * prixNuit, total, 0.01, "Le calcul doit être correct");
        
        System.out.println("✅ Calcul du prix correct");
    }

    @Test
    @Order(8)
    @DisplayName("Test 8: Supprimer une réservation")
    public void testSupprimerReservation() {
        System.out.println("\n🗑️  Test 8: Supprimer une réservation");
        
        if (testReservationId == 0) {
            System.out.println("⚠️  Aucune réservation de test à supprimer");
            return;
        }
        
        int nombreAvant = reservationService.afficherReservations().size();
        System.out.println("   Nombre avant suppression: " + nombreAvant);
        
        reservationService.supprimerReservation(testReservationId);
        
        int nombreApres = reservationService.afficherReservations().size();
        System.out.println("   Nombre après suppression: " + nombreApres);
        
        assertEquals(nombreAvant - 1, nombreApres, "Le nombre doit diminuer de 1");
        
        // Vérifier que la réservation n'existe plus
        boolean existe = reservationService.afficherReservations().stream()
            .anyMatch(r -> r.getId() == testReservationId);
        
        assertFalse(existe, "La réservation ne doit plus exister");
        
        System.out.println("✅ Réservation supprimée avec succès");
    }

    @AfterAll
    public static void tearDown() {
        System.out.println("\n" + "=".repeat(80));
        System.out.println("✅ TOUS LES TESTS TERMINÉS");
        System.out.println("=".repeat(80));
    }
}
