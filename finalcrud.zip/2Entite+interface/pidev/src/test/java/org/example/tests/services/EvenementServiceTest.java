package org.example.tests.services;

import org.example.entities.Evenement;
import org.example.services.EvenementService;
import org.junit.jupiter.api.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class EvenementServiceTest {

    private static EvenementService service;
    private Evenement testEvent;

    @BeforeAll
    static void initService() {
        service = new EvenementService();
    }

    @BeforeEach
    void setUp() {
        testEvent = new Evenement(
                "Event Test",
                "Description test",
                LocalDate.of(2026, 1, 1),
                "10:00", // ✅ String au lieu de LocalTime
                "Esprit",
                20.0,
                100,
                "Actif"
        );
    }

    @Test
    @Order(1)
    void testAjouterEvenement() {
        service.ajouterEvenement(testEvent);
        Evenement retrieved = service.trouverEvenementParId(testEvent.getIdEvent());
        assertNotNull(retrieved, "L'événement doit être ajouté avec succès");
        assertEquals("Event Test", retrieved.getTitre());
    }

    @Test
    @Order(2)
    void testModifierEvenement() {
        service.ajouterEvenement(testEvent);
        testEvent.setLieu("Tunis");
        testEvent.setPrix(30.0);
        service.modifierEvenement(testEvent);

        Evenement retrieved = service.trouverEvenementParId(testEvent.getIdEvent());
        assertEquals("Tunis", retrieved.getLieu());
        assertEquals(30.0, retrieved.getPrix());
    }

    @Test
    @Order(3)
    void testSupprimerEvenement() {
        service.ajouterEvenement(testEvent);
        service.supprimerEvenement(testEvent.getIdEvent());

        Evenement retrieved = service.trouverEvenementParId(testEvent.getIdEvent());
        assertNull(retrieved, "L'événement supprimé ne doit plus exister");
    }

    @Test
    @Order(4)
    void testListeEvenements() {
        service.ajouterEvenement(testEvent);
        List<Evenement> events = service.afficherEvenements(); // ✅ utiliser afficherEvenements()
        assertNotNull(events, "La liste des événements ne doit pas être nulle");
        assertTrue(events.stream().anyMatch(e -> e.getIdEvent() == testEvent.getIdEvent()),
                "La liste doit contenir l'événement ajouté");
    }
}
