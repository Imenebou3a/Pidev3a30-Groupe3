package org.example.utils;

import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

/**
 * Classe pour afficher des notifications toast (non bloquantes)
 */
public class ToastNotification {

    public enum Type {
        SUCCESS, ERROR, WARNING, INFO
    }

    /**
     * Affiche une notification toast
     */
    public static void show(String message, Type type, Stage ownerStage) {
        Stage toastStage = new Stage();
        toastStage.initOwner(ownerStage);
        toastStage.initStyle(StageStyle.TRANSPARENT);
        toastStage.setAlwaysOnTop(true);

        // Créer le label avec le message
        Label label = new Label(getIcon(type) + " " + message);
        label.setStyle(getStyle(type));
        label.setWrapText(true);
        label.setMaxWidth(400);

        StackPane root = new StackPane(label);
        root.setStyle("-fx-background-color: transparent;");
        root.setAlignment(Pos.BOTTOM_RIGHT);

        Scene scene = new Scene(root);
        scene.setFill(javafx.scene.paint.Color.TRANSPARENT);
        toastStage.setScene(scene);

        // Positionner en bas à droite
        toastStage.setX(ownerStage.getX() + ownerStage.getWidth() - 450);
        toastStage.setY(ownerStage.getY() + ownerStage.getHeight() - 150);

        // Animation d'apparition
        FadeTransition fadeIn = new FadeTransition(Duration.millis(300), root);
        fadeIn.setFromValue(0.0);
        fadeIn.setToValue(1.0);

        // Animation de disparition
        FadeTransition fadeOut = new FadeTransition(Duration.millis(300), root);
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);
        fadeOut.setOnFinished(e -> toastStage.close());

        // Pause avant de disparaître
        PauseTransition pause = new PauseTransition(Duration.seconds(3));
        pause.setOnFinished(e -> fadeOut.play());

        toastStage.show();
        fadeIn.play();
        fadeIn.setOnFinished(e -> pause.play());
    }

    private static String getIcon(Type type) {
        return switch (type) {
            case SUCCESS -> "✅";
            case ERROR -> "❌";
            case WARNING -> "⚠️";
            case INFO -> "ℹ️";
        };
    }

    private static String getStyle(Type type) {
        String baseStyle = "-fx-background-color: %s; " +
                "-fx-text-fill: white; " +
                "-fx-padding: 20px 30px; " +
                "-fx-background-radius: 12; " +
                "-fx-font-size: 14px; " +
                "-fx-font-weight: 700; " +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 15, 0, 0, 5);";

        return switch (type) {
            case SUCCESS -> String.format(baseStyle, "#10b981");
            case ERROR -> String.format(baseStyle, "#ef4444");
            case WARNING -> String.format(baseStyle, "#f59e0b");
            case INFO -> String.format(baseStyle, "#3b82f6");
        };
    }

    // Méthodes de commodité
    public static void showSuccess(String message, Stage ownerStage) {
        show(message, Type.SUCCESS, ownerStage);
    }

    public static void showError(String message, Stage ownerStage) {
        show(message, Type.ERROR, ownerStage);
    }

    public static void showWarning(String message, Stage ownerStage) {
        show(message, Type.WARNING, ownerStage);
    }

    public static void showInfo(String message, Stage ownerStage) {
        show(message, Type.INFO, ownerStage);
    }
}
