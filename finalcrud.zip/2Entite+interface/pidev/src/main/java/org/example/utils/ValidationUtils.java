package org.example.utils;

import java.time.LocalDate;
import java.util.regex.Pattern;

/**
 * Classe utilitaire pour la validation des données
 */
public class ValidationUtils {

    // Regex pour validation email (RFC 5322 simplifié)
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
    );

    // Regex pour téléphone tunisien: +216 XX XXX XXX ou XX XXX XXX
    private static final Pattern PHONE_TN_PATTERN = Pattern.compile(
            "^(\\+216)?[2-9]\\d{7}$"
    );

    // Regex pour nom/prénom (lettres, espaces, accents)
    private static final Pattern NAME_PATTERN = Pattern.compile(
            "^[a-zA-ZÀ-ÿ\\s'-]{2,50}$"
    );

    /**
     * Valide une adresse email
     * @param email L'email à valider
     * @return true si valide, false sinon
     */
    public static boolean isValidEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            return false;
        }
        return EMAIL_PATTERN.matcher(email.trim()).matches();
    }

    /**
     * Valide un numéro de téléphone tunisien
     * @param phone Le numéro à valider
     * @return true si valide, false sinon
     */
    public static boolean isValidPhoneTN(String phone) {
        if (phone == null || phone.trim().isEmpty()) {
            return false;
        }
        // Enlever les espaces pour la validation
        String cleanPhone = phone.replaceAll("\\s+", "");
        return PHONE_TN_PATTERN.matcher(cleanPhone).matches();
    }

    /**
     * Valide un nom ou prénom
     * @param name Le nom à valider
     * @return true si valide, false sinon
     */
    public static boolean isValidName(String name) {
        if (name == null || name.trim().isEmpty()) {
            return false;
        }
        return NAME_PATTERN.matcher(name.trim()).matches();
    }

    /**
     * Valide qu'une chaîne n'est pas vide
     * @param str La chaîne à valider
     * @param minLength Longueur minimale
     * @param maxLength Longueur maximale
     * @return true si valide, false sinon
     */
    public static boolean isValidString(String str, int minLength, int maxLength) {
        if (str == null || str.trim().isEmpty()) {
            return false;
        }
        int length = str.trim().length();
        return length >= minLength && length <= maxLength;
    }

    /**
     * Valide qu'une date est dans le futur
     * @param date La date à valider
     * @return true si dans le futur, false sinon
     */
    public static boolean isFutureDate(LocalDate date) {
        if (date == null) {
            return false;
        }
        return date.isAfter(LocalDate.now());
    }

    /**
     * Valide qu'une date est aujourd'hui ou dans le futur
     * @param date La date à valider
     * @return true si aujourd'hui ou futur, false sinon
     */
    public static boolean isTodayOrFuture(LocalDate date) {
        if (date == null) {
            return false;
        }
        return !date.isBefore(LocalDate.now());
    }

    /**
     * Valide un prix (doit être positif)
     * @param prix Le prix à valider
     * @param min Prix minimum
     * @param max Prix maximum
     * @return true si valide, false sinon
     */
    public static boolean isValidPrice(double prix, double min, double max) {
        return prix >= min && prix <= max;
    }

    /**
     * Valide un nombre entier dans une plage
     * @param value La valeur à valider
     * @param min Valeur minimale
     * @param max Valeur maximale
     * @return true si valide, false sinon
     */
    public static boolean isValidInteger(int value, int min, int max) {
        return value >= min && value <= max;
    }

    /**
     * Valide un format d'heure HH:MM
     * @param time L'heure à valider
     * @return true si valide, false sinon
     */
    public static boolean isValidTime(String time) {
        if (time == null || time.trim().isEmpty()) {
            return false;
        }
        String timePattern = "^([01]?[0-9]|2[0-3]):[0-5][0-9]$";
        return time.matches(timePattern);
    }

    /**
     * Nettoie une chaîne (trim et suppression des espaces multiples)
     * @param str La chaîne à nettoyer
     * @return La chaîne nettoyée
     */
    public static String cleanString(String str) {
        if (str == null) {
            return "";
        }
        return str.trim().replaceAll("\\s+", " ");
    }

    /**
     * Formate un numéro de téléphone tunisien
     * @param phone Le numéro à formater
     * @return Le numéro formaté (+216 XX XXX XXX)
     */
    public static String formatPhoneTN(String phone) {
        if (phone == null) {
            return "";
        }
        String cleanPhone = phone.replaceAll("\\s+", "");
        if (cleanPhone.startsWith("+216")) {
            cleanPhone = cleanPhone.substring(4);
        }
        if (cleanPhone.length() == 8) {
            return "+216 " + cleanPhone.substring(0, 2) + " " + 
                   cleanPhone.substring(2, 5) + " " + cleanPhone.substring(5);
        }
        return phone;
    }
}
