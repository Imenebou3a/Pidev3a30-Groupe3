package org.example.utils;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class MyDataBase {

    private static Connection conn;
    private static Properties dbProperties;

    static {
        // Charger les propriétés au démarrage
        dbProperties = new Properties();
        try (InputStream input = MyDataBase.class.getClassLoader().getResourceAsStream("db.properties")) {
            if (input == null) {
                System.err.println("❌ Fichier db.properties introuvable ! Utilisation des valeurs par défaut.");
                // Valeurs par défaut en cas d'absence du fichier
                dbProperties.setProperty("db.url", "jdbc:mysql://localhost:3306/pidev?useSSL=false&serverTimezone=UTC");
                dbProperties.setProperty("db.username", "root");
                dbProperties.setProperty("db.password", "");
                dbProperties.setProperty("db.driver", "com.mysql.cj.jdbc.Driver");
            } else {
                dbProperties.load(input);
                System.out.println("✅ Configuration DB chargée depuis db.properties");
            }
        } catch (IOException e) {
            System.err.println("❌ Erreur lors du chargement de db.properties: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static Connection getConnection() {
        if (conn == null) {
            try {
                String driver = dbProperties.getProperty("db.driver");
                String url = dbProperties.getProperty("db.url");
                String username = dbProperties.getProperty("db.username");
                String password = dbProperties.getProperty("db.password");

                Class.forName(driver);
                conn = DriverManager.getConnection(url, username, password);
                System.out.println("✅ Connexion à la DB réussie !");
            } catch (ClassNotFoundException e) {
                System.err.println("❌ Driver MySQL non trouvé !");
                e.printStackTrace();
            } catch (SQLException e) {
                System.err.println("❌ Erreur SQL : " + e.getMessage());
                e.printStackTrace();
            }
        }
        return conn;
    }

    /**
     * Ferme la connexion à la base de données
     */
    public static void closeConnection() {
        if (conn != null) {
            try {
                conn.close();
                conn = null;
                System.out.println("✅ Connexion DB fermée");
            } catch (SQLException e) {
                System.err.println("❌ Erreur lors de la fermeture: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }
}
