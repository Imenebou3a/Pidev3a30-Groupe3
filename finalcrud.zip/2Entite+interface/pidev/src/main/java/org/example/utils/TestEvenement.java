package org.example.utils;

import org.example.entities.Evenement;
import org.example.services.EvenementService;

import java.time.LocalDate;
import java.util.List;

public class TestEvenement {

    public static void main(String[] args) {

        EvenementService es = new EvenementService();

        // 🔹 Création d'un nouvel événement
        Evenement e = new Evenement(
                "Concert Rock",
                "Concert de rock en plein air",
                LocalDate.of(2026, 2, 15),
                "20:00", // String pour l'heure
                "Stade Municipal",
                50.0,
                200,
                "Actif"
        );

        // 🔹 Ajouter l'événement à la base
        es.ajouterEvenement(e);

        // 🔹 Afficher tous les événements pour vérifier
        List<Evenement> evenements = es.afficherEvenements();
        for (Evenement ev : evenements) {
            System.out.println("ID: " + ev.getIdEvent() +
                    ", Titre: " + ev.getTitre() +
                    ", Heure: " + ev.getHeureEvent() +
                    ", Date: " + ev.getDateEvent() +
                    ", Lieu: " + ev.getLieu() +
                    ", Prix: " + ev.getPrix() +
                    ", Places: " + ev.getNbPlaces() +
                    ", Statut: " + ev.getStatut());
        }
    }
}
