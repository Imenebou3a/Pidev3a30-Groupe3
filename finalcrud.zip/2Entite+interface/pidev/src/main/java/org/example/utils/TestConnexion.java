package org.example.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TestConnexion {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/pidev"; // nom de la DB
        String user = "root"; // utilisateur XAMPP par défaut
        String password = ""; // mot de passe vide par défaut

        try {
            // Charger le driver MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connexion
            Connection conn = DriverManager.getConnection(url, user, password);
            System.out.println("✅ Connexion réussie à la base 'pidev' !");
            conn.close();
        } catch (ClassNotFoundException e) {
            System.out.println("❌ Driver MySQL non trouvé !");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("❌ Test de connexion échoué !");
            e.printStackTrace();
        }
    }
}
