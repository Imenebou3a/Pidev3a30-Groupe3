package org.example.utils;

import org.example.entities.Participation;
import org.example.services.ParticipationService;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

public class TestParticipation {

    public static void main(String[] args) {

        ParticipationService ps = new ParticipationService();

        // ================= CREATE =================
        LocalDate ld = LocalDate.of(2026, 2, 14);
        Date sqlDate = Date.valueOf(ld);

        Participation p = new Participation(
                "Ali", "Ben Salah", "ali@gmail.com",
                "22123456", sqlDate,  1
        );

        System.out.println("=== AJOUT ===");
        ps.ajouterParticipation(p);

        // ================= READ =================
        System.out.println("\n=== LISTE APRÈS AJOUT ===");
        List<Participation> list = ps.afficherParticipations();
        for (Participation part : list) afficherParticipation(part);

        // ================= UPDATE =================
        if (!list.isEmpty()) {
            Participation first = list.get(0);
            System.out.println("\n=== MODIFICATION ===");
            first.setTelephone("99887766");
            ps.modifierParticipation(first);
        }

        // ================= READ APRÈS UPDATE =================
        System.out.println("\n=== LISTE APRÈS MODIFICATION ===");
        list = ps.afficherParticipations();
        for (Participation part : list) afficherParticipation(part);

        // ================= DELETE =================
        if (!list.isEmpty()) {
            Participation last = list.get(list.size() - 1);
            System.out.println("\n=== SUPPRESSION ID : " + last.getId() + " ===");
            ps.supprimerParticipation(last.getId());
        }

        // ================= READ APRÈS DELETE =================
        System.out.println("\n=== LISTE FINALE ===");
        list = ps.afficherParticipations();
        for (Participation part : list) afficherParticipation(part);

        System.out.println("\n✅ TEST CRUD PARTICIPATION TERMINÉ");
    }

    private static void afficherParticipation(Participation p) {
        System.out.println(
                "ID: " + p.getId() +
                        " | Nom: " + p.getNom() +
                        " | Prénom: " + p.getPrenom() +
                        " | Email: " + p.getEmail() +
                        " | Téléphone: " + p.getTelephone() +
                        " | Date: " + p.getDate() +
                        " | Event ID: " + p.getIdEvent()
        );
    }
}
