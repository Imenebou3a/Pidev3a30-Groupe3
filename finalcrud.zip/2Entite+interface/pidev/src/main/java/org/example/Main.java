package org.example;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/fxml/main/MainLayout.fxml"));
        Scene scene = new Scene(root);
        
        // Ajouter des raccourcis clavier
        setupKeyboardShortcuts(scene);
        
        stage.setTitle("Lammetna - Gestion d'Événements");
        stage.setScene(scene);
        stage.setMaximized(true);
        
        // Icône de l'application (si disponible)
        try {
            stage.getIcons().add(new javafx.scene.image.Image(
                getClass().getResourceAsStream("/images/logo.png")
            ));
        } catch (Exception e) {
            System.out.println("⚠️ Logo non trouvé");
        }
        
        stage.show();
        
        System.out.println("✅ Application Lammetna démarrée");
    }
    
    private void setupKeyboardShortcuts(Scene scene) {
        // F5 pour actualiser (simuler)
        scene.getAccelerators().put(
            new KeyCodeCombination(KeyCode.F5),
            () -> System.out.println("🔄 Actualisation demandée (F5)")
        );
        
        // Ctrl+Q pour quitter
        scene.getAccelerators().put(
            new KeyCodeCombination(KeyCode.Q, KeyCombination.CONTROL_DOWN),
            () -> {
                System.out.println("👋 Fermeture de l'application");
                javafx.application.Platform.exit();
            }
        );
    }

    public static void main(String[] args) {
        launch(args);
    }
}
