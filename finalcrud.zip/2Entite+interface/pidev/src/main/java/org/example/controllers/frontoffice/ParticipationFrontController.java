package org.example.controllers.frontoffice;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.example.entities.Participation;
import org.example.entities.Evenement;
import org.example.services.ParticipationService;
import org.example.services.EvenementService;
import org.example.utils.ValidationUtils;
import java.sql.Date;
import java.time.LocalDate;

public class ParticipationFrontController {

    @FXML private TextField tfNom, tfPrenom, tfEmail, tfTelephone;
    @FXML private DatePicker dpDate;
    @FXML private ComboBox<String> cbEvenement;
    @FXML private Label lblEventDetails;
    @FXML private VBox confirmationBox;

    private final ParticipationService participationService = new ParticipationService();
    private final EvenementService evenementService = new EvenementService();
    private ObservableList<Evenement> evenements;
    private Evenement selectedEvent;

    @FXML
    public void initialize() {
        System.out.println("🔵 Initialisation de ParticipationFrontController");
        loadEvenements();
        setupEventSelection();
        dpDate.setValue(LocalDate.now());
    }

    /* ================= MÉTHODE POUR PRÉ-SÉLECTIONNER UN ÉVÉNEMENT ================= */
    public void setIdEvenement(long idEvent) {
        System.out.println("🔵 Pré-sélection de l'événement ID: " + idEvent);
        // Attendre que les événements soient chargés
        javafx.application.Platform.runLater(() -> {
            for (int i = 0; i < cbEvenement.getItems().size(); i++) {
                String item = cbEvenement.getItems().get(i);
                if (item.startsWith(idEvent + " - ")) {
                    cbEvenement.getSelectionModel().select(i);
                    System.out.println("✅ Événement pré-sélectionné: " + item);
                    break;
                }
            }
        });
    }

    /* ================= CHARGEMENT DES ÉVÉNEMENTS ================= */
    private void loadEvenements() {
        try {
            evenements = FXCollections.observableArrayList(evenementService.afficherEvenements());
            ObservableList<String> eventNames = FXCollections.observableArrayList();
            
            for (Evenement e : evenements) {
                // Afficher seulement les événements actifs
                if ("Actif".equalsIgnoreCase(e.getStatut())) {
                    eventNames.add(e.getIdEvent() + " - " + e.getTitre() + " (" + e.getDateEvent() + ")");
                }
            }
            
            cbEvenement.setItems(eventNames);
            System.out.println("✅ " + eventNames.size() + " événements actifs chargés");
        } catch (Exception e) {
            System.err.println("❌ Erreur lors du chargement des événements: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /* ================= SÉLECTION D'ÉVÉNEMENT ================= */
    private void setupEventSelection() {
        cbEvenement.setOnAction(event -> {
            String selected = cbEvenement.getValue();
            if (selected != null && !selected.isEmpty()) {
                try {
                    // Extraire l'ID de l'événement
                    long idEvent = Long.parseLong(selected.split(" - ")[0]);
                    selectedEvent = evenementService.trouverEvenementParId(idEvent);
                    
                    if (selectedEvent != null) {
                        // Afficher les détails de l'événement
                        String details = String.format(
                            "📍 %s | 📅 %s à %s | 💰 %.2f DT | 🎫 %d places disponibles",
                            selectedEvent.getLieu(),
                            selectedEvent.getDateEvent(),
                            selectedEvent.getHeureEvent(),
                            selectedEvent.getPrix(),
                            selectedEvent.getNbPlaces()
                        );
                        lblEventDetails.setText(details);
                        lblEventDetails.setVisible(true);
                        System.out.println("✅ Événement sélectionné: " + selectedEvent.getTitre());
                    }
                } catch (Exception e) {
                    System.err.println("❌ Erreur lors de la sélection: " + e.getMessage());
                }
            }
        });
    }

    /* ================= AJOUT ================= */
    @FXML
    private void ajouterParticipation() {
        if (!validateFields()) return;

        try {
            if (selectedEvent == null) {
                showAlert("Erreur", "Veuillez sélectionner un événement !");
                return;
            }

            Participation p = new Participation(
                    tfNom.getText().trim(),
                    tfPrenom.getText().trim(),
                    tfEmail.getText().trim(),
                    tfTelephone.getText().trim(),
                    Date.valueOf(dpDate.getValue()),
                    (int) selectedEvent.getIdEvent()
            );

            System.out.println("🔵 Ajout de la participation: " + tfNom.getText() + " " + tfPrenom.getText());
            participationService.ajouterParticipation(p);
            System.out.println("✅ Participation ajoutée avec succès");
            
            // Afficher le message de confirmation
            showConfirmation();
            
            // Réinitialiser le formulaire après 2 secondes
            new Thread(() -> {
                try {
                    Thread.sleep(2000);
                    javafx.application.Platform.runLater(this::clearFields);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }).start();
            
        } catch (Exception e) {
            System.err.println("❌ Erreur lors de l'ajout: " + e.getMessage());
            e.printStackTrace();
            showAlert("Erreur", "Erreur lors de l'inscription ! Veuillez réessayer.");
        }
    }

    @FXML
    private void annulerAjout() {
        clearFields();
    }

    @FXML
    private void retourAuxEvenements() {
        // Fermer la fenêtre d'inscription
        Stage stage = (Stage) tfNom.getScene().getWindow();
        stage.close();
        System.out.println("🔵 Fenêtre d'inscription fermée");
    }

    /* ================= VALIDATION ================= */
    private boolean validateFields() {
        // Vérifier que tous les champs sont remplis
        if(tfNom.getText().trim().isEmpty() || tfPrenom.getText().trim().isEmpty() ||
                tfEmail.getText().trim().isEmpty() || tfTelephone.getText().trim().isEmpty() ||
                dpDate.getValue() == null || cbEvenement.getValue() == null) {
            showAlert("Erreur", "Tous les champs sont obligatoires !");
            return false;
        }
        
        // Valider le nom
        if(!ValidationUtils.isValidName(tfNom.getText())) {
            showAlert("Erreur", "Nom invalide ! Le nom doit contenir uniquement des lettres (2-50 caractères).");
            return false;
        }
        
        // Valider le prénom
        if(!ValidationUtils.isValidName(tfPrenom.getText())) {
            showAlert("Erreur", "Prénom invalide ! Le prénom doit contenir uniquement des lettres (2-50 caractères).");
            return false;
        }
        
        // Valider l'email
        if(!ValidationUtils.isValidEmail(tfEmail.getText())) {
            showAlert("Erreur", "Email invalide ! Format attendu: exemple@domaine.com");
            return false;
        }
        
        // Valider le téléphone
        if(!ValidationUtils.isValidPhoneTN(tfTelephone.getText())) {
            showAlert("Erreur", "Téléphone invalide ! Format attendu: +216 XX XXX XXX ou XX XXX XXX\n" +
                    "Le numéro doit commencer par 2, 3, 4, 5, 7, ou 9.");
            return false;
        }
        
        // Valider la date (doit être aujourd'hui ou dans le futur)
        if(!ValidationUtils.isTodayOrFuture(dpDate.getValue())) {
            showAlert("Erreur", "Date invalide ! La date d'inscription ne peut pas être dans le passé.");
            return false;
        }
        
        return true;
    }

    /* ================= UTILITAIRES ================= */
    private void clearFields() {
        tfNom.clear();
        tfPrenom.clear();
        tfEmail.clear();
        tfTelephone.clear();
        dpDate.setValue(LocalDate.now());
        cbEvenement.setValue(null);
        lblEventDetails.setVisible(false);
        selectedEvent = null;
        confirmationBox.setVisible(false);
        confirmationBox.setManaged(false);
    }

    private void showConfirmation() {
        confirmationBox.setVisible(true);
        confirmationBox.setManaged(true);
    }

    private void showAlert(String title, String msg) {
        Alert alert = new Alert(
            title.equals("Erreur") ? Alert.AlertType.ERROR : Alert.AlertType.INFORMATION
        );
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
