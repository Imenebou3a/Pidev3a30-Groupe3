package org.example.controllers.main;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.layout.StackPane;

public class MainLayoutController {

    @FXML
    private StackPane contentPane;

    @FXML
    public void initialize() {
        System.out.println("🔵 MainLayoutController - initialize() appelé");
        // Page par défaut
        loadPage("/fxml/backoffice/EvenementBack.fxml");
    }

    private void loadPage(String path) {
        try {
            System.out.println("🔵 Chargement de la page: " + path);
            
            // Afficher un indicateur de chargement
            contentPane.setOpacity(0.5);
            
            Parent page = FXMLLoader.load(getClass().getResource(path));
            contentPane.getChildren().clear();
            contentPane.getChildren().add(page);
            
            // Animation de fondu
            javafx.animation.FadeTransition fade = new javafx.animation.FadeTransition(
                javafx.util.Duration.millis(300), contentPane
            );
            fade.setFromValue(0.5);
            fade.setToValue(1.0);
            fade.play();
            
            System.out.println("✅ Page chargée avec succès: " + path);
        } catch (Exception e) {
            System.err.println("❌ Erreur chargement : " + path);
            e.printStackTrace();
            
            // Afficher une erreur à l'utilisateur
            javafx.scene.control.Alert alert = new javafx.scene.control.Alert(
                javafx.scene.control.Alert.AlertType.ERROR
            );
            alert.setTitle("Erreur");
            alert.setHeaderText("Impossible de charger la page");
            alert.setContentText("Erreur: " + e.getMessage());
            alert.showAndWait();
        }
    }

    @FXML
    private void openEvenementBack() {
        loadPage("/fxml/backoffice/EvenementBack.fxml");
    }

    @FXML
    private void openParticipationBack() {
        loadPage("/fxml/backoffice/ParticipationBack.fxml");
    }

    @FXML
    private void openEvenementFront() {
        loadPage("/fxml/frontoffice/EvenementFrontSimple.fxml");
    }

    @FXML
    private void openParticipationFront() {
        loadPage("/fxml/frontoffice/ParticipationFrontSimple.fxml");
    }
    
    @FXML
    private void openParametres() {
        javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.INFORMATION);
        alert.setTitle("Paramètres");
        alert.setHeaderText("⚙️ Configuration de l'application");
        alert.setContentText("Fonctionnalité en cours de développement.\n\n" +
                "Prochainement disponible:\n" +
                "• Gestion des préférences\n" +
                "• Configuration de la base de données\n" +
                "• Personnalisation de l'interface");
        alert.showAndWait();
    }
    
    @FXML
    private void openAPropos() {
        javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.INFORMATION);
        alert.setTitle("À propos");
        alert.setHeaderText("ℹ️ Lammetna - Gestion d'Événements");
        alert.setContentText("Version: 1.0.0\n" +
                "Développé par: Votre équipe\n" +
                "Année: 2024\n\n" +
                "Description:\n" +
                "Application de gestion d'événements culturels et festifs.\n\n" +
                "Modules:\n" +
                "• Gestion des événements (CRUD)\n" +
                "• Gestion des participations\n" +
                "• Interface publique et administrative\n\n" +
                "Technologies:\n" +
                "• JavaFX 17\n" +
                "• MySQL/MariaDB\n" +
                "• Maven");
        alert.showAndWait();
    }
}
