package org.example.controllers.backoffice;

import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.TextAlignment;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;
import org.example.entities.Participation;
import org.example.services.ParticipationService;

import java.io.File;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.Set;

public class ParticipationBackController {

    @FXML private TabPane tabPane;
    @FXML private Tab tabAfficher;
    @FXML private Tab tabModifier;

    @FXML private TableView<Participation> tableParticipation;
    @FXML private TableColumn<Participation, Integer> colId;
    @FXML private TableColumn<Participation, String> colNom;
    @FXML private TableColumn<Participation, String> colPrenom;
    @FXML private TableColumn<Participation, String> colEmail;
    @FXML private TableColumn<Participation, String> colTelephone;
    @FXML private TableColumn<Participation, Date> colDate;
    @FXML private TableColumn<Participation, Integer> colEvent;
    @FXML private TableColumn<Participation, Void> colAction;

    @FXML private TextField tfIdModif, tfNomModif, tfPrenomModif, tfEmailModif,
            tfTelephoneModif, tfEventModif;
    @FXML private DatePicker dpDateModif;

    // Recherche et filtres
    @FXML private TextField txtRecherche;
    @FXML private DatePicker dpFiltreDate;
    @FXML private TextField txtFiltreEvent;
    @FXML private Label lblTotalParticipants;
    @FXML private Label lblAujourdhui;
    @FXML private Label lblEventsUniques;

    private final ParticipationService participationService = new ParticipationService();
    private final ObservableList<Participation> list = FXCollections.observableArrayList();
    private FilteredList<Participation> filteredList;

    @FXML
    public void initialize() {
        System.out.println("🔵 ParticipationBackController - initialize() appelé");
        
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        colPrenom.setCellValueFactory(new PropertyValueFactory<>("prenom"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colTelephone.setCellValueFactory(new PropertyValueFactory<>("telephone"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("date"));
        colEvent.setCellValueFactory(new PropertyValueFactory<>("idEvent"));

        loadData();
        addActionButtons();
        setupSearchAndFilters();
    }

    private void setupSearchAndFilters() {
        filteredList = new FilteredList<>(list, p -> true);
        tableParticipation.setItems(filteredList);

        // Recherche dynamique
        txtRecherche.textProperty().addListener((observable, oldValue, newValue) -> {
            applyFilters();
        });

        // Filtre par date
        dpFiltreDate.valueProperty().addListener((observable, oldValue, newValue) -> {
            applyFilters();
        });

        // Filtre par event
        txtFiltreEvent.textProperty().addListener((observable, oldValue, newValue) -> {
            applyFilters();
        });
    }

    private void applyFilters() {
        filteredList.setPredicate(participation -> {
            String searchText = txtRecherche.getText();
            LocalDate dateFilter = dpFiltreDate.getValue();
            String eventFilter = txtFiltreEvent.getText();

            // Filtre de recherche
            if (searchText != null && !searchText.isEmpty()) {
                String lowerCaseFilter = searchText.toLowerCase();
                if (!participation.getNom().toLowerCase().contains(lowerCaseFilter) &&
                    !participation.getPrenom().toLowerCase().contains(lowerCaseFilter) &&
                    !participation.getEmail().toLowerCase().contains(lowerCaseFilter)) {
                    return false;
                }
            }

            // Filtre par date
            if (dateFilter != null) {
                if (!participation.getDate().toLocalDate().equals(dateFilter)) {
                    return false;
                }
            }

            // Filtre par event
            if (eventFilter != null && !eventFilter.isEmpty()) {
                try {
                    int eventId = Integer.parseInt(eventFilter);
                    if (participation.getIdEvent() != eventId) {
                        return false;
                    }
                } catch (NumberFormatException e) {
                    return false;
                }
            }

            return true;
        });

        updateStatistics();
    }

    private void updateStatistics() {
        int total = filteredList.size();
        
        LocalDate today = LocalDate.now();
        int aujourdhui = (int) filteredList.stream()
                .filter(p -> p.getDate().toLocalDate().equals(today))
                .count();

        Set<Integer> uniqueEvents = new HashSet<>();
        filteredList.forEach(p -> uniqueEvents.add(p.getIdEvent()));
        int eventsUniques = uniqueEvents.size();

        lblTotalParticipants.setText(String.valueOf(total));
        lblAujourdhui.setText(String.valueOf(aujourdhui));
        lblEventsUniques.setText(String.valueOf(eventsUniques));
    }

    @FXML
    private void reinitialiserFiltres() {
        txtRecherche.clear();
        dpFiltreDate.setValue(null);
        txtFiltreEvent.clear();
    }

    @FXML
    public void loadData() {
        System.out.println("🔵 Chargement des participations...");
        list.clear();
        list.addAll(participationService.afficherParticipations());
        System.out.println("📊 Nombre de participations récupérées: " + list.size());
        if (filteredList != null) {
            updateStatistics();
        }
    }

    private void addActionButtons() {
        colAction.setCellFactory(param -> new TableCell<>() {
            private final Button btnModifier = new Button("Modifier");
            private final Button btnSupprimer = new Button("Supprimer");
            private final HBox pane = new HBox(5, btnModifier, btnSupprimer);

            {
                btnModifier.setStyle("-fx-background-color: #60a5fa; -fx-text-fill: white; -fx-font-weight: bold;");
                btnSupprimer.setStyle("-fx-background-color: #f87171; -fx-text-fill: white; -fx-font-weight: bold;");

                btnModifier.setOnAction(event -> {
                    Participation p = getTableView().getItems().get(getIndex());
                    remplirFormulaire(p);
                    javafx.application.Platform.runLater(() -> {
                        if (tabPane != null && tabModifier != null) {
                            tabPane.getSelectionModel().select(tabModifier);
                        }
                    });
                });

                btnSupprimer.setOnAction(event -> {
                    Participation p = getTableView().getItems().get(getIndex());
                    Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
                    confirm.setTitle("Confirmation");
                    confirm.setHeaderText("Supprimer la participation");
                    confirm.setContentText("Voulez-vous vraiment supprimer la participation de " + 
                                          p.getNom() + " " + p.getPrenom() + " ?");
                    
                    confirm.showAndWait().ifPresent(response -> {
                        if (response == ButtonType.OK) {
                            participationService.supprimerParticipation(p.getId());
                            loadData();
                            showAlert("Succès", "Participation supprimée !");
                        }
                    });
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : pane);
            }
        });
    }

    private void remplirFormulaire(Participation p) {
        tfIdModif.setText(String.valueOf(p.getId()));
        tfNomModif.setText(p.getNom());
        tfPrenomModif.setText(p.getPrenom());
        tfEmailModif.setText(p.getEmail());
        tfTelephoneModif.setText(p.getTelephone());
        dpDateModif.setValue(p.getDate().toLocalDate());
        tfEventModif.setText(String.valueOf(p.getIdEvent()));
    }

    @FXML
    private void confirmerModification() {
        if(!validateFields()) return;

        try {
            int idEvent = Integer.parseInt(tfEventModif.getText());
            int id = Integer.parseInt(tfIdModif.getText());

            Participation p = new Participation(id,
                    tfNomModif.getText(),
                    tfPrenomModif.getText(),
                    tfEmailModif.getText(),
                    tfTelephoneModif.getText(),
                    Date.valueOf(dpDateModif.getValue()),
                    idEvent
            );

            participationService.modifierParticipation(p);
            showAlert("Succès", "Participation modifiée !");
            clearFields();
            loadData();
            
            // Retourner à l'onglet Afficher
            if (tabPane != null && tabAfficher != null) {
                tabPane.getSelectionModel().select(tabAfficher);
            }

        } catch (NumberFormatException e) {
            showAlert("Erreur", "ID ou ID Event invalide !");
        }
    }

    @FXML
    private void annulerModification() {
        clearFields();
        if (tabPane != null && tabAfficher != null) {
            tabPane.getSelectionModel().select(tabAfficher);
        }
    }

    private boolean validateFields() {
        if(tfNomModif.getText().isEmpty() || tfPrenomModif.getText().isEmpty() ||
                tfEmailModif.getText().isEmpty() || tfTelephoneModif.getText().isEmpty() ||
                dpDateModif.getValue() == null ||
                tfEventModif.getText().isEmpty() || tfIdModif.getText().isEmpty()) {
            showAlert("Erreur", "Tous les champs sont obligatoires !");
            return false;
        }
        if(!tfEmailModif.getText().matches("^\\S+@\\S+\\.\\S+$")) { 
            showAlert("Erreur", "Email invalide !"); 
            return false; 
        }
        if(!tfTelephoneModif.getText().matches("\\d{8,15}")) { 
            showAlert("Erreur", "Téléphone invalide !"); 
            return false; 
        }
        if(!tfNomModif.getText().matches("[a-zA-Z ]+")) { 
            showAlert("Erreur", "Nom invalide !"); 
            return false; 
        }
        if(!tfPrenomModif.getText().matches("[a-zA-Z ]+")) { 
            showAlert("Erreur", "Prénom invalide !"); 
            return false; 
        }
        if(!tfEventModif.getText().matches("\\d+")) { 
            showAlert("Erreur", "ID Event invalide !"); 
            return false; 
        }
        if(!tfIdModif.getText().matches("\\d+")) { 
            showAlert("Erreur", "ID invalide !"); 
            return false; 
        }
        return true;
    }

    private void clearFields() {
        tfIdModif.clear(); 
        tfNomModif.clear(); 
        tfPrenomModif.clear(); 
        tfEmailModif.clear();
        tfTelephoneModif.clear(); 
        dpDateModif.setValue(null);  
        tfEventModif.clear();
    }

    private void showAlert(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title); 
        alert.setHeaderText(null); 
        alert.setContentText(msg);
        alert.showAndWait();
    }

    // ================= EXPORT PDF =================
    @FXML
    private void exporterPDF() {
        try {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Enregistrer le PDF");
            fileChooser.setInitialFileName("participations_" + LocalDate.now() + ".pdf");
            fileChooser.getExtensionFilters().add(
                    new FileChooser.ExtensionFilter("PDF Files", "*.pdf")
            );

            File file = fileChooser.showSaveDialog(tableParticipation.getScene().getWindow());
            if (file != null) {
                PdfWriter writer = new PdfWriter(file.getAbsolutePath());
                PdfDocument pdfDoc = new PdfDocument(writer);
                Document document = new Document(pdfDoc);

                // Titre
                Paragraph title = new Paragraph("Liste des Participations")
                        .setFontSize(20)
                        .setBold()
                        .setTextAlignment(TextAlignment.CENTER);
                document.add(title);

                document.add(new Paragraph("Date d'export: " + LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")))
                        .setTextAlignment(TextAlignment.CENTER));
                document.add(new Paragraph("\n"));

                // Table
                Table table = new Table(new float[]{1, 3, 3, 4, 3, 2, 2});
                table.setWidth(com.itextpdf.layout.properties.UnitValue.createPercentValue(100));

                // En-têtes
                table.addHeaderCell("ID");
                table.addHeaderCell("Nom");
                table.addHeaderCell("Prénom");
                table.addHeaderCell("Email");
                table.addHeaderCell("Téléphone");
                table.addHeaderCell("Date");
                table.addHeaderCell("ID Event");

                // Données
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                for (Participation p : filteredList) {
                    table.addCell(String.valueOf(p.getId()));
                    table.addCell(p.getNom());
                    table.addCell(p.getPrenom());
                    table.addCell(p.getEmail());
                    table.addCell(p.getTelephone());
                    table.addCell(p.getDate().toLocalDate().format(formatter));
                    table.addCell(String.valueOf(p.getIdEvent()));
                }

                document.add(table);

                // Statistiques
                document.add(new Paragraph("\n\nStatistiques:"));
                document.add(new Paragraph("Total de participations: " + filteredList.size()));
                
                Set<Integer> uniqueEvents = new HashSet<>();
                filteredList.forEach(p -> uniqueEvents.add(p.getIdEvent()));
                document.add(new Paragraph("Événements concernés: " + uniqueEvents.size()));

                document.close();

                showAlert("Succès", "PDF exporté avec succès !\n" + file.getAbsolutePath());
            }
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur", "Erreur lors de l'export PDF: " + e.getMessage());
        }
    }
}
