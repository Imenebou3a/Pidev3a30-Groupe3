package org.example.tests.services;

import org.example.entities.Evenement;
import org.example.services.EvenementService;
import org.junit.jupiter.api.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class EvenementServiceTest {

    private static EvenementService service;
    private Evenement testEvent;
    private static List<Long> testEventIds = new java.util.ArrayList<>();

    @BeforeAll
    static void initService() {
        service = new EvenementService();
    }

    @BeforeEach
    void setUp() {
        testEvent = new Evenement(
                "Event Test",
                "Description test",
                LocalDate.of(2026, 1, 1),
                "10:00", // ✅ String au lieu de LocalTime
                "Esprit",
                20.0,
                100,
                "Actif"
        );
    }

    @AfterAll
    static void cleanup() {
        // Nettoyer tous les événements de test créés
        System.out.println("🧹 Nettoyage des événements de test...");
        for (Long id : testEventIds) {
            try {
                service.supprimerEvenement(id);
                System.out.println("✅ Événement test " + id + " supprimé");
            } catch (Exception e) {
                System.err.println("⚠️ Impossible de supprimer l'événement " + id);
            }
        }
        testEventIds.clear();
    }

    @Test
    @Order(1)
    void testAjouterEvenement() {
        service.ajouterEvenement(testEvent);
        testEventIds.add(testEvent.getIdEvent()); // Sauvegarder l'ID pour nettoyage
        Evenement retrieved = service.trouverEvenementParId(testEvent.getIdEvent());
        assertNotNull(retrieved, "L'événement doit être ajouté avec succès");
        assertEquals("Event Test", retrieved.getTitre());
    }

    @Test
    @Order(2)
    void testModifierEvenement() {
        service.ajouterEvenement(testEvent);
        testEventIds.add(testEvent.getIdEvent()); // Sauvegarder l'ID
        testEvent.setLieu("Tunis");
        testEvent.setPrix(30.0);
        service.modifierEvenement(testEvent);

        Evenement retrieved = service.trouverEvenementParId(testEvent.getIdEvent());
        assertEquals("Tunis", retrieved.getLieu());
        assertEquals(30.0, retrieved.getPrix());
    }

    @Test
    @Order(3)
    void testSupprimerEvenement() {
        service.ajouterEvenement(testEvent);
        long idToDelete = testEvent.getIdEvent();
        service.supprimerEvenement(idToDelete);

        Evenement retrieved = service.trouverEvenementParId(idToDelete);
        assertNull(retrieved, "L'événement supprimé ne doit plus exister");
        // Pas besoin d'ajouter à testEventIds car déjà supprimé
    }

    @Test
    @Order(4)
    void testListeEvenements() {
        service.ajouterEvenement(testEvent);
        testEventIds.add(testEvent.getIdEvent()); // Sauvegarder l'ID
        List<Evenement> events = service.afficherEvenements(); // ✅ utiliser afficherEvenements()
        assertNotNull(events, "La liste des événements ne doit pas être nulle");
        assertTrue(events.stream().anyMatch(e -> e.getIdEvent() == testEvent.getIdEvent()),
                "La liste doit contenir l'événement ajouté");
    }
}
