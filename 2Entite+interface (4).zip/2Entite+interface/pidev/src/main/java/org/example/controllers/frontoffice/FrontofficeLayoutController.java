package org.example.controllers.frontoffice;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import org.example.utils.AnimationUtils;
import org.example.utils.Constants;
import org.example.utils.Logger;

/**
 * Contrôleur du layout Front Office
 */
public class FrontofficeLayoutController {

    private static final Logger logger = Logger.getLogger(FrontofficeLayoutController.class);

    @FXML
    private StackPane contentPane;

    @FXML
    public void initialize() {
        logger.info("FrontofficeLayoutController - Initialisation");
        loadPage(Constants.FXML_EVENEMENT_FRONT);
    }

    private void loadPage(String path) {
        try {
            logger.debug("Chargement: " + path);
            contentPane.setOpacity(Constants.ANIMATION_FADE_FROM);
            
            Parent page = FXMLLoader.load(getClass().getResource(path));
            contentPane.getChildren().clear();
            contentPane.getChildren().add(page);
            
            AnimationUtils.pageTransition(contentPane);
            logger.info("Page chargée: " + path);
        } catch (Exception e) {
            logger.error("Erreur chargement: " + path, e);
        }
    }

    @FXML
    private void openEvenements() {
        loadPage(Constants.FXML_EVENEMENT_FRONT);
    }

    @FXML
    private void openInscription() {
        loadPage(Constants.FXML_PARTICIPATION_FRONT);
    }

    @FXML
    private void openBackoffice() {
        try {
            logger.info("Ouverture du Back Office...");
            
            // Charger le layout Back Office
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/backoffice/BackofficeLayout.fxml"));
            
            // Créer une nouvelle fenêtre
            Stage backStage = new Stage();
            Scene scene = new Scene(root);
            
            backStage.setTitle("Lammetna - Back Office");
            backStage.setScene(scene);
            backStage.setMaximized(true);
            
            // Ajouter l'icône
            try {
                backStage.getIcons().add(new javafx.scene.image.Image(
                    getClass().getResourceAsStream("/images/logo.png")
                ));
            } catch (Exception e) {
                logger.info("Logo non trouvé pour Back Office");
            }
            
            backStage.show();
            logger.info("Back Office ouvert avec succès");
            
        } catch (Exception e) {
            logger.error("Erreur lors de l'ouverture du Back Office", e);
            
            javafx.scene.control.Alert alert = new javafx.scene.control.Alert(
                javafx.scene.control.Alert.AlertType.ERROR
            );
            alert.setTitle("Erreur");
            alert.setHeaderText("Impossible d'ouvrir le Back Office");
            alert.setContentText("Erreur: " + e.getMessage());
            alert.showAndWait();
        }
    }
}
