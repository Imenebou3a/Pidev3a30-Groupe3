package org.example.entities;

import javafx.beans.property.*;
import java.sql.Date;

public class Participation {

    private IntegerProperty id = new SimpleIntegerProperty();
    private StringProperty nom = new SimpleStringProperty();
    private StringProperty prenom = new SimpleStringProperty();
    private StringProperty email = new SimpleStringProperty();
    private StringProperty telephone = new SimpleStringProperty();
    private ObjectProperty<Date> date = new SimpleObjectProperty<>();
    private IntegerProperty idEvent = new SimpleIntegerProperty();

    // Constructeur pour ajout (sans ID)
    public Participation(String nom, String prenom, String email, String telephone, Date date, int idEvent) {
        this.nom.set(nom);
        this.prenom.set(prenom);
        this.email.set(email);
        this.telephone.set(telephone);
        this.date.set(date);
        this.idEvent.set(idEvent);
    }

    // Constructeur complet (avec ID)
    public Participation(int id, String nom, String prenom, String email, String telephone, Date date,  int idEvent) {
        this(nom, prenom, email, telephone, date, idEvent);
        this.id.set(id);
    }

    // Getters & Setters
    public int getId() { return id.get(); }
    public void setId(int id) { this.id.set(id); }
    public IntegerProperty idProperty() { return id; }

    public String getNom() { return nom.get(); }
    public void setNom(String nom) { this.nom.set(nom); }
    public StringProperty nomProperty() { return nom; }

    public String getPrenom() { return prenom.get(); }
    public void setPrenom(String prenom) { this.prenom.set(prenom); }
    public StringProperty prenomProperty() { return prenom; }

    public String getEmail() { return email.get(); }
    public void setEmail(String email) { this.email.set(email); }
    public StringProperty emailProperty() { return email; }

    public String getTelephone() { return telephone.get(); }
    public void setTelephone(String telephone) { this.telephone.set(telephone); }
    public StringProperty telephoneProperty() { return telephone; }

    public Date getDate() { return date.get(); }
    public void setDate(Date date) { this.date.set(date); }
    public ObjectProperty<Date> dateProperty() { return date; }


    public int getIdEvent() { return idEvent.get(); }
    public void setIdEvent(int idEvent) { this.idEvent.set(idEvent); }
    public IntegerProperty idEventProperty() { return idEvent; }
}
