package org.example.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Logger simple et professionnel pour l'application
 * Alternative légère à SLF4J pour ce projet
 */
public class Logger {
    
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final boolean DEBUG_MODE = true; // Mettre à false en production
    
    private final String className;
    
    public Logger(Class<?> clazz) {
        this.className = clazz.getSimpleName();
    }
    
    public static Logger getLogger(Class<?> clazz) {
        return new Logger(clazz);
    }
    
    public void info(String message) {
        log("INFO", message, null);
    }
    
    public void debug(String message) {
        if (DEBUG_MODE) {
            log("DEBUG", message, null);
        }
    }
    
    public void warn(String message) {
        log("WARN", message, null);
    }
    
    public void error(String message) {
        log("ERROR", message, null);
    }
    
    public void error(String message, Throwable throwable) {
        log("ERROR", message, throwable);
    }
    
    private void log(String level, String message, Throwable throwable) {
        String timestamp = LocalDateTime.now().format(FORMATTER);
        String logMessage = String.format("[%s] [%s] [%s] %s", 
            timestamp, level, className, message);
        
        if ("ERROR".equals(level) || "WARN".equals(level)) {
            System.err.println(logMessage);
            if (throwable != null) {
                throwable.printStackTrace();
            }
        } else {
            System.out.println(logMessage);
        }
    }
}
