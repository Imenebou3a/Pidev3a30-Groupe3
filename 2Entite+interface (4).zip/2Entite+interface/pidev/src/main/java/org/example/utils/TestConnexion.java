package org.example.utils;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Classe de test pour vérifier la connexion à la base de données
 */
public class TestConnexion {
    
    public static void main(String[] args) {
        System.out.println("=== Test de connexion à la base de données ===\n");
        
        try {
            // Récupération de la connexion
            Connection connection = MyDataBase.getConnection();
            
            if (connection != null && !connection.isClosed()) {
                System.out.println("✅ Connexion réussie !");
                System.out.println("📊 Base de données : " + connection.getCatalog());
                System.out.println("🔗 URL : " + connection.getMetaData().getURL());
                System.out.println("👤 Utilisateur : " + connection.getMetaData().getUserName());
                System.out.println("🔧 Driver : " + connection.getMetaData().getDriverName());
                System.out.println("📌 Version : " + connection.getMetaData().getDriverVersion());
            } else {
                System.err.println("❌ Échec de la connexion !");
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Erreur SQL : " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("❌ Erreur : " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println("\n=== Fin du test ===");
    }
}
