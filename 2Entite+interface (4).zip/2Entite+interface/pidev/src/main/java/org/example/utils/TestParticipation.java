package org.example.utils;

import org.example.entities.Participation;
import org.example.services.ParticipationService;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

/**
 * Classe de test pour les opérations CRUD sur les participations
 */
public class TestParticipation {
    
    private static final ParticipationService service = new ParticipationService();
    
    public static void main(String[] args) {
        System.out.println("=== Test des opérations sur les Participations ===\n");
        
        try {
            // Test 1: Afficher toutes les participations
            testAfficher();
            
            // Test 2: Ajouter une participation
            testAjouter();
            
            // Test 3: Modifier une participation
            // testModifier();
            
            // Test 4: Supprimer une participation
            // testSupprimer();
            
        } catch (Exception e) {
            System.err.println("❌ Erreur lors du test : " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println("\n=== Fin des tests ===");
    }
    
    private static void testAfficher() {
        System.out.println("📋 Test 1: Affichage de toutes les participations");
        System.out.println("─────────────────────────────────────────────────");
        
        List<Participation> participations = service.afficherParticipations();
        System.out.println("Nombre de participations : " + participations.size());
        
        for (Participation p : participations) {
            System.out.println("  • " + p.getNom() + " " + p.getPrenom() + 
                             " - Event ID: " + p.getIdEvent() + 
                             " - " + p.getEmail());
        }
        System.out.println();
    }
    
    private static void testAjouter() {
        System.out.println("➕ Test 2: Ajout d'une participation");
        System.out.println("─────────────────────────────────────────────────");
        
        Participation nouvelleParticipation = new Participation(
            "Ben Salah",
            "Sami",
            "sami.bensalah@example.com",
            "+216 98 765 432",
            Date.valueOf(LocalDate.now()),
            1 // ID d'un événement existant
        );
        
        try {
            service.ajouterParticipation(nouvelleParticipation);
            System.out.println("✅ Participation ajoutée avec succès !");
            System.out.println("   ID généré : " + nouvelleParticipation.getId());
        } catch (Exception e) {
            System.err.println("❌ Erreur lors de l'ajout : " + e.getMessage());
        }
        System.out.println();
    }
    
    private static void testModifier() {
        System.out.println("✏️ Test 3: Modification d'une participation");
        System.out.println("─────────────────────────────────────────────────");
        
        List<Participation> participations = service.afficherParticipations();
        if (!participations.isEmpty()) {
            Participation participation = participations.get(0);
            participation.setTelephone("+216 20 123 456");
            
            try {
                service.modifierParticipation(participation);
                System.out.println("✅ Participation modifiée avec succès !");
            } catch (Exception e) {
                System.err.println("❌ Erreur lors de la modification : " + e.getMessage());
            }
        } else {
            System.out.println("⚠️ Aucune participation à modifier");
        }
        System.out.println();
    }
    
    private static void testSupprimer() {
        System.out.println("🗑️ Test 4: Suppression d'une participation");
        System.out.println("─────────────────────────────────────────────────");
        
        List<Participation> participations = service.afficherParticipations();
        if (!participations.isEmpty()) {
            Participation derniereParticipation = participations.get(participations.size() - 1);
            
            try {
                service.supprimerParticipation(derniereParticipation.getId());
                System.out.println("✅ Participation supprimée avec succès !");
            } catch (Exception e) {
                System.err.println("❌ Erreur lors de la suppression : " + e.getMessage());
            }
        } else {
            System.out.println("⚠️ Aucune participation à supprimer");
        }
        System.out.println();
    }
}
