package org.example.utils;

import javafx.animation.*;
import javafx.scene.Node;
import javafx.util.Duration;

/**
 * Classe utilitaire pour les animations JavaFX
 * Fournit des animations réutilisables et professionnelles
 */
public class AnimationUtils {

    /**
     * Animation de fondu entrant
     */
    public static void fadeIn(Node node, int durationMs) {
        FadeTransition fade = new FadeTransition(Duration.millis(durationMs), node);
        fade.setFromValue(0.0);
        fade.setToValue(1.0);
        fade.play();
    }

    /**
     * Animation de fondu sortant
     */
    public static void fadeOut(Node node, int durationMs) {
        FadeTransition fade = new FadeTransition(Duration.millis(durationMs), node);
        fade.setFromValue(1.0);
        fade.setToValue(0.0);
        fade.play();
    }

    /**
     * Animation de glissement depuis le haut
     */
    public static void slideInFromTop(Node node, int durationMs) {
        TranslateTransition slide = new TranslateTransition(Duration.millis(durationMs), node);
        slide.setFromY(-100);
        slide.setToY(0);
        
        FadeTransition fade = new FadeTransition(Duration.millis(durationMs), node);
        fade.setFromValue(0.0);
        fade.setToValue(1.0);
        
        ParallelTransition parallel = new ParallelTransition(slide, fade);
        parallel.play();
    }

    /**
     * Animation de zoom
     */
    public static void zoomIn(Node node, int durationMs) {
        ScaleTransition scale = new ScaleTransition(Duration.millis(durationMs), node);
        scale.setFromX(0.8);
        scale.setFromY(0.8);
        scale.setToX(1.0);
        scale.setToY(1.0);
        
        FadeTransition fade = new FadeTransition(Duration.millis(durationMs), node);
        fade.setFromValue(0.0);
        fade.setToValue(1.0);
        
        ParallelTransition parallel = new ParallelTransition(scale, fade);
        parallel.play();
    }

    /**
     * Animation de secousse (pour les erreurs)
     */
    public static void shake(Node node) {
        TranslateTransition shake = new TranslateTransition(Duration.millis(50), node);
        shake.setFromX(0);
        shake.setByX(10);
        shake.setCycleCount(6);
        shake.setAutoReverse(true);
        shake.play();
    }

    /**
     * Animation de pulsation (pour attirer l'attention)
     */
    public static void pulse(Node node) {
        ScaleTransition pulse = new ScaleTransition(Duration.millis(200), node);
        pulse.setToX(1.1);
        pulse.setToY(1.1);
        pulse.setCycleCount(2);
        pulse.setAutoReverse(true);
        pulse.play();
    }

    /**
     * Animation de rotation
     */
    public static void rotate(Node node, int durationMs, double angle) {
        RotateTransition rotate = new RotateTransition(Duration.millis(durationMs), node);
        rotate.setByAngle(angle);
        rotate.play();
    }

    /**
     * Animation de chargement de page avec fondu
     */
    public static void pageTransition(Node node) {
        FadeTransition fade = new FadeTransition(Duration.millis(Constants.ANIMATION_DURATION_MS), node);
        fade.setFromValue(Constants.ANIMATION_FADE_FROM);
        fade.setToValue(Constants.ANIMATION_FADE_TO);
        fade.play();
    }
}
