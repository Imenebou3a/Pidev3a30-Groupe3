package org.example.services;

import org.example.entities.Evenement;
import org.example.utils.MyDataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EvenementService {

    private final Connection conn;

    public EvenementService() {
        conn = MyDataBase.getConnection();
    }

    // 🔹 CREATE
    public boolean ajouterEvenement(Evenement e) {
        String sql = "INSERT INTO evenement (titre, description, date_event, heure_event, lieu, prix, nb_places, statut) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        System.out.println("🔵 EvenementService - Ajout événement: " + e.getTitre());
        
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, e.getTitre());
            ps.setString(2, e.getDescription());
            ps.setDate(3, Date.valueOf(e.getDateEvent()));
            ps.setString(4, e.getHeureEvent());
            ps.setString(5, e.getLieu());
            ps.setDouble(6, e.getPrix());
            ps.setInt(7, e.getNbPlaces());
            ps.setString(8, e.getStatut());

            System.out.println("📝 Exécution de la requête SQL...");
            int rows = ps.executeUpdate();
            System.out.println("📊 Nombre de lignes affectées: " + rows);
            
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                long generatedId = rs.getLong(1);
                e.setIdEvent(generatedId);
                System.out.println("✅ ID généré: " + generatedId);
            }
            
            return rows > 0;
        } catch (SQLException ex) {
            System.err.println("❌ Erreur SQL lors de l'ajout: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        }
    }

    // 🔹 READ : tous les événements
    public List<Evenement> afficherEvenements() {
        List<Evenement> evenements = new ArrayList<>();
        String sql = "SELECT * FROM evenement ORDER BY date_event DESC";
        
        System.out.println("🔵 EvenementService - Récupération de tous les événements...");
        
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            
            int count = 0;
            while (rs.next()) {
                Evenement e = new Evenement();
                e.setIdEvent(rs.getLong("id_event"));
                e.setTitre(rs.getString("titre"));
                e.setDescription(rs.getString("description"));
                e.setDateEvent(rs.getDate("date_event").toLocalDate());
                e.setHeureEvent(rs.getString("heure_event"));
                e.setLieu(rs.getString("lieu"));
                e.setPrix(rs.getDouble("prix"));
                e.setNbPlaces(rs.getInt("nb_places"));
                e.setStatut(rs.getString("statut"));
                evenements.add(e);
                count++;
            }
            
            System.out.println("✅ " + count + " événement(s) récupéré(s)");
            
        } catch (SQLException ex) {
            System.err.println("❌ Erreur SQL lors de la récupération: " + ex.getMessage());
            ex.printStackTrace();
        }
        return evenements;
    }

    // 🔹 READ : par ID
    public Evenement trouverEvenementParId(long id) {
        Evenement e = null;
        String sql = "SELECT * FROM evenement WHERE id_event=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    e = new Evenement();
                    e.setIdEvent(rs.getLong("id_event"));
                    e.setTitre(rs.getString("titre"));
                    e.setDescription(rs.getString("description"));
                    e.setDateEvent(rs.getDate("date_event").toLocalDate());
                    e.setHeureEvent(rs.getString("heure_event"));
                    e.setLieu(rs.getString("lieu"));
                    e.setPrix(rs.getDouble("prix"));
                    e.setNbPlaces(rs.getInt("nb_places"));
                    e.setStatut(rs.getString("statut"));
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return e;
    }

    // 🔹 UPDATE
    public boolean modifierEvenement(Evenement e) {
        String sql = "UPDATE evenement SET titre=?, description=?, date_event=?, heure_event=?, lieu=?, prix=?, nb_places=?, statut=? " +
                "WHERE id_event=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, e.getTitre());
            ps.setString(2, e.getDescription());
            ps.setDate(3, Date.valueOf(e.getDateEvent()));
            ps.setString(4, e.getHeureEvent());
            ps.setString(5, e.getLieu());
            ps.setDouble(6, e.getPrix());
            ps.setInt(7, e.getNbPlaces());
            ps.setString(8, e.getStatut());
            ps.setLong(9, e.getIdEvent());
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    // 🔹 DELETE
    public boolean supprimerEvenement(long idEvent) {
        String sql = "DELETE FROM evenement WHERE id_event=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, idEvent);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
}
