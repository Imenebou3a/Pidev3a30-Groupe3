package org.example;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.stage.Stage;

/**
 * Application Back Office - Interface d'administration
 * Permet de gérer les événements et participations
 */
public class MainBackoffice extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/fxml/backoffice/BackofficeLayout.fxml"));
        Scene scene = new Scene(root);
        
        // Raccourcis clavier
        setupKeyboardShortcuts(scene);
        
        stage.setTitle("Lammetna - Back Office");
        stage.setScene(scene);
        stage.setMaximized(true);
        
        // Icône
        try {
            stage.getIcons().add(new javafx.scene.image.Image(
                getClass().getResourceAsStream("/images/logo.png")
            ));
        } catch (Exception e) {
            System.out.println("⚠️ Logo non trouvé");
        }
        
        stage.show();
        System.out.println("✅ Back Office Lammetna démarré");
    }
    
    private void setupKeyboardShortcuts(Scene scene) {
        scene.getAccelerators().put(
            new KeyCodeCombination(KeyCode.F5),
            () -> System.out.println("🔄 Actualisation (F5)")
        );
        
        scene.getAccelerators().put(
            new KeyCodeCombination(KeyCode.Q, KeyCombination.CONTROL_DOWN),
            () -> {
                System.out.println("👋 Fermeture Back Office");
                javafx.application.Platform.exit();
            }
        );
    }

    public static void main(String[] args) {
        launch(args);
    }
}
