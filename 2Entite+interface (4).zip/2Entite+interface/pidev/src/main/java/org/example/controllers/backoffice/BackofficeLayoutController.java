package org.example.controllers.backoffice;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import org.example.utils.AnimationUtils;
import org.example.utils.Constants;
import org.example.utils.Logger;

/**
 * Contrôleur du layout Back Office
 */
public class BackofficeLayoutController {

    private static final Logger logger = Logger.getLogger(BackofficeLayoutController.class);

    @FXML
    private StackPane contentPane;

    @FXML
    public void initialize() {
        logger.info("BackofficeLayoutController - Initialisation");
        loadPage(Constants.FXML_EVENEMENT_BACK);
    }

    private void loadPage(String path) {
        try {
            logger.debug("Chargement: " + path);
            contentPane.setOpacity(Constants.ANIMATION_FADE_FROM);
            
            Parent page = FXMLLoader.load(getClass().getResource(path));
            contentPane.getChildren().clear();
            contentPane.getChildren().add(page);
            
            AnimationUtils.pageTransition(contentPane);
            logger.info("Page chargée: " + path);
        } catch (Exception e) {
            logger.error("Erreur chargement: " + path, e);
        }
    }

    @FXML
    private void openEvenements() {
        loadPage(Constants.FXML_EVENEMENT_BACK);
    }

    @FXML
    private void openParticipations() {
        loadPage(Constants.FXML_PARTICIPATION_BACK);
    }

    @FXML
    private void openFrontoffice() {
        try {
            logger.info("Ouverture du Front Office...");
            
            // Charger le layout Front Office
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/frontoffice/FrontofficeLayout.fxml"));
            
            // Créer une nouvelle fenêtre
            Stage frontStage = new Stage();
            Scene scene = new Scene(root);
            
            frontStage.setTitle("Lammetna - Événements Culturels");
            frontStage.setScene(scene);
            frontStage.setMaximized(true);
            
            // Ajouter l'icône
            try {
                frontStage.getIcons().add(new javafx.scene.image.Image(
                    getClass().getResourceAsStream("/images/logo.png")
                ));
            } catch (Exception e) {
                logger.info("Logo non trouvé pour Front Office");
            }
            
            frontStage.show();
            logger.info("Front Office ouvert avec succès");
            
        } catch (Exception e) {
            logger.error("Erreur lors de l'ouverture du Front Office", e);
            
            javafx.scene.control.Alert alert = new javafx.scene.control.Alert(
                javafx.scene.control.Alert.AlertType.ERROR
            );
            alert.setTitle("Erreur");
            alert.setHeaderText("Impossible d'ouvrir le Front Office");
            alert.setContentText("Erreur: " + e.getMessage());
            alert.showAndWait();
        }
    }
}
