package org.example.controllers.backoffice;

import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.TextAlignment;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;
import org.example.entities.Evenement;
import org.example.services.EvenementService;

import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class EvenementBackController {

    // ================= AJOUT =================
    @FXML private TextField txtTitre;
    @FXML private TextField txtDescription;
    @FXML private DatePicker dpDate;
    @FXML private TextField txtHeure;
    @FXML private TextField txtLieu;
    @FXML private TextField txtPrix;
    @FXML private TextField txtPlaces;
    @FXML private ComboBox<String> cbStatut;

    // ================= MODIFIER =================
    @FXML private TextField txtIdModif;
    @FXML private TextField txtTitreModif;
    @FXML private TextField txtDescriptionModif;
    @FXML private DatePicker dpDateModif;
    @FXML private TextField txtHeureModif;
    @FXML private TextField txtLieuModif;
    @FXML private TextField txtPrixModif;
    @FXML private TextField txtPlacesModif;
    @FXML private ComboBox<String> cbStatutModif;

    // ================= SUPPRIMER =================
    @FXML private TextField txtIdSupp;

    // ================= TABLE =================
    @FXML private TableView<Evenement> tableEvenements;
    @FXML private TableColumn<Evenement, Long> colId;
    @FXML private TableColumn<Evenement, String> colTitre;
    @FXML private TableColumn<Evenement, String> colDescription;
    @FXML private TableColumn<Evenement, LocalDate> colDate;
    @FXML private TableColumn<Evenement, String> colHeure;
    @FXML private TableColumn<Evenement, String> colLieu;
    @FXML private TableColumn<Evenement, Double> colPrix;
    @FXML private TableColumn<Evenement, Integer> colPlaces;
    @FXML private TableColumn<Evenement, String> colStatut;
    @FXML private TableColumn<Evenement, Void> colAction;

    @FXML private TabPane tabPane;
    @FXML private Tab tabAjouter;
    @FXML private Tab tabModifier;
    @FXML private Tab tabAfficher;
    @FXML private Tab tabSupprimer;

    // Recherche et filtres
    @FXML private TextField txtRechercheAfficher;
    @FXML private ComboBox<String> cbFiltreStatut;
    @FXML private DatePicker dpFiltreDate;
    @FXML private Label lblTotalEventsBack;
    @FXML private Label lblActifsBack;
    @FXML private Label lblPlacesBack;

    private final EvenementService es = new EvenementService();
    private final ObservableList<Evenement> evenementList = FXCollections.observableArrayList();
    private FilteredList<Evenement> filteredList;

    @FXML
    public void initialize() {
        System.out.println("🔵 EvenementBackController - initialize() appelé");
        System.out.println("📋 tabPane: " + (tabPane != null ? "OK" : "NULL"));
        System.out.println("📋 tabModifier: " + (tabModifier != null ? "OK" : "NULL"));
        
        // Combobox
        cbStatut.setItems(FXCollections.observableArrayList("Actif", "Annulé", "Complet"));
        cbStatutModif.setItems(FXCollections.observableArrayList("Actif", "Annulé", "Complet"));
        cbFiltreStatut.setItems(FXCollections.observableArrayList("Tous", "Actif", "Annulé", "Complet"));
        cbFiltreStatut.setValue("Tous");

        // TableView
        colId.setCellValueFactory(new PropertyValueFactory<>("idEvent"));
        colTitre.setCellValueFactory(new PropertyValueFactory<>("titre"));
        colDescription.setCellValueFactory(new PropertyValueFactory<>("description"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("dateEvent"));
        colHeure.setCellValueFactory(new PropertyValueFactory<>("heureEvent"));
        colLieu.setCellValueFactory(new PropertyValueFactory<>("lieu"));
        colPrix.setCellValueFactory(new PropertyValueFactory<>("prix"));
        colPlaces.setCellValueFactory(new PropertyValueFactory<>("nbPlaces"));
        colStatut.setCellValueFactory(new PropertyValueFactory<>("statut"));

        loadEvenements();
        addActionButtonsToTable();
        setupSearchAndFilters();
        
        System.out.println("✅ Initialisation terminée");
    }

    private void setupSearchAndFilters() {
        filteredList = new FilteredList<>(evenementList, p -> true);
        tableEvenements.setItems(filteredList);

        // Recherche dynamique
        txtRechercheAfficher.textProperty().addListener((observable, oldValue, newValue) -> {
            applyFilters();
        });

        // Filtre par statut
        cbFiltreStatut.valueProperty().addListener((observable, oldValue, newValue) -> {
            applyFilters();
        });

        // Filtre par date
        dpFiltreDate.valueProperty().addListener((observable, oldValue, newValue) -> {
            applyFilters();
        });
    }

    private void applyFilters() {
        filteredList.setPredicate(evenement -> {
            String searchText = txtRechercheAfficher.getText();
            String statutFilter = cbFiltreStatut.getValue();
            LocalDate dateFilter = dpFiltreDate.getValue();

            // Filtre de recherche
            if (searchText != null && !searchText.isEmpty()) {
                String lowerCaseFilter = searchText.toLowerCase();
                if (!evenement.getTitre().toLowerCase().contains(lowerCaseFilter) &&
                    !evenement.getLieu().toLowerCase().contains(lowerCaseFilter) &&
                    !evenement.getStatut().toLowerCase().contains(lowerCaseFilter)) {
                    return false;
                }
            }

            // Filtre par statut
            if (statutFilter != null && !statutFilter.equals("Tous")) {
                if (!evenement.getStatut().equals(statutFilter)) {
                    return false;
                }
            }

            // Filtre par date
            if (dateFilter != null) {
                if (!evenement.getDateEvent().equals(dateFilter)) {
                    return false;
                }
            }

            return true;
        });

        updateStatistics();
    }

    private void updateStatistics() {
        int total = filteredList.size();
        int actifs = (int) filteredList.stream()
                .filter(e -> "Actif".equals(e.getStatut()))
                .count();
        int places = filteredList.stream()
                .mapToInt(Evenement::getNbPlaces)
                .sum();

        lblTotalEventsBack.setText(String.valueOf(total));
        lblActifsBack.setText(String.valueOf(actifs));
        lblPlacesBack.setText(String.valueOf(places));
    }

    @FXML
    private void reinitialiserFiltres() {
        txtRechercheAfficher.clear();
        cbFiltreStatut.setValue("Tous");
        dpFiltreDate.setValue(null);
    }

    // ================= AJOUT =================
    @FXML
    public void ajouterEvenement(ActionEvent event) {
        System.out.println("🔵 Début ajout événement...");
        
        if (!validateAjoutFields()) {
            System.out.println("❌ Validation échouée");
            return;
        }
        
        Evenement e = new Evenement(
                txtTitre.getText().trim(),
                txtDescription.getText().trim(),
                dpDate.getValue(),
                txtHeure.getText().trim(),
                txtLieu.getText().trim(),
                Double.parseDouble(txtPrix.getText().trim()),
                Integer.parseInt(txtPlaces.getText().trim()),
                cbStatut.getValue()
        );
        
        System.out.println("📝 Événement créé: " + e.getTitre());
        
        boolean success = es.ajouterEvenement(e);
        
        if (success) {
            System.out.println("✅ Événement ajouté en base de données avec ID: " + e.getIdEvent());
            
            // Recharger les données
            loadEvenements();
            System.out.println("📊 Nombre d'événements après rechargement: " + evenementList.size());
            
            // Nettoyer les champs
            clearAjouterFields();
            
            // Afficher le message de succès
            showAlert(Alert.AlertType.INFORMATION, "Événement ajouté avec succès !\nID: " + e.getIdEvent());
            
            // Naviguer vers l'onglet Afficher
            if (tabPane != null && tabAfficher != null) {
                tabPane.getSelectionModel().select(tabAfficher);
                System.out.println("✅ Navigation vers l'onglet Afficher après ajout");
            }
        } else {
            System.err.println("❌ Échec de l'ajout en base de données");
            showAlert(Alert.AlertType.ERROR, "Erreur lors de l'ajout de l'événement !");
        }
    }

    @FXML public void annulerAjout(ActionEvent event) { clearAjouterFields(); }

    private boolean validateAjoutFields() {
        // Vérifier champs vides
        if (txtTitre.getText().trim().isEmpty() || txtDescription.getText().trim().isEmpty() ||
                dpDate.getValue() == null || txtHeure.getText().trim().isEmpty() ||
                txtLieu.getText().trim().isEmpty() || txtPrix.getText().trim().isEmpty() ||
                txtPlaces.getText().trim().isEmpty() || cbStatut.getValue() == null) {
            showAlert(Alert.AlertType.WARNING, "Tous les champs doivent être remplis !");
            return false;
        }
        
        // Validation longueur titre
        if (txtTitre.getText().trim().length() < 3 || txtTitre.getText().trim().length() > 100) {
            showAlert(Alert.AlertType.ERROR, "Le titre doit contenir entre 3 et 100 caractères !");
            return false;
        }
        
        // Validation longueur description
        if (txtDescription.getText().trim().length() < 10 || txtDescription.getText().trim().length() > 500) {
            showAlert(Alert.AlertType.ERROR, "La description doit contenir entre 10 et 500 caractères !");
            return false;
        }
        
        // Validation date future
        if (dpDate.getValue().isBefore(java.time.LocalDate.now())) {
            showAlert(Alert.AlertType.ERROR, "La date doit être dans le futur !");
            return false;
        }
        
        // Validation format heure
        if (!txtHeure.getText().matches("\\d{2}:\\d{2}")) {
            showAlert(Alert.AlertType.ERROR, "Format de l'heure invalide ! Utilisez HH:MM (ex: 14:30)");
            return false;
        }
        
        // Validation heure valide (00:00 à 23:59)
        String[] timeParts = txtHeure.getText().split(":");
        int hours = Integer.parseInt(timeParts[0]);
        int minutes = Integer.parseInt(timeParts[1]);
        if (hours < 0 || hours > 23 || minutes < 0 || minutes > 59) {
            showAlert(Alert.AlertType.ERROR, "Heure invalide ! Heures: 00-23, Minutes: 00-59");
            return false;
        }
        
        // Validation lieu
        if (txtLieu.getText().trim().length() < 3 || txtLieu.getText().trim().length() > 100) {
            showAlert(Alert.AlertType.ERROR, "Le lieu doit contenir entre 3 et 100 caractères !");
            return false;
        }
        
        // Validation prix
        try {
            double prix = Double.parseDouble(txtPrix.getText().trim());
            if (prix < 0 || prix > 10000) {
                showAlert(Alert.AlertType.ERROR, "Le prix doit être entre 0 et 10000 DT !");
                return false;
            }
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Prix invalide ! Entrez un nombre valide.");
            return false;
        }
        
        // Validation places
        try {
            int places = Integer.parseInt(txtPlaces.getText().trim());
            if (places < 1 || places > 10000) {
                showAlert(Alert.AlertType.ERROR, "Le nombre de places doit être entre 1 et 10000 !");
                return false;
            }
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Nombre de places invalide ! Entrez un nombre entier.");
            return false;
        }
        
        return true;
    }

    // ================= MODIFIER =================
    @FXML
    public void modifierEvenement(ActionEvent event) {
        if (txtIdModif.getText().isEmpty()) { showAlert(Alert.AlertType.WARNING, "Veuillez saisir l'ID !"); return; }
        long id = Long.parseLong(txtIdModif.getText());
        Evenement e = es.trouverEvenementParId(id);
        if (e == null) { showAlert(Alert.AlertType.WARNING, "Événement introuvable !"); return; }
        if (!validateModifierFields()) return;

        e.setTitre(txtTitreModif.getText());
        e.setDescription(txtDescriptionModif.getText());
        e.setDateEvent(dpDateModif.getValue());
        e.setHeureEvent(txtHeureModif.getText());
        e.setLieu(txtLieuModif.getText());
        e.setPrix(Double.parseDouble(txtPrixModif.getText()));
        e.setNbPlaces(Integer.parseInt(txtPlacesModif.getText()));
        e.setStatut(cbStatutModif.getValue());
        es.modifierEvenement(e);

        loadEvenements();
        clearModifierFields();
        showAlert(Alert.AlertType.INFORMATION, "Événement modifié avec succès !");
        
        // Retourner à l'onglet Afficher
        if (tabPane != null && tabAfficher != null) {
            tabPane.getSelectionModel().select(tabAfficher);
            System.out.println("✅ Retour à l'onglet Afficher");
        }
    }

    @FXML public void annulerModification(ActionEvent event) { clearModifierFields(); }

    private boolean validateModifierFields() {
        // Vérifier champs vides
        if (txtTitreModif.getText().trim().isEmpty() || txtDescriptionModif.getText().trim().isEmpty() ||
                dpDateModif.getValue() == null || txtHeureModif.getText().trim().isEmpty() ||
                txtLieuModif.getText().trim().isEmpty() || txtPrixModif.getText().trim().isEmpty() ||
                txtPlacesModif.getText().trim().isEmpty() || cbStatutModif.getValue() == null) {
            showAlert(Alert.AlertType.WARNING, "Tous les champs doivent être remplis !");
            return false;
        }
        
        // Validation longueur titre
        if (txtTitreModif.getText().trim().length() < 3 || txtTitreModif.getText().trim().length() > 100) {
            showAlert(Alert.AlertType.ERROR, "Le titre doit contenir entre 3 et 100 caractères !");
            return false;
        }
        
        // Validation longueur description
        if (txtDescriptionModif.getText().trim().length() < 10 || txtDescriptionModif.getText().trim().length() > 500) {
            showAlert(Alert.AlertType.ERROR, "La description doit contenir entre 10 et 500 caractères !");
            return false;
        }
        
        // Validation date future
        if (dpDateModif.getValue().isBefore(java.time.LocalDate.now())) {
            showAlert(Alert.AlertType.ERROR, "La date doit être dans le futur !");
            return false;
        }
        
        // Validation format heure
        if (!txtHeureModif.getText().matches("\\d{2}:\\d{2}")) {
            showAlert(Alert.AlertType.ERROR, "Format de l'heure invalide ! Utilisez HH:MM (ex: 14:30)");
            return false;
        }
        
        // Validation heure valide
        String[] timeParts = txtHeureModif.getText().split(":");
        int hours = Integer.parseInt(timeParts[0]);
        int minutes = Integer.parseInt(timeParts[1]);
        if (hours < 0 || hours > 23 || minutes < 0 || minutes > 59) {
            showAlert(Alert.AlertType.ERROR, "Heure invalide ! Heures: 00-23, Minutes: 00-59");
            return false;
        }
        
        // Validation lieu
        if (txtLieuModif.getText().trim().length() < 3 || txtLieuModif.getText().trim().length() > 100) {
            showAlert(Alert.AlertType.ERROR, "Le lieu doit contenir entre 3 et 100 caractères !");
            return false;
        }
        
        // Validation prix
        try {
            double prix = Double.parseDouble(txtPrixModif.getText().trim());
            if (prix < 0 || prix > 10000) {
                showAlert(Alert.AlertType.ERROR, "Le prix doit être entre 0 et 10000 DT !");
                return false;
            }
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Prix invalide ! Entrez un nombre valide.");
            return false;
        }
        
        // Validation places
        try {
            int places = Integer.parseInt(txtPlacesModif.getText().trim());
            if (places < 1 || places > 10000) {
                showAlert(Alert.AlertType.ERROR, "Le nombre de places doit être entre 1 et 10000 !");
                return false;
            }
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Nombre de places invalide ! Entrez un nombre entier.");
            return false;
        }
        
        return true;
    }

    // ================= SUPPRIMER =================
    @FXML
    public void supprimerEvenement(ActionEvent event) {
        if (txtIdSupp.getText().isEmpty()) { showAlert(Alert.AlertType.WARNING,"Veuillez saisir l'ID à supprimer !"); return; }
        long id = Long.parseLong(txtIdSupp.getText());
        Evenement e = es.trouverEvenementParId(id);
        if (e == null) { showAlert(Alert.AlertType.WARNING,"Événement introuvable !"); return; }
        es.supprimerEvenement(id);
        loadEvenements();
        showAlert(Alert.AlertType.INFORMATION,"Événement supprimé avec succès !");
        txtIdSupp.clear();
        
        // Naviguer vers l'onglet Afficher
        if (tabPane != null && tabAfficher != null) {
            tabPane.getSelectionModel().select(tabAfficher);
            System.out.println("✅ Navigation vers l'onglet Afficher après suppression");
        }
    }

    // ================= AFFICHER =================
    @FXML 
    public void afficherEvenements(ActionEvent event) { 
        System.out.println("🔵 Bouton Afficher cliqué");
        loadEvenements(); 
    }

    private void loadEvenements() {
        System.out.println("🔵 Chargement des événements depuis la base de données...");
        
        try {
            List<Evenement> events = es.afficherEvenements();
            System.out.println("📊 Nombre d'événements récupérés: " + events.size());
            
            if (events.isEmpty()) {
                System.out.println("⚠️ Aucun événement trouvé dans la base de données");
            } else {
                System.out.println("✅ Événements récupérés:");
                for (Evenement e : events) {
                    System.out.println("   - " + e.getIdEvent() + ": " + e.getTitre());
                }
            }
            
            evenementList.setAll(events);
            System.out.println("📋 Liste observable mise à jour: " + evenementList.size() + " éléments");
            
            if (filteredList != null) {
                updateStatistics();
                System.out.println("📈 Statistiques mises à jour");
            }
            
            System.out.println("✅ Chargement terminé avec succès");
        } catch (Exception e) {
            System.err.println("❌ Erreur lors du chargement des événements: " + e.getMessage());
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur lors du chargement des événements: " + e.getMessage());
        }
    }

    // ================= CLEAR =================
    private void clearAjouterFields() {
        txtTitre.clear(); txtDescription.clear(); dpDate.setValue(null); txtHeure.clear();
        txtLieu.clear(); txtPrix.clear(); txtPlaces.clear(); cbStatut.getSelectionModel().clearSelection();
    }
    private void clearModifierFields() {
        txtIdModif.clear(); txtTitreModif.clear(); txtDescriptionModif.clear(); dpDateModif.setValue(null);
        txtHeureModif.clear(); txtLieuModif.clear(); txtPrixModif.clear(); txtPlacesModif.clear();
        cbStatutModif.getSelectionModel().clearSelection();
    }

    // ================= ALERT =================
    private void showAlert(Alert.AlertType type, String message) {
        Alert alert = new Alert(type, message);
        alert.showAndWait();
    }

    // ================= COLONNE ACTION =================
    private void addActionButtonsToTable() {
        colAction.setCellFactory(param -> new TableCell<>() {
            private final Button btnEdit = new Button("✏️ Modifier");
            private final Button btnDelete = new Button("🗑️ Supprimer");

            {
                // Style moderne pour le bouton Modifier
                btnEdit.setStyle(
                    "-fx-background-color: linear-gradient(to right, #3b82f6, #60a5fa); " +
                    "-fx-text-fill: white; " +
                    "-fx-font-weight: 700; " +
                    "-fx-font-size: 12px; " +
                    "-fx-padding: 8 16; " +
                    "-fx-background-radius: 8; " +
                    "-fx-cursor: hand; " +
                    "-fx-effect: dropshadow(gaussian, rgba(59, 130, 246, 0.3), 8, 0, 0, 2);"
                );
                
                // Style moderne pour le bouton Supprimer
                btnDelete.setStyle(
                    "-fx-background-color: linear-gradient(to right, #ef4444, #f87171); " +
                    "-fx-text-fill: white; " +
                    "-fx-font-weight: 700; " +
                    "-fx-font-size: 12px; " +
                    "-fx-padding: 8 16; " +
                    "-fx-background-radius: 8; " +
                    "-fx-cursor: hand; " +
                    "-fx-effect: dropshadow(gaussian, rgba(239, 68, 68, 0.3), 8, 0, 0, 2);"
                );

                // Effet hover pour Modifier
                btnEdit.setOnMouseEntered(e -> btnEdit.setStyle(
                    "-fx-background-color: linear-gradient(to right, #2563eb, #3b82f6); " +
                    "-fx-text-fill: white; " +
                    "-fx-font-weight: 700; " +
                    "-fx-font-size: 12px; " +
                    "-fx-padding: 8 16; " +
                    "-fx-background-radius: 8; " +
                    "-fx-cursor: hand; " +
                    "-fx-effect: dropshadow(gaussian, rgba(59, 130, 246, 0.5), 12, 0, 0, 3); " +
                    "-fx-scale-x: 1.05; " +
                    "-fx-scale-y: 1.05;"
                ));
                
                btnEdit.setOnMouseExited(e -> btnEdit.setStyle(
                    "-fx-background-color: linear-gradient(to right, #3b82f6, #60a5fa); " +
                    "-fx-text-fill: white; " +
                    "-fx-font-weight: 700; " +
                    "-fx-font-size: 12px; " +
                    "-fx-padding: 8 16; " +
                    "-fx-background-radius: 8; " +
                    "-fx-cursor: hand; " +
                    "-fx-effect: dropshadow(gaussian, rgba(59, 130, 246, 0.3), 8, 0, 0, 2);"
                ));

                // Effet hover pour Supprimer
                btnDelete.setOnMouseEntered(e -> btnDelete.setStyle(
                    "-fx-background-color: linear-gradient(to right, #dc2626, #ef4444); " +
                    "-fx-text-fill: white; " +
                    "-fx-font-weight: 700; " +
                    "-fx-font-size: 12px; " +
                    "-fx-padding: 8 16; " +
                    "-fx-background-radius: 8; " +
                    "-fx-cursor: hand; " +
                    "-fx-effect: dropshadow(gaussian, rgba(239, 68, 68, 0.5), 12, 0, 0, 3); " +
                    "-fx-scale-x: 1.05; " +
                    "-fx-scale-y: 1.05;"
                ));
                
                btnDelete.setOnMouseExited(e -> btnDelete.setStyle(
                    "-fx-background-color: linear-gradient(to right, #ef4444, #f87171); " +
                    "-fx-text-fill: white; " +
                    "-fx-font-weight: 700; " +
                    "-fx-font-size: 12px; " +
                    "-fx-padding: 8 16; " +
                    "-fx-background-radius: 8; " +
                    "-fx-cursor: hand; " +
                    "-fx-effect: dropshadow(gaussian, rgba(239, 68, 68, 0.3), 8, 0, 0, 2);"
                ));

                btnEdit.setOnAction(event -> {
                    try {
                        Evenement e = getTableView().getItems().get(getIndex());
                        System.out.println("🔵 Bouton Modifier cliqué pour: " + e.getTitre());
                        
                        // Pré-remplir le formulaire
                        prefillModificationForm(e);
                        System.out.println("✅ Formulaire pré-rempli");
                        
                        // Aller à l'onglet Modifier avec un délai pour s'assurer que tout est chargé
                        javafx.application.Platform.runLater(() -> {
                            if (tabPane != null && tabModifier != null) {
                                tabPane.getSelectionModel().select(tabModifier);
                                System.out.println("✅ Navigation vers l'onglet Modifier réussie");
                            } else {
                                System.err.println("❌ Erreur: tabPane=" + tabPane + ", tabModifier=" + tabModifier);
                            }
                        });
                    } catch (Exception ex) {
                        System.err.println("❌ Erreur lors du clic sur Modifier: " + ex.getMessage());
                        ex.printStackTrace();
                    }
                });

                btnDelete.setOnAction(event -> {
                    Evenement e = getTableView().getItems().get(getIndex());
                    Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
                    confirm.setTitle("Confirmation");
                    confirm.setHeaderText("🗑️ Supprimer l'événement");
                    confirm.setContentText("Voulez-vous vraiment supprimer \"" + e.getTitre() + "\" ?\n\nCette action est irréversible.");
                    
                    confirm.showAndWait().ifPresent(response -> {
                        if (response == ButtonType.OK) {
                            es.supprimerEvenement(e.getIdEvent());
                            loadEvenements();
                            showAlert(Alert.AlertType.INFORMATION,"✅ Événement supprimé avec succès !");
                        }
                    });
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : new HBox(10, btnEdit, btnDelete));
            }
        });
    }

    public void prefillModificationForm(Evenement e) {
        txtIdModif.setText(String.valueOf(e.getIdEvent()));
        txtTitreModif.setText(e.getTitre());
        txtDescriptionModif.setText(e.getDescription());
        dpDateModif.setValue(e.getDateEvent());
        txtHeureModif.setText(e.getHeureEvent());
        txtLieuModif.setText(e.getLieu());
        txtPrixModif.setText(String.valueOf(e.getPrix()));
        txtPlacesModif.setText(String.valueOf(e.getNbPlaces()));
        cbStatutModif.setValue(e.getStatut());
    }

    // ================= EXPORT PDF =================
    @FXML
    private void exporterPDF() {
        try {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Enregistrer le PDF");
            fileChooser.setInitialFileName("evenements_" + LocalDate.now() + ".pdf");
            fileChooser.getExtensionFilters().add(
                    new FileChooser.ExtensionFilter("PDF Files", "*.pdf")
            );

            File file = fileChooser.showSaveDialog(tableEvenements.getScene().getWindow());
            if (file != null) {
                PdfWriter writer = new PdfWriter(file.getAbsolutePath());
                PdfDocument pdfDoc = new PdfDocument(writer);
                Document document = new Document(pdfDoc);

                // Titre
                Paragraph title = new Paragraph("Liste des Événements")
                        .setFontSize(20)
                        .setBold()
                        .setTextAlignment(TextAlignment.CENTER);
                document.add(title);

                document.add(new Paragraph("Date d'export: " + LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")))
                        .setTextAlignment(TextAlignment.CENTER));
                document.add(new Paragraph("\n"));

                // Table
                Table table = new Table(new float[]{1, 3, 4, 2, 2, 3, 2, 2, 2});
                table.setWidth(com.itextpdf.layout.properties.UnitValue.createPercentValue(100));

                // En-têtes
                table.addHeaderCell("ID");
                table.addHeaderCell("Titre");
                table.addHeaderCell("Description");
                table.addHeaderCell("Date");
                table.addHeaderCell("Heure");
                table.addHeaderCell("Lieu");
                table.addHeaderCell("Prix");
                table.addHeaderCell("Places");
                table.addHeaderCell("Statut");

                // Données
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                for (Evenement e : filteredList) {
                    table.addCell(String.valueOf(e.getIdEvent()));
                    table.addCell(e.getTitre());
                    table.addCell(e.getDescription());
                    table.addCell(e.getDateEvent().format(formatter));
                    table.addCell(e.getHeureEvent());
                    table.addCell(e.getLieu());
                    table.addCell(e.getPrix() + " DT");
                    table.addCell(String.valueOf(e.getNbPlaces()));
                    table.addCell(e.getStatut());
                }

                document.add(table);

                // Statistiques
                document.add(new Paragraph("\n\nStatistiques:"));
                document.add(new Paragraph("Total d'événements: " + filteredList.size()));
                document.add(new Paragraph("Événements actifs: " + 
                        filteredList.stream().filter(e -> "Actif".equals(e.getStatut())).count()));
                document.add(new Paragraph("Places totales: " + 
                        filteredList.stream().mapToInt(Evenement::getNbPlaces).sum()));

                document.close();

                showAlert(Alert.AlertType.INFORMATION, "PDF exporté avec succès !\n" + file.getAbsolutePath());
            }
        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur lors de l'export PDF: " + e.getMessage());
        }
    }
}
