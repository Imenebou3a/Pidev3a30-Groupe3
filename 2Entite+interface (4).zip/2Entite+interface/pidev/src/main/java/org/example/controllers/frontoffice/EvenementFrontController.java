package org.example.controllers.frontoffice;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import org.example.entities.Evenement;
import org.example.services.EvenementService;

import java.time.format.DateTimeFormatter;
import java.util.List;

public class EvenementFrontController {

    @FXML private TextField txtRecherche;
    @FXML private ComboBox<String> cbFiltreStatut;
    @FXML private Label lblTotalEvents;
    @FXML private Label lblAvailableEvents;
    @FXML private Label lblTotalPlaces;
    @FXML private VBox eventsContainer;

    private final EvenementService service = new EvenementService();
    private final ObservableList<Evenement> list = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        System.out.println("🔵 EvenementFrontController - initialize() appelé");
        
        // Initialiser le ComboBox
        if (cbFiltreStatut != null) {
            cbFiltreStatut.setItems(FXCollections.observableArrayList("Tous", "Actif", "Complet", "Annulé"));
            cbFiltreStatut.setValue("Tous");
        }
        
        loadData();
        setupDynamicSearch();
    }

    private void setupDynamicSearch() {
        // Recherche dynamique en temps réel
        txtRecherche.textProperty().addListener((observable, oldValue, newValue) -> {
            applyFilters();
        });
        
        // Filtre par statut dynamique
        if (cbFiltreStatut != null) {
            cbFiltreStatut.valueProperty().addListener((observable, oldValue, newValue) -> {
                applyFilters();
            });
        }
    }

    private void loadData() {
        System.out.println("🔵 Chargement des événements...");
        List<Evenement> events = service.afficherEvenements();
        System.out.println("📊 Nombre d'événements récupérés: " + events.size());

        list.setAll(events);
        applyFilters();
    }

    private void applyFilters() {
        String searchText = txtRecherche.getText();
        String statutFilter = (cbFiltreStatut != null) ? cbFiltreStatut.getValue() : "Tous";
        
        List<Evenement> filteredEvents = list.stream()
                .filter(e -> {
                    // Filtre de recherche
                    if (searchText != null && !searchText.isEmpty()) {
                        String lowerCaseFilter = searchText.toLowerCase();
                        if (!e.getTitre().toLowerCase().contains(lowerCaseFilter) &&
                            !e.getDescription().toLowerCase().contains(lowerCaseFilter) &&
                            !e.getLieu().toLowerCase().contains(lowerCaseFilter)) {
                            return false;
                        }
                    }
                    
                    // Filtre par statut
                    if (statutFilter != null && !statutFilter.equals("Tous")) {
                        if (!e.getStatut().equalsIgnoreCase(statutFilter)) {
                            return false;
                        }
                    }
                    
                    return true;
                })
                .toList();
        
        displayEventsAsCards(filteredEvents);
        updateStats(filteredEvents);
    }

    private void displayEventsAsCards() {
        displayEventsAsCards(list);
    }

    private void displayEventsAsCards(List<Evenement> events) {
        eventsContainer.getChildren().clear();

        if (events.isEmpty()) {
            VBox emptyMessage = new VBox(20);
            emptyMessage.setAlignment(Pos.CENTER);
            emptyMessage.setStyle("-fx-background-color: white; " +
                    "-fx-background-radius: 16; " +
                    "-fx-padding: 60; " +
                    "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 20, 0, 0, 5); " +
                    "-fx-border-color: #E0E0E0; " +
                    "-fx-border-width: 1; " +
                    "-fx-border-radius: 16;");
            
            Label icon = new Label("🔍");
            icon.setStyle("-fx-font-size: 60px;");
            
            Label message = new Label("Aucun événement trouvé");
            message.setStyle("-fx-font-size: 22px; -fx-font-weight: 900; -fx-text-fill: #1F2937;");
            
            Label hint = new Label("Essayez de modifier vos critères de recherche");
            hint.setStyle("-fx-font-size: 14px; -fx-font-weight: 600; -fx-text-fill: #6B7280;");
            
            emptyMessage.getChildren().addAll(icon, message, hint);
            eventsContainer.getChildren().add(emptyMessage);
            return;
        }

        for (Evenement event : events) {
            VBox card = createEventCard(event);
            eventsContainer.getChildren().add(card);
        }
    }

    private VBox createEventCard(Evenement event) {
        VBox card = new VBox(15);
        card.setStyle("-fx-background-color: white; " +
                "-fx-background-radius: 14; " +
                "-fx-padding: 20 25; " +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 15, 0, 0, 3); " +
                "-fx-border-color: " + getBorderColor(event.getStatut()) + "; " +
                "-fx-border-width: 2; " +
                "-fx-border-radius: 14;");
        card.setMaxWidth(1300);

        // Header compact avec titre et badge
        HBox header = new HBox(12);
        header.setAlignment(Pos.CENTER_LEFT);

        Label titre = new Label(event.getTitre());
        titre.setStyle("-fx-font-size: 17px; -fx-font-weight: 900; -fx-text-fill: #1F2937;");
        HBox.setHgrow(titre, Priority.ALWAYS);

        Label badge = createStatusBadge(event.getStatut());
        header.getChildren().addAll(titre, badge);

        // Info rapide (date et lieu)
        HBox quickInfo = new HBox(20);
        quickInfo.setAlignment(Pos.CENTER_LEFT);
        
        Label dateInfo = new Label("📅 " + event.getDateEvent().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        dateInfo.setStyle("-fx-font-size: 12px; -fx-font-weight: 700; -fx-text-fill: #6B7280;");
        
        Label lieuInfo = new Label("📍 " + event.getLieu());
        lieuInfo.setStyle("-fx-font-size: 12px; -fx-font-weight: 700; -fx-text-fill: #6B7280;");
        
        Label prixInfo = new Label("💰 " + event.getPrix() + " DT");
        prixInfo.setStyle("-fx-font-size: 12px; -fx-font-weight: 700; -fx-text-fill: #D9541E;");
        
        quickInfo.getChildren().addAll(dateInfo, lieuInfo, prixInfo);

        // Boutons d'action
        HBox actions = new HBox(12);
        actions.setAlignment(Pos.CENTER_LEFT);
        
        Button btnDetails = new Button("👁 Voir détails");
        btnDetails.setStyle("-fx-background-color: #F3F4F6; " +
                "-fx-text-fill: #1F2937; " +
                "-fx-font-size: 12px; " +
                "-fx-font-weight: 800; " +
                "-fx-padding: 10 20; " +
                "-fx-background-radius: 8; " +
                "-fx-cursor: hand; " +
                "-fx-border-color: #D1D5DB; " +
                "-fx-border-width: 2; " +
                "-fx-border-radius: 8;");
        
        // Effet hover
        btnDetails.setOnMouseEntered(e -> btnDetails.setStyle(
                "-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #117A7A, #1A9999); " +
                "-fx-text-fill: white; " +
                "-fx-font-size: 12px; " +
                "-fx-font-weight: 800; " +
                "-fx-padding: 10 20; " +
                "-fx-background-radius: 8; " +
                "-fx-cursor: hand; " +
                "-fx-border-color: #0D5F5F; " +
                "-fx-border-width: 2; " +
                "-fx-border-radius: 8; " +
                "-fx-effect: dropshadow(gaussian, rgba(17,122,122,0.4), 12, 0, 0, 3);"));
        
        btnDetails.setOnMouseExited(e -> btnDetails.setStyle(
                "-fx-background-color: #F3F4F6; " +
                "-fx-text-fill: #1F2937; " +
                "-fx-font-size: 12px; " +
                "-fx-font-weight: 800; " +
                "-fx-padding: 10 20; " +
                "-fx-background-radius: 8; " +
                "-fx-cursor: hand; " +
                "-fx-border-color: #D1D5DB; " +
                "-fx-border-width: 2; " +
                "-fx-border-radius: 8;"));
        
        btnDetails.setOnAction(e -> showEventDetails(event));
        
        if (event.getStatut().equalsIgnoreCase("Actif")) {
            Button btnInscrire = new Button("✅ S'inscrire");
            btnInscrire.setStyle("-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #D9541E, #F07040); " +
                    "-fx-text-fill: white; " +
                    "-fx-font-size: 12px; " +
                    "-fx-font-weight: 900; " +
                    "-fx-padding: 10 25; " +
                    "-fx-background-radius: 8; " +
                    "-fx-cursor: hand; " +
                    "-fx-effect: dropshadow(gaussian, rgba(217,84,30,0.3), 10, 0, 0, 2);");
            
            // Effet hover
            btnInscrire.setOnMouseEntered(e -> btnInscrire.setStyle(
                    "-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #B84015, #D9541E); " +
                    "-fx-text-fill: white; " +
                    "-fx-font-size: 12px; " +
                    "-fx-font-weight: 900; " +
                    "-fx-padding: 10 25; " +
                    "-fx-background-radius: 8; " +
                    "-fx-cursor: hand; " +
                    "-fx-effect: dropshadow(gaussian, rgba(217,84,30,0.6), 15, 0, 0, 5); " +
                    "-fx-scale-x: 1.05; " +
                    "-fx-scale-y: 1.05;"));
            
            btnInscrire.setOnMouseExited(e -> btnInscrire.setStyle(
                    "-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #D9541E, #F07040); " +
                    "-fx-text-fill: white; " +
                    "-fx-font-size: 12px; " +
                    "-fx-font-weight: 900; " +
                    "-fx-padding: 10 25; " +
                    "-fx-background-radius: 8; " +
                    "-fx-cursor: hand; " +
                    "-fx-effect: dropshadow(gaussian, rgba(217,84,30,0.3), 10, 0, 0, 2);"));
            
            btnInscrire.setOnAction(e -> ouvrirFormulaireInscription(event));
            actions.getChildren().addAll(btnDetails, btnInscrire);
        } else {
            actions.getChildren().add(btnDetails);
        }

        card.getChildren().addAll(header, quickInfo, actions);
        return card;
    }

    private void showEventDetails(Evenement event) {
        try {
            // Créer une nouvelle fenêtre
            javafx.stage.Stage detailsStage = new javafx.stage.Stage();
            detailsStage.setTitle("Détails de l'événement");
            detailsStage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
            
            // Container principal
            VBox mainContainer = new VBox(0);
            mainContainer.setStyle("-fx-background-color: white;");
            
            // Header avec gradient
            VBox header = new VBox(15);
            header.setAlignment(Pos.CENTER);
            header.setStyle("-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #117A7A, #1A9999); " +
                    "-fx-padding: 30 40;");
            
            // Logo Lammetna
            ImageView logoView = new ImageView();
            try {
                Image logoImage = new Image(getClass().getResourceAsStream("/images/logo.png"));
                logoView.setImage(logoImage);
                logoView.setFitHeight(60);
                logoView.setFitWidth(60);
                logoView.setPreserveRatio(true);
            } catch (Exception e) {
                System.err.println("❌ Erreur chargement logo: " + e.getMessage());
            }
            
            Label titre = new Label(event.getTitre());
            titre.setStyle("-fx-font-size: 26px; -fx-font-weight: 900; -fx-text-fill: white; " +
                    "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 8, 0, 0, 2);");
            titre.setWrapText(true);
            titre.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
            titre.setMaxWidth(500);
            
            Label badge = createStatusBadge(event.getStatut());
            
            header.getChildren().addAll(logoView, titre, badge);
            
            // Corps avec ScrollPane
            ScrollPane scrollPane = new ScrollPane();
            scrollPane.setFitToWidth(true);
            scrollPane.setStyle("-fx-background: white; -fx-background-color: white;");
            
            VBox content = new VBox(25);
            content.setStyle("-fx-padding: 30 40; -fx-background-color: white;");
            
            // Description
            VBox descSection = createSection("📋 Description", event.getDescription());
            
            // Informations
            GridPane infoGrid = new GridPane();
            infoGrid.setHgap(40);
            infoGrid.setVgap(18);
            infoGrid.setStyle("-fx-background-color: #F9FAFB; -fx-background-radius: 12; -fx-padding: 25;");
            
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            
            addDetailRow(infoGrid, 0, "📅", "Date", event.getDateEvent().format(formatter));
            addDetailRow(infoGrid, 1, "🕐", "Heure", event.getHeureEvent());
            addDetailRow(infoGrid, 2, "📍", "Lieu", event.getLieu());
            addDetailRow(infoGrid, 3, "💰", "Prix", event.getPrix() + " DT");
            addDetailRow(infoGrid, 4, "🎫", "Places disponibles", String.valueOf(event.getNbPlaces()));
            
            content.getChildren().addAll(descSection, infoGrid);
            scrollPane.setContent(content);
            
            // Footer avec boutons
            HBox footer = new HBox(15);
            footer.setAlignment(Pos.CENTER);
            footer.setStyle("-fx-padding: 20 40; -fx-background-color: #F9FAFB; " +
                    "-fx-border-color: #E5E7EB; -fx-border-width: 1 0 0 0;");
            
            Button btnFermer = new Button("Fermer");
            btnFermer.setStyle("-fx-background-color: #F3F4F6; -fx-text-fill: #1F2937; " +
                    "-fx-font-size: 13px; -fx-font-weight: 800; -fx-padding: 12 30; " +
                    "-fx-background-radius: 10; -fx-cursor: hand; " +
                    "-fx-border-color: #D1D5DB; -fx-border-width: 2; -fx-border-radius: 10;");
            btnFermer.setOnAction(e -> detailsStage.close());
            
            if (event.getStatut().equalsIgnoreCase("Actif")) {
                Button btnInscrire = new Button("✅ S'inscrire maintenant");
                btnInscrire.setStyle("-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #D9541E, #F07040); " +
                        "-fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: 900; " +
                        "-fx-padding: 14 35; -fx-background-radius: 10; -fx-cursor: hand; " +
                        "-fx-effect: dropshadow(gaussian, rgba(217,84,30,0.4), 15, 0, 0, 4);");
                btnInscrire.setOnAction(e -> {
                    detailsStage.close();
                    ouvrirFormulaireInscription(event);
                });
                footer.getChildren().addAll(btnFermer, btnInscrire);
            } else {
                footer.getChildren().add(btnFermer);
            }
            
            mainContainer.getChildren().addAll(header, scrollPane, footer);
            
            javafx.scene.Scene scene = new javafx.scene.Scene(mainContainer, 650, 600);
            detailsStage.setScene(scene);
            detailsStage.show();
            
        } catch (Exception ex) {
            ex.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setContentText("Impossible d'afficher les détails");
            alert.show();
        }
    }
    
    private VBox createSection(String title, String content) {
        VBox section = new VBox(12);
        
        Label titleLabel = new Label(title);
        titleLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: 900; -fx-text-fill: #117A7A;");
        
        Label contentLabel = new Label(content);
        contentLabel.setWrapText(true);
        contentLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: 600; -fx-text-fill: #4B5563; " +
                "-fx-line-spacing: 3;");
        
        section.getChildren().addAll(titleLabel, contentLabel);
        return section;
    }
    
    private void addDetailRow(GridPane grid, int row, String emoji, String label, String value) {
        HBox labelBox = new HBox(8);
        labelBox.setAlignment(Pos.CENTER_LEFT);
        
        Label emojiLabel = new Label(emoji);
        emojiLabel.setStyle("-fx-font-size: 18px;");
        
        Label textLabel = new Label(label);
        textLabel.setStyle("-fx-font-size: 13px; -fx-font-weight: 800; -fx-text-fill: #6B7280;");
        
        labelBox.getChildren().addAll(emojiLabel, textLabel);
        
        Label valueLabel = new Label(value);
        valueLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: 700; -fx-text-fill: #1F2937;");
        
        grid.add(labelBox, 0, row);
        grid.add(valueLabel, 1, row);
    }

    private String getBorderColor(String statut) {
        return statut.equalsIgnoreCase("Actif") ? "#117A7A" :
               statut.equalsIgnoreCase("Complet") ? "#EF4444" : "#F59E0B";
    }

    private Label createStatusBadge(String statut) {
        String icon = statut.equalsIgnoreCase("Actif") ? "✅" :
                     statut.equalsIgnoreCase("Complet") ? "❌" : "⚠️";
        String bgColor = statut.equalsIgnoreCase("Actif") ? "linear-gradient(from 0% 0% to 100% 100%, #10B981, #059669)" :
                        statut.equalsIgnoreCase("Complet") ? "linear-gradient(from 0% 0% to 100% 100%, #EF4444, #DC2626)" :
                        "linear-gradient(from 0% 0% to 100% 100%, #F59E0B, #D97706)";
        
        Label badge = new Label(icon + " " + statut.toUpperCase());
        badge.setStyle("-fx-background-color: " + bgColor + "; " +
                "-fx-text-fill: white; " +
                "-fx-padding: 8 20; " +
                "-fx-background-radius: 15; " +
                "-fx-font-size: 12px; " +
                "-fx-font-weight: 900; " +
                "-fx-letter-spacing: 0.5px; " +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 8, 0, 0, 2);");
        return badge;
    }
    private void ouvrirFormulaireInscription(Evenement evenement) {
        try {
            javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(
                    getClass().getResource("/fxml/frontoffice/ParticipationFrontSimple.fxml")
            );
            javafx.scene.Parent root = loader.load();

            ParticipationFrontController controller = loader.getController();
            controller.setIdEvenement(evenement.getIdEvent());

            javafx.stage.Stage stage = new javafx.stage.Stage();
            stage.setTitle("Inscription - " + evenement.getTitre());
            stage.setScene(new javafx.scene.Scene(root, 750, 650));
            stage.show();

        } catch (Exception ex) {
            ex.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText("Impossible d'ouvrir le formulaire");
            alert.setContentText("Erreur: " + ex.getMessage());
            alert.showAndWait();
        }
    }

    private void updateStats(List<Evenement> events) {
        int total = events.size();
        int active = (int) events.stream()
                .filter(e -> "Actif".equalsIgnoreCase(e.getStatut()))
                .count();
        int places = events.stream()
                .mapToInt(Evenement::getNbPlaces)
                .sum();

        lblTotalEvents.setText(String.valueOf(total));
        lblAvailableEvents.setText(String.valueOf(active));
        lblTotalPlaces.setText(String.valueOf(places));
    }

    @FXML
    private void searchEvent() {
        applyFilters();
    }

    @FXML
    private void refreshTable() {
        txtRecherche.clear();
        if (cbFiltreStatut != null) {
            cbFiltreStatut.setValue("Tous");
        }
        loadData();
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Actualisation");
        alert.setHeaderText(null);
        alert.setContentText("Liste actualisée !");
        alert.show();
    }
}
