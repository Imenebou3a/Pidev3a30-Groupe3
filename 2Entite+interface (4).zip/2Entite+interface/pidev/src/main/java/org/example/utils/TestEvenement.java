package org.example.utils;

import org.example.entities.Evenement;
import org.example.services.EvenementService;
import java.time.LocalDate;
import java.util.List;

public class TestEvenement {
    private static final EvenementService service = new EvenementService();
    
    public static void main(String[] args) {
        System.out.println("Test Evenements");
        testAfficher();
        testAjouter();
    }
    
    private static void testAfficher() {
        List<Evenement> evenements = service.afficherEvenements();
        System.out.println("Nombre: " + evenements.size());
        for (Evenement e : evenements) {
            System.out.println(e.getTitre());
        }
    }
    
    private static void testAjouter() {
        Evenement e = new Evenement();
        e.setTitre("Test");
        e.setDescription("Test");
        e.setDateEvent(LocalDate.now().plusDays(30));
        e.setHeureEvent("20:00");
        e.setLieu("Tunis");
        e.setPrix(25.0);
        e.setNbPlaces(150);
        e.setStatut("Actif");
        service.ajouterEvenement(e);
        System.out.println("Ajoute: " + e.getIdEvent());
    }
}
