package org.example.controllers.main;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.layout.StackPane;
import org.example.utils.AnimationUtils;
import org.example.utils.Constants;
import org.example.utils.Logger;

/**
 * Contrôleur principal de l'application
 * Gère la navigation entre les différentes pages
 */
public class MainLayoutController {

    private static final Logger logger = Logger.getLogger(MainLayoutController.class);

    @FXML
    private StackPane contentPane;

    @FXML
    public void initialize() {
        logger.info("MainLayoutController - Initialisation");
        // Page par défaut
        loadPage(Constants.FXML_EVENEMENT_BACK);
    }

    /**
     * Charge une page FXML dans le contentPane
     * @param path Chemin vers le fichier FXML
     */
    private void loadPage(String path) {
        try {
            logger.debug("Chargement de la page: " + path);
            
            // Afficher un indicateur de chargement
            contentPane.setOpacity(Constants.ANIMATION_FADE_FROM);
            
            Parent page = FXMLLoader.load(getClass().getResource(path));
            contentPane.getChildren().clear();
            contentPane.getChildren().add(page);
            
            // Animation de transition
            AnimationUtils.pageTransition(contentPane);
            
            logger.info("Page chargée avec succès: " + path);
        } catch (Exception e) {
            logger.error("Erreur lors du chargement de la page: " + path, e);
            
            // Afficher une erreur à l'utilisateur
            javafx.scene.control.Alert alert = new javafx.scene.control.Alert(
                javafx.scene.control.Alert.AlertType.ERROR
            );
            alert.setTitle("Erreur");
            alert.setHeaderText("Impossible de charger la page");
            alert.setContentText("Erreur: " + e.getMessage());
            alert.showAndWait();
        }
    }

    @FXML
    private void openEvenementBack() {
        loadPage(Constants.FXML_EVENEMENT_BACK);
    }

    @FXML
    private void openParticipationBack() {
        loadPage(Constants.FXML_PARTICIPATION_BACK);
    }

    @FXML
    private void openEvenementFront() {
        loadPage(Constants.FXML_EVENEMENT_FRONT);
    }

    @FXML
    private void openParticipationFront() {
        loadPage(Constants.FXML_PARTICIPATION_FRONT);
    }
}
