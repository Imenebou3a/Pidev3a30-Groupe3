package org.example.utils;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DialogPane;
import javafx.stage.StageStyle;
import java.util.Optional;

/**
 * Classe utilitaire pour afficher des alertes professionnelles avec style moderne
 */
public class AlertUtils {

    private static final String DIALOG_CSS = "/css/dialogs.css";
    private static final Logger logger = Logger.getLogger(AlertUtils.class);

    /**
     * Applique le style CSS personnalisé à une alerte
     */
    private static void applyStyle(Alert alert, String styleClass) {
        try {
            DialogPane dialogPane = alert.getDialogPane();
            
            // Charger le CSS personnalisé
            String css = AlertUtils.class.getResource(DIALOG_CSS).toExternalForm();
            dialogPane.getStylesheets().add(css);
            
            // Ajouter la classe de style spécifique
            if (styleClass != null && !styleClass.isEmpty()) {
                dialogPane.getStyleClass().add(styleClass);
            }
            
            // Style moderne sans décoration par défaut
            alert.initStyle(StageStyle.TRANSPARENT);
            
        } catch (Exception e) {
            logger.error("Erreur lors de l'application du style à l'alerte: " + e.getMessage(), e);
        }
    }

    /**
     * Affiche une alerte de succès
     */
    public static void showSuccess(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText("✅ " + title);
        alert.setContentText(message);
        applyStyle(alert, "success");
        alert.showAndWait();
    }

    /**
     * Affiche une alerte d'erreur
     */
    public static void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText("❌ " + title);
        alert.setContentText(message);
        applyStyle(alert, "error");
        alert.showAndWait();
    }

    /**
     * Affiche une alerte d'avertissement
     */
    public static void showWarning(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText("⚠️ " + title);
        alert.setContentText(message);
        applyStyle(alert, "warning");
        alert.showAndWait();
    }

    /**
     * Affiche une alerte d'information
     */
    public static void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText("ℹ️ " + title);
        alert.setContentText(message);
        applyStyle(alert, "information");
        alert.showAndWait();
    }

    /**
     * Affiche une confirmation et retourne true si OK
     */
    public static boolean showConfirmation(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(title);
        alert.setHeaderText("❓ " + title);
        alert.setContentText(message);
        applyStyle(alert, "confirmation");
        
        Optional<ButtonType> result = alert.showAndWait();
        return result.isPresent() && result.get() == ButtonType.OK;
    }

    /**
     * Affiche une confirmation de suppression
     */
    public static boolean showDeleteConfirmation(String itemName) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation de suppression");
        alert.setHeaderText("🗑️ Supprimer " + itemName + " ?");
        alert.setContentText("Voulez-vous vraiment supprimer " + itemName + " ?\n\nCette action est irréversible.");
        applyStyle(alert, "warning");
        
        Optional<ButtonType> result = alert.showAndWait();
        return result.isPresent() && result.get() == ButtonType.OK;
    }

    /**
     * Affiche un message de chargement (non bloquant)
     */
    public static Alert showLoading(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Chargement");
        alert.setHeaderText("⏳ Veuillez patienter...");
        alert.setContentText(message);
        applyStyle(alert, "information");
        alert.show();
        return alert;
    }

    /**
     * Affiche une alerte simple sans style personnalisé (fallback)
     */
    public static void showSimple(Alert.AlertType type, String title, String header, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
