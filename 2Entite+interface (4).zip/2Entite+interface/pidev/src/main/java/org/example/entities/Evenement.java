package org.example.entities;

import javafx.beans.property.*;
import java.time.LocalDate;

public class Evenement {

    private final LongProperty idEvent = new SimpleLongProperty();
    private final StringProperty titre = new SimpleStringProperty();
    private final StringProperty description = new SimpleStringProperty();
    private final ObjectProperty<LocalDate> dateEvent = new SimpleObjectProperty<>();
    private final StringProperty heureEvent = new SimpleStringProperty();
    private final StringProperty lieu = new SimpleStringProperty();
    private final DoubleProperty prix = new SimpleDoubleProperty();
    private final IntegerProperty nbPlaces = new SimpleIntegerProperty();
    private final StringProperty statut = new SimpleStringProperty();

    // Constructeurs
    public Evenement() {}

    public Evenement(String titre, String description, LocalDate dateEvent,
                     String heureEvent, String lieu, double prix,
                     int nbPlaces, String statut) {
        this.titre.set(titre);
        this.description.set(description);
        this.dateEvent.set(dateEvent);
        this.heureEvent.set(heureEvent);
        this.lieu.set(lieu);
        this.prix.set(prix);
        this.nbPlaces.set(nbPlaces);
        this.statut.set(statut);
    }

    // Getters / Setters
    public long getIdEvent() { return idEvent.get(); }
    public void setIdEvent(long id) { this.idEvent.set(id); }
    public LongProperty idEventProperty() { return idEvent; }

    public String getTitre() { return titre.get(); }
    public void setTitre(String t) { this.titre.set(t); }
    public StringProperty titreProperty() { return titre; }

    public String getDescription() { return description.get(); }
    public void setDescription(String d) { this.description.set(d); }
    public StringProperty descriptionProperty() { return description; }

    public LocalDate getDateEvent() { return dateEvent.get(); }
    public void setDateEvent(LocalDate d) { this.dateEvent.set(d); }
    public ObjectProperty<LocalDate> dateEventProperty() { return dateEvent; }

    public String getHeureEvent() { return heureEvent.get(); }
    public void setHeureEvent(String h) { this.heureEvent.set(h); }
    public StringProperty heureEventProperty() { return heureEvent; }

    public String getLieu() { return lieu.get(); }
    public void setLieu(String l) { this.lieu.set(l); }
    public StringProperty lieuProperty() { return lieu; }

    public double getPrix() { return prix.get(); }
    public void setPrix(double p) { this.prix.set(p); }
    public DoubleProperty prixProperty() { return prix; }

    public int getNbPlaces() { return nbPlaces.get(); }
    public void setNbPlaces(int n) { this.nbPlaces.set(n); }
    public IntegerProperty nbPlacesProperty() { return nbPlaces; }

    public String getStatut() { return statut.get(); }
    public void setStatut(String s) { this.statut.set(s); }
    public StringProperty statutProperty() { return statut; }
}
