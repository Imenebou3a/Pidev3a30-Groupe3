package org.example.utils;

import org.example.exceptions.DatabaseException;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Gestionnaire de connexion à la base de données
 * Utilise le pattern Singleton pour une connexion unique
 */
public class MyDataBase {

    private static final Logger logger = Logger.getLogger(MyDataBase.class);
    private static Connection conn;
    private static Properties dbProperties;

    static {
        // Charger les propriétés au démarrage
        dbProperties = new Properties();
        try (InputStream input = MyDataBase.class.getClassLoader().getResourceAsStream("db.properties")) {
            if (input == null) {
                logger.warn("Fichier db.properties introuvable ! Utilisation des valeurs par défaut.");
                // Valeurs par défaut en cas d'absence du fichier
                dbProperties.setProperty("db.url", "jdbc:mysql://localhost:3306/pidev?useSSL=false&serverTimezone=UTC");
                dbProperties.setProperty("db.username", "root");
                dbProperties.setProperty("db.password", "");
                dbProperties.setProperty("db.driver", "com.mysql.cj.jdbc.Driver");
            } else {
                dbProperties.load(input);
                logger.info("Configuration DB chargée depuis db.properties");
            }
        } catch (IOException e) {
            logger.error("Erreur lors du chargement de db.properties", e);
            throw new DatabaseException("Impossible de charger la configuration de la base de données", e);
        }
    }

    /**
     * Obtient une connexion à la base de données (Singleton)
     * @return Connection active
     * @throws DatabaseException si la connexion échoue
     */
    public static Connection getConnection() {
        try {
            // Vérifier si la connexion existe et est valide
            if (conn == null || conn.isClosed()) {
                String driver = dbProperties.getProperty("db.driver");
                String url = dbProperties.getProperty("db.url");
                String username = dbProperties.getProperty("db.username");
                String password = dbProperties.getProperty("db.password");

                Class.forName(driver);
                conn = DriverManager.getConnection(url, username, password);
                logger.info("Connexion à la DB réussie");
            }
        } catch (ClassNotFoundException e) {
            logger.error("Driver MySQL non trouvé", e);
            throw new DatabaseException("Driver MySQL introuvable", e);
        } catch (SQLException e) {
            logger.error("Erreur SQL lors de la connexion", e);
            throw new DatabaseException("Impossible de se connecter à la base de données", e);
        }
        return conn;
    }

    /**
     * Ferme la connexion à la base de données
     */
    public static void closeConnection() {
        if (conn != null) {
            try {
                conn.close();
                conn = null;
                logger.info("Connexion DB fermée");
            } catch (SQLException e) {
                logger.error("Erreur lors de la fermeture de la connexion", e);
            }
        }
    }
    
    /**
     * Vérifie si la connexion est active
     * @return true si la connexion est active
     */
    public static boolean isConnected() {
        try {
            return conn != null && !conn.isClosed();
        } catch (SQLException e) {
            return false;
        }
    }
}
