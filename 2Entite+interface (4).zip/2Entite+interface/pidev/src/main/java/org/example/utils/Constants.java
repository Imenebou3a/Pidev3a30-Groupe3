package org.example.utils;

/**
 * Classe contenant toutes les constantes de l'application
 * Centralise les valeurs pour faciliter la maintenance
 */
public class Constants {

    // ================= COULEURS LAMMETNA =================
    public static final String COLOR_TEAL = "#117A7A";
    public static final String COLOR_TEAL_DARK = "#0D5F5F";
    public static final String COLOR_TEAL_LIGHT = "#1A9999";
    public static final String COLOR_ORANGE = "#D9541E";
    public static final String COLOR_ORANGE_DARK = "#B84015";
    public static final String COLOR_CREAM = "#F5E6C8";
    
    // ================= CHEMINS FXML =================
    public static final String FXML_MAIN_LAYOUT = "/fxml/main/MainLayout.fxml";
    public static final String FXML_EVENEMENT_BACK = "/fxml/backoffice/EvenementBack.fxml";
    public static final String FXML_PARTICIPATION_BACK = "/fxml/backoffice/ParticipationBack.fxml";
    public static final String FXML_EVENEMENT_FRONT = "/fxml/frontoffice/EvenementFrontSimple.fxml";
    public static final String FXML_PARTICIPATION_FRONT = "/fxml/frontoffice/ParticipationFrontSimple.fxml";
    
    // ================= CHEMINS RESSOURCES =================
    public static final String IMAGE_LOGO = "/images/logo.png";
    public static final String CSS_FRONTOFFICE = "@../../css/frontoffice.css";
    public static final String CSS_BACKOFFICE = "@../../css/backoffice.css";
    public static final String CSS_MAINLAYOUT = "@../../css/mainlayout.css";
    public static final String CSS_ADDITIONS = "@../../css/additions.css";
    
    // ================= STATUTS ÉVÉNEMENTS =================
    public static final String STATUT_ACTIF = "Actif";
    public static final String STATUT_COMPLET = "Complet";
    public static final String STATUT_ANNULE = "Annulé";
    
    // ================= VALIDATION =================
    public static final int TITRE_MIN_LENGTH = 3;
    public static final int TITRE_MAX_LENGTH = 100;
    public static final int DESCRIPTION_MIN_LENGTH = 10;
    public static final int DESCRIPTION_MAX_LENGTH = 500;
    public static final int LIEU_MIN_LENGTH = 3;
    public static final int LIEU_MAX_LENGTH = 100;
    public static final double PRIX_MIN = 0.0;
    public static final double PRIX_MAX = 10000.0;
    public static final int PLACES_MIN = 1;
    public static final int PLACES_MAX = 10000;
    
    // ================= MESSAGES =================
    public static final String MSG_SUCCESS_AJOUT = "✅ Ajouté avec succès";
    public static final String MSG_SUCCESS_MODIFICATION = "✅ Modifié avec succès";
    public static final String MSG_SUCCESS_SUPPRESSION = "✅ Supprimé avec succès";
    public static final String MSG_ERROR_CHAMPS_VIDES = "❌ Veuillez remplir tous les champs obligatoires";
    public static final String MSG_ERROR_VALIDATION = "❌ Erreur de validation";
    public static final String MSG_ERROR_DATABASE = "❌ Erreur de base de données";
    public static final String MSG_CONFIRM_SUPPRESSION = "Êtes-vous sûr de vouloir supprimer cet élément ?";
    
    // ================= ANIMATIONS =================
    public static final int ANIMATION_DURATION_MS = 300;
    public static final double ANIMATION_FADE_FROM = 0.5;
    public static final double ANIMATION_FADE_TO = 1.0;
    
    // ================= APPLICATION =================
    public static final String APP_NAME = "Lammetna";
    public static final String APP_VERSION = "1.0.0";
    public static final String APP_TITLE = "Lammetna - Gestion d'Événements";
    public static final String APP_COPYRIGHT = "© 2024 Lammetna - Tous droits réservés";
    
    // Constructeur privé pour empêcher l'instanciation
    private Constants() {
        throw new UnsupportedOperationException("Cette classe ne peut pas être instanciée");
    }
}
