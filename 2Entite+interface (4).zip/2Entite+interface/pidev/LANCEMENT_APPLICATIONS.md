# 🚀 Lancement des Applications Lammetna

## 📋 Vue d'ensemble

Le projet Lammetna est maintenant divisé en **deux applications indépendantes** :

1. **Back Office** - Interface d'administration pour gérer les événements et participations
2. **Front Office** - Interface publique pour consulter et s'inscrire aux événements

Les deux applications partagent la **même base de données** MySQL.

---

## 🔧 Prérequis

- Java 17 ou supérieur
- Maven
- MySQL avec la base de données configurée
- Fichier `db.properties` configuré dans `src/main/resources/`

---

## 🎯 Lancement des Applications

### Option 1 : Via Maven (Recommandé)

#### Lancer le Back Office (Administration)
```bash
mvn javafx:run
```
ou
```bash
mvn javafx:run -Djavafx.mainClass=org.example.MainBackoffice
```

#### Lancer le Front Office (Public)
```bash
mvn javafx:run -Djavafx.mainClass=org.example.MainFrontoffice
```

#### Lancer l'application originale (avec sidebar)
```bash
mvn javafx:run -Djavafx.mainClass=org.example.Main
```

### Option 2 : Via IDE (IntelliJ IDEA / Eclipse)

#### Back Office
1. Ouvrir `MainBackoffice.java`
2. Clic droit → Run 'MainBackoffice.main()'

#### Front Office
1. Ouvrir `MainFrontoffice.java`
2. Clic droit → Run 'MainFrontoffice.main()'

### Option 3 : Via ligne de commande Java

Après compilation (`mvn compile`):

#### Back Office
```bash
java --module-path "path/to/javafx-sdk/lib" --add-modules javafx.controls,javafx.fxml -cp target/classes org.example.MainBackoffice
```

#### Front Office
```bash
java --module-path "path/to/javafx-sdk/lib" --add-modules javafx.controls,javafx.fxml -cp target/classes org.example.MainFrontoffice
```

---

## 📁 Structure des Applications

### Back Office
- **Point d'entrée** : `MainBackoffice.java`
- **Layout** : `BackofficeLayout.fxml`
- **Contrôleur** : `BackofficeLayoutController.java`
- **Pages** :
  - Gestion des événements (`EvenementBack.fxml`)
  - Gestion des participations (`ParticipationBack.fxml`)

### Front Office
- **Point d'entrée** : `MainFrontoffice.java`
- **Layout** : `FrontofficeLayout.fxml`
- **Contrôleur** : `FrontofficeLayoutController.java`
- **Pages** :
  - Consultation des événements (`EvenementFront.fxml`)
  - Inscription aux événements (`ParticipationFront.fxml`)

---

## 🔗 Base de Données Partagée

Les deux applications utilisent la **même connexion** via :
- `MyDataBase.java` (Singleton pattern)
- Configuration dans `db.properties`

Cela signifie que :
- Les événements créés dans le Back Office apparaissent immédiatement dans le Front Office
- Les inscriptions faites dans le Front Office sont visibles dans le Back Office
- Les deux applications peuvent fonctionner **simultanément**

---

## ⚡ Raccourcis Clavier

Les deux applications supportent :
- **F5** : Actualiser la page
- **Ctrl+Q** : Quitter l'application

---

## 🎨 Différences Visuelles

### Back Office
- Titre : "Lammetna - Back Office"
- Sidebar : "ADMINISTRATION"
- Utilisateur : "Administrateur"
- Fonctionnalités : CRUD complet (Ajouter, Modifier, Supprimer, Afficher)

### Front Office
- Titre : "Lammetna - Événements Culturels"
- Sidebar : "MENU"
- Utilisateur : "Visiteur"
- Fonctionnalités : Consultation et inscription uniquement

---

## 📝 Notes Importantes

1. **Compilation** : Toujours compiler avant de lancer (`mvn compile`)
2. **Base de données** : Vérifier que MySQL est démarré
3. **Configuration** : Le fichier `db.properties` doit être présent
4. **Simultanéité** : Les deux applications peuvent tourner en même temps
5. **Tests** : Les fichiers de test (TestConnexion, TestEvenement, TestParticipation) restent disponibles

---

## 🐛 Dépannage

### Erreur "Cannot find symbol"
```bash
mvn clean compile
```

### Erreur de connexion à la base de données
Vérifier `db.properties` :
```properties
db.url=jdbc:mysql://localhost:3306/votre_base
db.user=votre_utilisateur
db.password=votre_mot_de_passe
```

### Logo non trouvé
Vérifier que `logo.png` existe dans `src/main/resources/images/`

---

## ✅ Validation

Pour votre présentation demain, vous pouvez :
1. Lancer le **Back Office** pour montrer la gestion administrative
2. Lancer le **Front Office** pour montrer l'interface publique
3. Démontrer que les deux sont **synchronisés** via la même base de données
4. Montrer que les applications sont **indépendantes** (pas de sidebar commune)

---

**Version** : 1.0.0  
**Date** : Février 2024  
**Projet** : Lammetna - Gestion d'Événements
