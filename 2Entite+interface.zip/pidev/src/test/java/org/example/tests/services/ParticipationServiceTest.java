package org.example.services;

import org.example.entities.Participation;
import org.junit.jupiter.api.*;

import java.sql.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ParticipationServiceTest {

    private static ParticipationService service;
    private Participation testParticipation;

    @BeforeAll
    static void initService() {
        service = new ParticipationService();
    }

    @BeforeEach
    void setUp() {

        testParticipation = new Participation(
                "Ali",                      // nom
                "Ben Salah",               // prenom
                "ali@gmail.com",           // email
                "22123456",                // telephone
                Date.valueOf("2026-01-10"),// date
                "Confirmé",                // statut
                1                          // idEvent
        );
    }

    /* ================= AJOUT ================= */

    @Test
    @Order(1)
    void testAjouterParticipation() {

        service.ajouterParticipation(testParticipation);

        Participation retrieved =
                service.trouverParticipationParId(testParticipation.getId());

        assertNotNull(retrieved, "La participation doit être ajoutée");
        assertEquals("Ali", retrieved.getNom());
    }


    /* ================= MODIFICATION ================= */

    @Test
    @Order(2)
    void testModifierParticipation() {

        service.ajouterParticipation(testParticipation);

        testParticipation.setStatut("Annulé");
        testParticipation.setTelephone("99887766");

        service.modifierParticipation(testParticipation);

        Participation retrieved =
                service.trouverParticipationParId(testParticipation.getId());

        assertEquals("Annulé", retrieved.getStatut());
        assertEquals("99887766", retrieved.getTelephone());
    }


    /* ================= SUPPRESSION ================= */

    @Test
    @Order(3)
    void testSupprimerParticipation() {

        service.ajouterParticipation(testParticipation);

        service.supprimerParticipation(testParticipation.getId());

        Participation retrieved =
                service.trouverParticipationParId(testParticipation.getId());

        assertNull(retrieved, "La participation supprimée ne doit plus exister");
    }


    /* ================= LISTE ================= */

    @Test
    @Order(4)
    void testListeParticipations() {

        service.ajouterParticipation(testParticipation);

        List<Participation> participations =
                service.afficherParticipations();

        assertNotNull(participations, "La liste ne doit pas être nulle");

        assertTrue(
                participations.stream()
                        .anyMatch(p -> p.getId() == testParticipation.getId()),
                "La liste doit contenir la participation ajoutée"
        );
    }
}
