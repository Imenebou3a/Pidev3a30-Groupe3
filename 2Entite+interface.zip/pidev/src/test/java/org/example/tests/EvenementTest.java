package org.example.tests;

import org.example.entities.Evenement;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.*;

public class EvenementTest {

    private Evenement evenement;

    @BeforeEach
    void setUp() {

        evenement = new Evenement(
                "Event Test",
                "Description test",
                LocalDate.of(2026, 1, 1),
                "10:00",
                "Esprit",
                20.0,
                100,
                "Actif"
        );
    }

    @Test
    void testGetTitre() {
        assertEquals("Event Test", evenement.getTitre());
    }

    @Test
    void testGetPrix() {
        assertEquals(20.0, evenement.getPrix());
    }

    @Test
    void testGetNbPlaces() {
        assertEquals(100, evenement.getNb_places());
    }

    @Test
    void testGetStatut() {
        assertEquals("Actif", evenement.getStatut());
    }

    @Test
    void testSetLieu() {
        evenement.setLieu("Tunis");
        assertEquals("Tunis", evenement.getLieu());
    }
}
