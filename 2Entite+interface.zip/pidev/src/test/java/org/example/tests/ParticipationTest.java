package org.example.tests;

import org.example.entities.Participation;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.Date;

import static org.junit.jupiter.api.Assertions.*;

public class ParticipationTest {

    private Participation participation;

    @BeforeEach
    void setUp() {

        participation = new Participation(
                "Ali",                      // nom
                "Ben Salah",               // prenom
                "ali@gmail.com",           // email
                "22123456",                // telephone
                Date.valueOf("2026-01-10"),// date
                "Confirmé",                // statut
                1                          // idEvent
        );
    }

    /* ================= GETTERS ================= */

    @Test
    void testGetNom() {
        assertEquals("Ali", participation.getNom());
    }

    @Test
    void testGetPrenom() {
        assertEquals("Ben Salah", participation.getPrenom());
    }

    @Test
    void testGetEmail() {
        assertEquals("ali@gmail.com", participation.getEmail());
    }

    @Test
    void testGetTelephone() {
        assertEquals("22123456", participation.getTelephone());
    }

    @Test
    void testGetDate() {
        assertEquals(Date.valueOf("2026-01-10"), participation.getDate());
    }

    @Test
    void testGetStatut() {
        assertEquals("Confirmé", participation.getStatut());
    }

    @Test
    void testGetIdEvent() {
        assertEquals(1, participation.getIdEvent());
    }


    /* ================= SETTERS ================= */

    @Test
    void testSetNom() {
        participation.setNom("Sami");
        assertEquals("Sami", participation.getNom());
    }

    @Test
    void testSetPrenom() {
        participation.setPrenom("Trabelsi");
        assertEquals("Trabelsi", participation.getPrenom());
    }

    @Test
    void testSetEmail() {
        participation.setEmail("sami@gmail.com");
        assertEquals("sami@gmail.com", participation.getEmail());
    }

    @Test
    void testSetTelephone() {
        participation.setTelephone("99112233");
        assertEquals("99112233", participation.getTelephone());
    }

    @Test
    void testSetDate() {
        Date newDate = Date.valueOf("2026-02-01");
        participation.setDate(newDate);
        assertEquals(newDate, participation.getDate());
    }

    @Test
    void testSetStatut() {
        participation.setStatut("Annulé");
        assertEquals("Annulé", participation.getStatut());
    }

    @Test
    void testSetIdEvent() {
        participation.setIdEvent(5);
        assertEquals(5, participation.getIdEvent());
    }
}
