package org.example.services;

import org.example.entities.Evenement;
import org.example.utils.MyDataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EvenementService {

    private final Connection conn;

    public EvenementService() {
        conn = MyDataBase.getConnection();
    }

    // 🔹 CREATE
    public boolean ajouterEvenement(Evenement e) {
        String sql = "INSERT INTO evenement (titre, description, date_event, heure_event, lieu, prix, nb_places, statut) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, e.getTitre());
            ps.setString(2, e.getDescription());
            ps.setDate(3, Date.valueOf(e.getDate_event()));
            ps.setString(4, e.getHeure_event());
            ps.setString(5, e.getLieu());
            ps.setDouble(6, e.getPrix());
            ps.setInt(7, e.getNb_places());
            ps.setString(8, e.getStatut());

            int rows = ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) e.setId_event(rs.getLong(1));
            return rows > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    // 🔹 READ : tous les événements
    public List<Evenement> afficherEvenements() {
        List<Evenement> evenements = new ArrayList<>();
        String sql = "SELECT * FROM evenement";
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Evenement e = new Evenement();
                e.setId_event(rs.getLong("id_event"));
                e.setTitre(rs.getString("titre"));
                e.setDescription(rs.getString("description"));
                e.setDate_event(rs.getDate("date_event").toLocalDate());
                e.setHeure_event(rs.getString("heure_event"));
                e.setLieu(rs.getString("lieu"));
                e.setPrix(rs.getDouble("prix"));
                e.setNb_places(rs.getInt("nb_places"));
                e.setStatut(rs.getString("statut"));
                evenements.add(e);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return evenements;
    }

    // 🔹 READ : par ID
    public Evenement trouverEvenementParId(long id) {
        Evenement e = null;
        String sql = "SELECT * FROM evenement WHERE id_event=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    e = new Evenement();
                    e.setId_event(rs.getLong("id_event"));
                    e.setTitre(rs.getString("titre"));
                    e.setDescription(rs.getString("description"));
                    e.setDate_event(rs.getDate("date_event").toLocalDate());
                    e.setHeure_event(rs.getString("heure_event"));
                    e.setLieu(rs.getString("lieu"));
                    e.setPrix(rs.getDouble("prix"));
                    e.setNb_places(rs.getInt("nb_places"));
                    e.setStatut(rs.getString("statut"));
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return e;
    }

    // 🔹 UPDATE
    public boolean modifierEvenement(Evenement e) {
        String sql = "UPDATE evenement SET titre=?, description=?, date_event=?, heure_event=?, lieu=?, prix=?, nb_places=?, statut=? " +
                "WHERE id_event=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, e.getTitre());
            ps.setString(2, e.getDescription());
            ps.setDate(3, Date.valueOf(e.getDate_event()));
            ps.setString(4, e.getHeure_event());
            ps.setString(5, e.getLieu());
            ps.setDouble(6, e.getPrix());
            ps.setInt(7, e.getNb_places());
            ps.setString(8, e.getStatut());
            ps.setLong(9, e.getId_event());
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    // 🔹 DELETE
    public boolean supprimerEvenement(long id_event) {
        String sql = "DELETE FROM evenement WHERE id_event=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id_event);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
}
