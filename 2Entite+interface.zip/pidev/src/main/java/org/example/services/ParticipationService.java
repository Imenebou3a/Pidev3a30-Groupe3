package org.example.services;

import org.example.entities.Participation;
import org.example.utils.MyDataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ParticipationService {

    private Connection conn;

    public ParticipationService() {
        conn = MyDataBase.getConnection();
    }

    // ================= AJOUT =================
    public void ajouterParticipation(Participation p) {
        String sql = "INSERT INTO participation " +
                "(nom_participant, prenom_participant, email, telephone, date_inscription, statut_p, id_event) " +
                "VALUES (?,?,?,?,?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, p.getNom());
            ps.setString(2, p.getPrenom());
            ps.setString(3, p.getEmail());
            ps.setString(4, p.getTelephone());
            ps.setDate(5, p.getDate());
            ps.setString(6, p.getStatut());
            ps.setInt(7, p.getIdEvent());

            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                p.setId(rs.getInt(1));
            }

            System.out.println("✅ Participation ajoutée");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ================= MODIFIER =================
    public void modifierParticipation(Participation p) {
        String sql = "UPDATE participation SET " +
                "nom_participant=?, prenom_participant=?, email=?, telephone=?, " +
                "date_inscription=?, statut_p=?, id_event=? " +
                "WHERE id_participation=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, p.getNom());
            ps.setString(2, p.getPrenom());
            ps.setString(3, p.getEmail());
            ps.setString(4, p.getTelephone());
            ps.setDate(5, p.getDate());
            ps.setString(6, p.getStatut());
            ps.setInt(7, p.getIdEvent());
            ps.setInt(8, p.getId());
            ps.executeUpdate();
            System.out.println("✏️ Participation modifiée");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ================= SUPPRIMER =================
    public void supprimerParticipation(int id) {
        String sql = "DELETE FROM participation WHERE id_participation=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("🗑️ Participation supprimée");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ================= TROUVER PAR ID =================
    public Participation trouverParticipationParId(int id) {
        String sql = "SELECT * FROM participation WHERE id_participation=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Participation(
                        rs.getInt("id_participation"),
                        rs.getString("nom_participant"),
                        rs.getString("prenom_participant"),
                        rs.getString("email"),
                        rs.getString("telephone"),
                        rs.getDate("date_inscription"),
                        rs.getString("statut_p"),
                        rs.getInt("id_event")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // ================= AFFICHER =================
    public List<Participation> afficherParticipations() {
        List<Participation> list = new ArrayList<>();
        String sql = "SELECT * FROM participation";
        try (Statement st = conn.createStatement()) {
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                list.add(new Participation(
                        rs.getInt("id_participation"),
                        rs.getString("nom_participant"),
                        rs.getString("prenom_participant"),
                        rs.getString("email"),
                        rs.getString("telephone"),
                        rs.getDate("date_inscription"),
                        rs.getString("statut_p"),
                        rs.getInt("id_event")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
