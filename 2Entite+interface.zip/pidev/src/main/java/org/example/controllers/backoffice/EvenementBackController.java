package org.example.controllers.backoffice;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import org.example.entities.Evenement;
import org.example.services.EvenementService;

import java.time.LocalDate;
import java.util.List;

public class EvenementBackController {

    // ================= AJOUT =================
    @FXML private TextField txtTitre;
    @FXML private TextField txtDescription;
    @FXML private DatePicker dpDate;
    @FXML private TextField txtHeure;
    @FXML private TextField txtLieu;
    @FXML private TextField txtPrix;
    @FXML private TextField txtPlaces;
    @FXML private ComboBox<String> cbStatut;

    // ================= MODIFIER =================
    @FXML private TextField txtIdModif;
    @FXML private TextField txtTitreModif;
    @FXML private TextField txtDescriptionModif;
    @FXML private DatePicker dpDateModif;
    @FXML private TextField txtHeureModif;
    @FXML private TextField txtLieuModif;
    @FXML private TextField txtPrixModif;
    @FXML private TextField txtPlacesModif;
    @FXML private ComboBox<String> cbStatutModif;

    // ================= SUPPRIMER =================
    @FXML private TextField txtIdSupp;

    // ================= TABLE =================
    @FXML private TableView<Evenement> tableEvenements;
    @FXML private TableColumn<Evenement, Long> colId;
    @FXML private TableColumn<Evenement, String> colTitre;
    @FXML private TableColumn<Evenement, String> colDescription;
    @FXML private TableColumn<Evenement, LocalDate> colDate;
    @FXML private TableColumn<Evenement, String> colHeure;
    @FXML private TableColumn<Evenement, String> colLieu;
    @FXML private TableColumn<Evenement, Double> colPrix;
    @FXML private TableColumn<Evenement, Integer> colPlaces;
    @FXML private TableColumn<Evenement, String> colStatut;
    @FXML private TableColumn<Evenement, Void> colAction;

    @FXML private TabPane tabPane;
    @FXML private Tab tabAjouter;
    @FXML private Tab tabModifier;
    @FXML private Tab tabAfficher;
    @FXML private Tab tabSupprimer;

    private EvenementService es = new EvenementService();
    private ObservableList<Evenement> evenementList = FXCollections.observableArrayList();

    // ================= INITIALIZE =================
    @FXML
    public void initialize() {
        cbStatut.setItems(FXCollections.observableArrayList("Actif", "Annulé", "Complet"));
        cbStatutModif.setItems(FXCollections.observableArrayList("Actif", "Annulé", "Complet"));

        // Initialiser TableView
        colId.setCellValueFactory(new PropertyValueFactory<>("id_event"));
        colTitre.setCellValueFactory(new PropertyValueFactory<>("titre"));
        colDescription.setCellValueFactory(new PropertyValueFactory<>("description"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("date_event"));
        colHeure.setCellValueFactory(new PropertyValueFactory<>("heure_event"));
        colLieu.setCellValueFactory(new PropertyValueFactory<>("lieu"));
        colPrix.setCellValueFactory(new PropertyValueFactory<>("prix"));
        colPlaces.setCellValueFactory(new PropertyValueFactory<>("nb_places"));
        colStatut.setCellValueFactory(new PropertyValueFactory<>("statut"));

        loadEvenements();
        addActionButtonsToTable();
    }

    // ================= AJOUT =================
    @FXML
    public void ajouterEvenement(ActionEvent event) {
        if (!validateAjoutFields()) return;

        Evenement e = new Evenement(
                txtTitre.getText(),
                txtDescription.getText(),
                dpDate.getValue(),
                txtHeure.getText(),
                txtLieu.getText(),
                Double.parseDouble(txtPrix.getText()),
                Integer.parseInt(txtPlaces.getText()),
                cbStatut.getValue()
        );

        es.ajouterEvenement(e);
        loadEvenements();
        clearAjouterFields();
        showAlert(Alert.AlertType.INFORMATION, "Événement ajouté avec succès !");
        tabPane.getSelectionModel().select(tabAfficher);
    }

    @FXML
    public void annulerAjout(ActionEvent event) {
        clearAjouterFields();
    }

    private boolean validateAjoutFields() {
        if (txtTitre.getText().isEmpty() || txtDescription.getText().isEmpty() ||
                dpDate.getValue() == null || txtHeure.getText().isEmpty() ||
                txtLieu.getText().isEmpty() || txtPrix.getText().isEmpty() ||
                txtPlaces.getText().isEmpty() || cbStatut.getValue() == null) {
            showAlert(Alert.AlertType.WARNING, "Tous les champs doivent être remplis !");
            return false;
        }
        if (!txtHeure.getText().matches("\\d{2}:\\d{2}")) {
            showAlert(Alert.AlertType.ERROR, "Format de l'heure invalide (HH:MM) !");
            return false;
        }
        try { if (Double.parseDouble(txtPrix.getText()) < 0) throw new NumberFormatException(); }
        catch (NumberFormatException e) { showAlert(Alert.AlertType.ERROR,"Prix invalide !"); return false; }
        try { if (Integer.parseInt(txtPlaces.getText()) < 0) throw new NumberFormatException(); }
        catch (NumberFormatException e) { showAlert(Alert.AlertType.ERROR,"Nombre de places invalide !"); return false; }
        return true;
    }

    // ================= MODIFIER =================
    @FXML
    public void modifierEvenement(ActionEvent event) {
        if (txtIdModif.getText().isEmpty()) { showAlert(Alert.AlertType.WARNING, "Veuillez saisir l'ID !"); return; }

        long id = Long.parseLong(txtIdModif.getText());
        Evenement e = es.trouverEvenementParId(id);
        if (e == null) { showAlert(Alert.AlertType.WARNING, "Événement introuvable !"); return; }
        if (!validateModifierFields()) return;

        e.setTitre(txtTitreModif.getText());
        e.setDescription(txtDescriptionModif.getText());
        e.setDate_event(dpDateModif.getValue());
        e.setHeure_event(txtHeureModif.getText());
        e.setLieu(txtLieuModif.getText());
        e.setPrix(Double.parseDouble(txtPrixModif.getText()));
        e.setNb_places(Integer.parseInt(txtPlacesModif.getText()));
        e.setStatut(cbStatutModif.getValue());

        es.modifierEvenement(e);
        loadEvenements();
        clearModifierFields();
        showAlert(Alert.AlertType.INFORMATION, "Événement modifié avec succès !");
        tabPane.getSelectionModel().select(tabAfficher);
    }

    @FXML
    public void annulerModification(ActionEvent event) {
        clearModifierFields();
    }

    private boolean validateModifierFields() {
        if (txtTitreModif.getText().isEmpty() || txtDescriptionModif.getText().isEmpty() ||
                dpDateModif.getValue() == null || txtHeureModif.getText().isEmpty() ||
                txtLieuModif.getText().isEmpty() || txtPrixModif.getText().isEmpty() ||
                txtPlacesModif.getText().isEmpty() || cbStatutModif.getValue() == null) {
            showAlert(Alert.AlertType.WARNING, "Tous les champs doivent être remplis !");
            return false;
        }
        if (!txtHeureModif.getText().matches("\\d{2}:\\d{2}")) {
            showAlert(Alert.AlertType.ERROR, "Format de l'heure invalide (HH:MM) !");
            return false;
        }
        try { if (Double.parseDouble(txtPrixModif.getText()) < 0) throw new NumberFormatException(); }
        catch (NumberFormatException e) { showAlert(Alert.AlertType.ERROR,"Prix invalide !"); return false; }
        try { if (Integer.parseInt(txtPlacesModif.getText()) < 0) throw new NumberFormatException(); }
        catch (NumberFormatException e) { showAlert(Alert.AlertType.ERROR,"Nombre de places invalide !"); return false; }
        return true;
    }

    // ================= SUPPRIMER =================
    @FXML
    public void supprimerEvenement(ActionEvent event) {
        if (txtIdSupp.getText().isEmpty()) { showAlert(Alert.AlertType.WARNING,"Veuillez saisir l'ID à supprimer !"); return; }

        long id = Long.parseLong(txtIdSupp.getText());
        Evenement e = es.trouverEvenementParId(id);
        if (e == null) { showAlert(Alert.AlertType.WARNING,"Événement introuvable !"); return; }

        es.supprimerEvenement(id);
        loadEvenements();
        showAlert(Alert.AlertType.INFORMATION,"Événement supprimé avec succès !");
        txtIdSupp.clear();
    }

    // ================= AFFICHER =================
    @FXML
    public void afficherEvenements(ActionEvent event) {
        loadEvenements();
    }

    // ================= CHARGER TABLE =================
    private void loadEvenements() {
        List<Evenement> events = es.afficherEvenements();
        evenementList.setAll(events);
        tableEvenements.setItems(evenementList);
    }

    // ================= CLEAR =================
    private void clearAjouterFields() {
        txtTitre.clear(); txtDescription.clear(); dpDate.setValue(null); txtHeure.clear();
        txtLieu.clear(); txtPrix.clear(); txtPlaces.clear(); cbStatut.getSelectionModel().clearSelection();
    }

    private void clearModifierFields() {
        txtIdModif.clear(); txtTitreModif.clear(); txtDescriptionModif.clear(); dpDateModif.setValue(null);
        txtHeureModif.clear(); txtLieuModif.clear(); txtPrixModif.clear(); txtPlacesModif.clear();
        cbStatutModif.getSelectionModel().clearSelection();
    }

    // ================= ALERT =================
    private void showAlert(Alert.AlertType type, String message) {
        Alert alert = new Alert(type, message);
        alert.showAndWait();
    }

    // ================= COLONNE ACTION =================
    private void addActionButtonsToTable() {
        colAction.setCellFactory(param -> new TableCell<>() {
            private final Button btnEdit = new Button("Modifier");
            private final Button btnDelete = new Button("Supprimer");

            {
                btnEdit.setStyle("-fx-background-color: lightblue;");
                btnDelete.setStyle("-fx-background-color: lightcoral;");

                btnEdit.setOnAction(event -> {
                    Evenement e = getTableView().getItems().get(getIndex());
                    prefillModificationForm(e);
                    tabPane.getSelectionModel().select(tabModifier);
                });

                btnDelete.setOnAction(event -> {
                    Evenement e = getTableView().getItems().get(getIndex());
                    es.supprimerEvenement(e.getId_event());
                    loadEvenements();
                    showAlert(Alert.AlertType.INFORMATION,"Événement supprimé !");
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : new HBox(10, btnEdit, btnDelete));
            }
        });
    }

    private void prefillModificationForm(Evenement e) {
        txtIdModif.setText(String.valueOf(e.getId_event()));
        txtTitreModif.setText(e.getTitre());
        txtDescriptionModif.setText(e.getDescription());
        dpDateModif.setValue(e.getDate_event());
        txtHeureModif.setText(e.getHeure_event());
        txtLieuModif.setText(e.getLieu());
        txtPrixModif.setText(String.valueOf(e.getPrix()));
        txtPlacesModif.setText(String.valueOf(e.getNb_places()));
        cbStatutModif.setValue(e.getStatut());
    }
}
