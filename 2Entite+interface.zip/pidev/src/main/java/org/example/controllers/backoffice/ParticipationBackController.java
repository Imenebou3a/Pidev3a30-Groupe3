package org.example.controllers.backoffice;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import org.example.entities.Participation;
import org.example.services.ParticipationService;

import java.sql.Date;

public class ParticipationBackController {

    @FXML private TabPane tabPane;

    @FXML private TableView<Participation> tableParticipation;
    @FXML private TableColumn<Participation, Integer> colId;
    @FXML private TableColumn<Participation, String> colNom;
    @FXML private TableColumn<Participation, String> colPrenom;
    @FXML private TableColumn<Participation, String> colEmail;
    @FXML private TableColumn<Participation, String> colTelephone;
    @FXML private TableColumn<Participation, Date> colDate;
    @FXML private TableColumn<Participation, String> colStatut;
    @FXML private TableColumn<Participation, Integer> colEvent;
    @FXML private TableColumn<Participation, Void> colAction;

    @FXML private TextField tfIdModif, tfNomModif, tfPrenomModif, tfEmailModif,
            tfTelephoneModif, tfStatutModif, tfEventModif;
    @FXML private DatePicker dpDateModif;

    private final ParticipationService participationService = new ParticipationService();
    private final ObservableList<Participation> list = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        colPrenom.setCellValueFactory(new PropertyValueFactory<>("prenom"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colTelephone.setCellValueFactory(new PropertyValueFactory<>("telephone"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("date"));
        colStatut.setCellValueFactory(new PropertyValueFactory<>("statut"));
        colEvent.setCellValueFactory(new PropertyValueFactory<>("idEvent"));

        loadData();
        addActionButtons();
    }

    @FXML
    public void loadData() {
        list.clear();
        list.addAll(participationService.afficherParticipations()); // ✅ méthode correcte
        tableParticipation.setItems(list);
    }

    private void addActionButtons() {
        colAction.setCellFactory(param -> new TableCell<>() {
            private final Button btnModifier = new Button("Modifier");
            private final Button btnSupprimer = new Button("Supprimer");
            private final HBox pane = new HBox(5, btnModifier, btnSupprimer);

            {
                btnModifier.setOnAction(event -> {
                    Participation p = getTableView().getItems().get(getIndex());
                    remplirFormulaire(p);
                    tabPane.getSelectionModel().select(1);
                });

                btnSupprimer.setOnAction(event -> {
                    Participation p = getTableView().getItems().get(getIndex());
                    participationService.supprimerParticipation(p.getId()); // ✅ méthode correcte
                    loadData();
                    showAlert("Succès", "Participation supprimée !");
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : pane);
            }
        });
    }

    private void remplirFormulaire(Participation p) {
        tfIdModif.setText(String.valueOf(p.getId()));
        tfNomModif.setText(p.getNom());
        tfPrenomModif.setText(p.getPrenom());
        tfEmailModif.setText(p.getEmail());
        tfTelephoneModif.setText(p.getTelephone());
        dpDateModif.setValue(p.getDate().toLocalDate());
        tfStatutModif.setText(p.getStatut());
        tfEventModif.setText(String.valueOf(p.getIdEvent()));
    }

    @FXML
    private void confirmerModification() {
        if(!validateFields()) return;

        try {
            int idEvent = Integer.parseInt(tfEventModif.getText());
            int id = Integer.parseInt(tfIdModif.getText());

            Participation p = new Participation(id,
                    tfNomModif.getText(),
                    tfPrenomModif.getText(),
                    tfEmailModif.getText(),
                    tfTelephoneModif.getText(),
                    Date.valueOf(dpDateModif.getValue()),
                    tfStatutModif.getText(),
                    idEvent
            );

            participationService.modifierParticipation(p); // ✅ méthode correcte
            showAlert("Succès", "Participation modifiée !");
            clearFields();
            loadData();
            tabPane.getSelectionModel().select(0);

        } catch (NumberFormatException e) {
            showAlert("Erreur", "ID ou ID Event invalide !");
        }
    }

    private boolean validateFields() {
        if(tfNomModif.getText().isEmpty() || tfPrenomModif.getText().isEmpty() ||
                tfEmailModif.getText().isEmpty() || tfTelephoneModif.getText().isEmpty() ||
                dpDateModif.getValue() == null || tfStatutModif.getText().isEmpty() ||
                tfEventModif.getText().isEmpty() || tfIdModif.getText().isEmpty()) {
            showAlert("Erreur", "Tous les champs sont obligatoires !");
            return false;
        }
        if(!tfEmailModif.getText().matches("^\\S+@\\S+\\.\\S+$")) { showAlert("Erreur", "Email invalide !"); return false; }
        if(!tfTelephoneModif.getText().matches("\\d{8,15}")) { showAlert("Erreur", "Téléphone invalide !"); return false; }
        if(!tfNomModif.getText().matches("[a-zA-Z ]+")) { showAlert("Erreur", "Nom invalide !"); return false; }
        if(!tfPrenomModif.getText().matches("[a-zA-Z ]+")) { showAlert("Erreur", "Prénom invalide !"); return false; }
        if(!tfEventModif.getText().matches("\\d+")) { showAlert("Erreur", "ID Event invalide !"); return false; }
        if(!tfIdModif.getText().matches("\\d+")) { showAlert("Erreur", "ID invalide !"); return false; }
        return true;
    }

    private void clearFields() {
        tfIdModif.clear(); tfNomModif.clear(); tfPrenomModif.clear(); tfEmailModif.clear();
        tfTelephoneModif.clear(); dpDateModif.setValue(null); tfStatutModif.clear(); tfEventModif.clear();
    }

    private void showAlert(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title); alert.setHeaderText(null); alert.setContentText(msg);
        alert.showAndWait();
    }
}
