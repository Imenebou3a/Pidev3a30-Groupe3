package org.example.controllers.frontoffice;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.example.entities.Participation;
import org.example.services.ParticipationService;
import java.sql.Date;

public class ParticipationFrontController {

    @FXML private TextField tfNom, tfPrenom, tfEmail, tfTelephone, tfStatut, tfEvent;
    @FXML private DatePicker dpDate;

    private final ParticipationService participationService = new ParticipationService();

    /* ================= AJOUT ================= */
    @FXML
    private void ajouterParticipation() {
        if (!validateFields()) return;

        try {
            int idEvent = Integer.parseInt(tfEvent.getText());

            Participation p = new Participation(
                    tfNom.getText(),
                    tfPrenom.getText(),
                    tfEmail.getText(),
                    tfTelephone.getText(),
                    Date.valueOf(dpDate.getValue()),
                    tfStatut.getText(),
                    idEvent
            );

            participationService.ajouterParticipation(p); // ✅ méthode correcte
            clearFields();
            showAlert("Succès", "Participation ajoutée !");
        } catch (NumberFormatException e) {
            showAlert("Erreur", "ID Event invalide !");
        }
    }

    @FXML
    private void annulerAjout() {
        clearFields();
    }

    /* ================= VALIDATION ================= */
    private boolean validateFields() {
        if(tfNom.getText().isEmpty() || tfPrenom.getText().isEmpty() ||
                tfEmail.getText().isEmpty() || tfTelephone.getText().isEmpty() ||
                dpDate.getValue() == null || tfStatut.getText().isEmpty() ||
                tfEvent.getText().isEmpty()) {
            showAlert("Erreur", "Tous les champs sont obligatoires !");
            return false;
        }
        if(!tfEmail.getText().matches("^\\S+@\\S+\\.\\S+$")) {
            showAlert("Erreur", "Email invalide !");
            return false;
        }
        if(!tfTelephone.getText().matches("\\d{8,15}")) {
            showAlert("Erreur", "Téléphone invalide !");
            return false;
        }
        if(!tfNom.getText().matches("[a-zA-Z ]+")) {
            showAlert("Erreur", "Nom invalide !");
            return false;
        }
        if(!tfPrenom.getText().matches("[a-zA-Z ]+")) {
            showAlert("Erreur", "Prénom invalide !");
            return false;
        }
        if(!tfEvent.getText().matches("\\d+")) {
            showAlert("Erreur", "ID Event invalide !");
            return false;
        }
        return true;
    }

    /* ================= UTILITAIRES ================= */
    private void clearFields() {
        tfNom.clear();
        tfPrenom.clear();
        tfEmail.clear();
        tfTelephone.clear();
        dpDate.setValue(null);
        tfStatut.clear();
        tfEvent.clear();
    }

    private void showAlert(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
