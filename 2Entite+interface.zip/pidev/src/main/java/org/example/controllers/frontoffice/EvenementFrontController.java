package org.example.controllers.frontoffice;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.entities.Evenement;
import org.example.services.EvenementService;

import java.time.LocalDate;
import java.util.List;

public class EvenementFrontController {

    @FXML private TableView<Evenement> tableEvenementsFront;
    @FXML private TableColumn<Evenement, String> colTitreFront;
    @FXML private TableColumn<Evenement, String> colDescriptionFront;
    @FXML private TableColumn<Evenement, LocalDate> colDateFront;
    @FXML private TableColumn<Evenement, String> colHeureFront;
    @FXML private TableColumn<Evenement, String> colLieuFront;
    @FXML private TableColumn<Evenement, Double> colPrixFront;
    @FXML private TableColumn<Evenement, Integer> colPlacesFront;
    @FXML private TableColumn<Evenement, String> colStatutFront;

    private EvenementService es = new EvenementService();
    private ObservableList<Evenement> evenementList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        colTitreFront.setCellValueFactory(new PropertyValueFactory<>("titre"));
        colDescriptionFront.setCellValueFactory(new PropertyValueFactory<>("description"));
        colDateFront.setCellValueFactory(new PropertyValueFactory<>("date_event"));
        colHeureFront.setCellValueFactory(new PropertyValueFactory<>("heure_event"));
        colLieuFront.setCellValueFactory(new PropertyValueFactory<>("lieu"));
        colPrixFront.setCellValueFactory(new PropertyValueFactory<>("prix"));
        colPlacesFront.setCellValueFactory(new PropertyValueFactory<>("nb_places"));
        colStatutFront.setCellValueFactory(new PropertyValueFactory<>("statut"));

        loadEvenementsFront();
    }

    private void loadEvenementsFront() {
        List<Evenement> events = es.afficherEvenements();
        // Montrer uniquement les événements actifs et disponibles
        events.removeIf(e -> !e.getStatut().equals("Actif") || e.getNb_places() <= 0);
        evenementList.setAll(events);
        tableEvenementsFront.setItems(evenementList);
    }
}
