package org.example.entities;

import javafx.beans.property.*;
import java.time.LocalDate;

public class Evenement {

    private LongProperty id_event = new SimpleLongProperty();
    private StringProperty titre = new SimpleStringProperty();
    private StringProperty description = new SimpleStringProperty();
    private ObjectProperty<LocalDate> date_event = new SimpleObjectProperty<>();
    private StringProperty heure_event = new SimpleStringProperty(); // on stocke en String
    private StringProperty lieu = new SimpleStringProperty();
    private DoubleProperty prix = new SimpleDoubleProperty();
    private IntegerProperty nb_places = new SimpleIntegerProperty();
    private StringProperty statut = new SimpleStringProperty();

    public Evenement() { }

    public Evenement(String titre, String description,
                     LocalDate date_event, String heure_event,
                     String lieu, double prix,
                     int nb_places, String statut) {
        this.titre.set(titre);
        this.description.set(description);
        this.date_event.set(date_event);
        this.heure_event.set(heure_event);
        this.lieu.set(lieu);
        this.prix.set(prix);
        this.nb_places.set(nb_places);
        this.statut.set(statut);
    }

    // Getters & Setters
    public long getId_event() { return id_event.get(); }
    public void setId_event(long id_event) { this.id_event.set(id_event); }

    public String getTitre() { return titre.get(); }
    public void setTitre(String titre) { this.titre.set(titre); }

    public String getDescription() { return description.get(); }
    public void setDescription(String description) { this.description.set(description); }

    public LocalDate getDate_event() { return date_event.get(); }
    public void setDate_event(LocalDate date_event) { this.date_event.set(date_event); }

    public String getHeure_event() { return heure_event.get(); }
    public void setHeure_event(String heure_event) { this.heure_event.set(heure_event); }

    public String getLieu() { return lieu.get(); }
    public void setLieu(String lieu) { this.lieu.set(lieu); }

    public double getPrix() { return prix.get(); }
    public void setPrix(double prix) { this.prix.set(prix); }

    public int getNb_places() { return nb_places.get(); }
    public void setNb_places(int nb_places) { this.nb_places.set(nb_places); }

    public String getStatut() { return statut.get(); }
    public void setStatut(String statut) { this.statut.set(statut); }
}
