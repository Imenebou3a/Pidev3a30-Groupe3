package org.example.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyDataBase {

    private static Connection conn;

    // Méthode pour récupérer la connexion
    public static Connection getConnection() {
        if (conn == null) {
            try {
                // Charger le driver MySQL
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/pidev?useSSL=false&serverTimezone=UTC",
                        "root", ""); // mot de passe XAMPP vide par défaut
                System.out.println("✅ Connexion à la DB réussie !");
            } catch (ClassNotFoundException e) {
                System.out.println("❌ Driver MySQL non trouvé !");
                e.printStackTrace();
            } catch (SQLException e) {
                System.out.println("❌ Erreur SQL : " + e.getMessage());
                e.printStackTrace();
            }
        }
        return conn;
    }
}
