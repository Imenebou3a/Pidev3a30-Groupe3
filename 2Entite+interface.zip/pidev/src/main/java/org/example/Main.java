package org.example;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        try {
            // BOUTONS MENU PRINCIPAL
            Button btnEvenementBack = new Button("Événements BackOffice");
            Button btnParticipationBack = new Button("Participations BackOffice");
            Button btnEvenementFront = new Button("Événements FrontOffice");
            Button btnParticipationFront = new Button("Participations FrontOffice");

            VBox root = new VBox(15, btnEvenementBack, btnParticipationBack, btnEvenementFront, btnParticipationFront);
            root.setStyle("-fx-padding: 30; -fx-alignment: center;");

            Scene scene = new Scene(root, 400, 300);
            primaryStage.setScene(scene);
            primaryStage.setTitle("Menu Principal - Lametna");
            primaryStage.show();

            // BACKOFFICE
            btnEvenementBack.setOnAction(e -> openFXML("/fxml/backoffice/EvenementBack.fxml", "Gestion Événements BackOffice"));
            btnParticipationBack.setOnAction(e -> openFXML("/fxml/backoffice/ParticipationBack.fxml", "Gestion Participations BackOffice"));

            // FRONTOFFICE
            btnEvenementFront.setOnAction(e -> openFXML("/fxml/frontoffice/EvenementFront.fxml", "Gestion Événements FrontOffice"));
            btnParticipationFront.setOnAction(e -> openFXML("/fxml/frontoffice/ParticipationFront.fxml", "Gestion Participations FrontOffice"));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void openFXML(String fxmlPath, String title) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource(fxmlPath));
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle(title);
            stage.setMaximized(true); // plein écran
            stage.show();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
