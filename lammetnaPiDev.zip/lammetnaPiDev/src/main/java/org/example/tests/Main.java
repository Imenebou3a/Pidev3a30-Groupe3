package org.example.tests;

import org.example.utils.MyDataBase;

public class Main {
    public static void main(String[] args) {
        MyDataBase myDataBase = new MyDataBase();
    }
}
