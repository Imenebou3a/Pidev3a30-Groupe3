package org.example.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyDataBase {

    private final String URL = "jdbc:mysql://localhost:3306/lammetna_db";
    private final String USER = "root";
    private final String PSW = "";

    private Connection connection;

    private static MyDataBase instance;

    // constructeur privé (Singleton)
    private MyDataBase() {
        try {
            connection = DriverManager.getConnection(URL, USER, PSW);
            System.out.println("Connexion base réussie !");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // méthode pour récupérer instance unique
    public static MyDataBase getInstance() {
        if (instance == null) {
            instance = new MyDataBase();
        }
        return instance;
    }

    // getter connexion
    public Connection getConnection() {
        return connection;
    }
}
