package org.example.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.entities.produit_local;
import org.example.services.ProduitLocalService;

public class ProduitLocalController {

    @FXML private TextField tfIdProduit;
    @FXML private TextField tfNom;
    @FXML private TextArea tfDescription;
    @FXML private TextField tfPrix;
    @FXML private TextField tfCategorie;
    @FXML private TextField tfRegion;
    @FXML private TextField tfStock;
    @FXML private TextField tfImage;

    @FXML private TableView<produit_local> tableProduits;
    @FXML private TableColumn<produit_local, Integer> colId;
    @FXML private TableColumn<produit_local, String> colNom;
    @FXML private TableColumn<produit_local, Double> colPrix;
    @FXML private TableColumn<produit_local, String> colCategorie;
    @FXML private TableColumn<produit_local, String> colRegion;
    @FXML private TableColumn<produit_local, Integer> colStock;

    private ProduitLocalService service = new ProduitLocalService();

    @FXML
    public void initialize() {

        // LINK TABLE WITH ENTITY ATTRIBUTES (MATCH GETTERS)
        colId.setCellValueFactory(new PropertyValueFactory<>("id_produit"));
        colNom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        colPrix.setCellValueFactory(new PropertyValueFactory<>("prix"));
        colCategorie.setCellValueFactory(new PropertyValueFactory<>("categorie"));
        colRegion.setCellValueFactory(new PropertyValueFactory<>("region"));
        colStock.setCellValueFactory(new PropertyValueFactory<>("stock"));

        refreshTable();

        // WHEN CLICK ROW → FILL FIELDS
        tableProduits.getSelectionModel().selectedItemProperty().addListener(
                (obs, oldSelection, selected) -> {
                    if (selected != null) {
                        tfIdProduit.setText(String.valueOf(selected.getId_produit()));
                        tfNom.setText(selected.getNom());
                        tfDescription.setText(selected.getDescription());
                        tfPrix.setText(String.valueOf(selected.getPrix()));
                        tfCategorie.setText(selected.getCategorie());
                        tfRegion.setText(selected.getRegion());
                        tfStock.setText(String.valueOf(selected.getStock()));
                        tfImage.setText(selected.getImage_url());
                    }
                });
    }

    // ================= REFRESH =================
    public void refreshTable() {
        ObservableList<produit_local> list =
                FXCollections.observableArrayList(service.afficher());
        tableProduits.setItems(list);
    }

    // ================= ADD =================
    @FXML
    public void ajouterProduit() {
        try {
            produit_local p = new produit_local(
                    tfNom.getText(),
                    tfDescription.getText(),
                    Double.parseDouble(tfPrix.getText()),
                    tfCategorie.getText(),
                    tfRegion.getText(),
                    Integer.parseInt(tfStock.getText()),
                    tfImage.getText()
            );

            service.ajouter(p);
            refreshTable();
            clearFields();

        } catch (Exception e) {
            showAlert("Erreur ajout", "Vérifie les champs !");
        }
    }

    // ================= UPDATE =================
    @FXML
    public void modifierProduit() {
        try {
            if (tfIdProduit.getText().isEmpty()) {
                showAlert("Erreur", "Sélectionne un produit !");
                return;
            }

            produit_local p = new produit_local(
                    Integer.parseInt(tfIdProduit.getText()),
                    tfNom.getText(),
                    tfDescription.getText(),
                    Double.parseDouble(tfPrix.getText()),
                    tfCategorie.getText(),
                    tfRegion.getText(),
                    Integer.parseInt(tfStock.getText()),
                    tfImage.getText()
            );

            service.modifier(p);
            refreshTable();
            clearFields();

        } catch (Exception e) {
            showAlert("Erreur modification", "Vérifie les champs !");
        }
    }

    // ================= DELETE =================
    @FXML
    public void supprimerProduit() {
        try {
            if (tfIdProduit.getText().isEmpty()) {
                showAlert("Erreur", "Sélectionne un produit !");
                return;
            }

            int id = Integer.parseInt(tfIdProduit.getText());
            service.supprimer(id);
            refreshTable();
            clearFields();

        } catch (Exception e) {
            showAlert("Erreur suppression", "Impossible de supprimer !");
        }
    }

    // ================= CLEAR =================
    private void clearFields() {
        tfIdProduit.clear();
        tfNom.clear();
        tfDescription.clear();
        tfPrix.clear();
        tfCategorie.clear();
        tfRegion.clear();
        tfStock.clear();
        tfImage.clear();
    }

    // ================= ALERT =================
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
