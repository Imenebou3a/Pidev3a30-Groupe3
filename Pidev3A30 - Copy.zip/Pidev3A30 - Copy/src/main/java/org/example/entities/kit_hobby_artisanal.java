package org.example.entities;

public class kit_hobby_artisanal {

    private int id_kit;
    private String nom_kit;
    private String description;
    private String type_artisanat;
    private String niveau_difficulte;
    private double prix;
    private int stock;
    private String image_url;
    private int id_produit;

    public kit_hobby_artisanal() {}

    public kit_hobby_artisanal(int id_kit, String nom_kit, String description,
                               String type_artisanat, String niveau_difficulte,
                               double prix, int stock, String image_url, int id_produit) {
        this.id_kit = id_kit;
        this.nom_kit = nom_kit;
        this.description = description;
        this.type_artisanat = type_artisanat;
        this.niveau_difficulte = niveau_difficulte;
        this.prix = prix;
        this.stock = stock;
        this.image_url = image_url;
        this.id_produit = id_produit;
    }

    public kit_hobby_artisanal(String nom_kit, String description,
                               String type_artisanat, String niveau_difficulte,
                               double prix, int stock, String image_url, int id_produit) {
        this.nom_kit = nom_kit;
        this.description = description;
        this.type_artisanat = type_artisanat;
        this.niveau_difficulte = niveau_difficulte;
        this.prix = prix;
        this.stock = stock;
        this.image_url = image_url;
        this.id_produit = id_produit;
    }

    // Getters / Setters
    public int getId_kit() { return id_kit; }
    public void setId_kit(int id_kit) { this.id_kit = id_kit; }

    public String getNom_kit() { return nom_kit; }
    public void setNom_kit(String nom_kit) { this.nom_kit = nom_kit; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getType_artisanat() { return type_artisanat; }
    public void setType_artisanat(String type_artisanat) { this.type_artisanat = type_artisanat; }

    public String getNiveau_difficulte() { return niveau_difficulte; }
    public void setNiveau_difficulte(String niveau_difficulte) { this.niveau_difficulte = niveau_difficulte; }

    public double getPrix() { return prix; }
    public void setPrix(double prix) { this.prix = prix; }

    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }

    public String getImage_url() { return image_url; }
    public void setImage_url(String image_url) { this.image_url = image_url; }

    public int getId_produit() { return id_produit; }
    public void setId_produit(int id_produit) { this.id_produit = id_produit; }

    @Override
    public String toString() {
        return "kit{" +
                "id=" + id_kit +
                ", nom='" + nom_kit + '\'' +
                ", prix=" + prix +
                ", id_produit=" + id_produit +
                '}';
    }
}
