package org.example.interfaces;

import org.example.entities.kit_hobby_artisanal;
import java.util.List;

public interface IKit {

    void ajouter(kit_hobby_artisanal k);
    void modifier(kit_hobby_artisanal k);
    void supprimer(int id);
    List<kit_hobby_artisanal> afficher();
}
