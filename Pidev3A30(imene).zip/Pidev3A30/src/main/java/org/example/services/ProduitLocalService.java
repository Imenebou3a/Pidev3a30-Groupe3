package org.example.services;

import org.example.entities.produit_local;
import org.example.interfaces.IProduitLocal;
import org.example.utils.MyDataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProduitLocalService implements IProduitLocal {

    Connection cnx = MyDataBase.getInstance().getConnection();

    @Override
    public void ajouter(produit_local p) {
        try {
            String sql = "INSERT INTO produit_local (nom, description, prix, categorie, region, stock, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = cnx.prepareStatement(sql);
            ps.setString(1, p.getNom());
            ps.setString(2, p.getDescription());
            ps.setDouble(3, p.getPrix());
            ps.setString(4, p.getCategorie());
            ps.setString(5, p.getRegion());
            ps.setInt(6, p.getStock());
            ps.setString(7, p.getImage_url());
            ps.executeUpdate();
            System.out.println("Produit ajouté !");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void modifier(produit_local p) {
        try {
            String sql = "UPDATE produit_local SET nom=?, description=?, prix=?, categorie=?, region=?, stock=?, image_url=? WHERE id_produit=?";
            PreparedStatement ps = cnx.prepareStatement(sql);
            ps.setString(1, p.getNom());
            ps.setString(2, p.getDescription());
            ps.setDouble(3, p.getPrix());
            ps.setString(4, p.getCategorie());
            ps.setString(5, p.getRegion());
            ps.setInt(6, p.getStock());
            ps.setString(7, p.getImage_url());
            ps.setInt(8, p.getId_produit());
            ps.executeUpdate();
            System.out.println("Produit modifié !");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void supprimer(int id_produit) {
        try {
            String sql = "DELETE FROM produit_local WHERE id_produit=?";
            PreparedStatement ps = cnx.prepareStatement(sql);
            ps.setInt(1, id_produit);
            ps.executeUpdate();
            System.out.println("Produit supprimé !");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public List<produit_local> afficher() {
        List<produit_local> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM produit_local";
            Statement st = cnx.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                produit_local p = new produit_local(
                        rs.getInt("id_produit"),
                        rs.getString("nom"),
                        rs.getString("description"),
                        rs.getDouble("prix"),
                        rs.getString("categorie"),
                        rs.getString("region"),
                        rs.getInt("stock"),
                        rs.getString("image_url")
                );
                list.add(p);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return list;
    }
}
