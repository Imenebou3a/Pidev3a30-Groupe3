package org.example.entities;

public class produit_local {

    private int id_produit;
    private String nom;
    private String description;
    private double prix;
    private String categorie;
    private String region;
    private int stock;
    private String image_url;

    public produit_local() {}

    public produit_local(int id_produit, String nom, String description, double prix, String categorie, String region, int stock, String image_url) {
        this.id_produit = id_produit;
        this.nom = nom;
        this.description = description;
        this.prix = prix;
        this.categorie = categorie;
        this.region = region;
        this.stock = stock;
        this.image_url = image_url;
    }

    public produit_local(String nom, String description, double prix, String categorie, String region, int stock, String image_url) {
        this.nom = nom;
        this.description = description;
        this.prix = prix;
        this.categorie = categorie;
        this.region = region;
        this.stock = stock;
        this.image_url = image_url;
    }

    // Getters & Setters
    public int getId_produit() { return id_produit; }
    public void setId_produit(int id_produit) { this.id_produit = id_produit; }

    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public double getPrix() { return prix; }
    public void setPrix(double prix) { this.prix = prix; }

    public String getCategorie() { return categorie; }
    public void setCategorie(String categorie) { this.categorie = categorie; }

    public String getRegion() { return region; }
    public void setRegion(String region) { this.region = region; }

    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }

    public String getImage_url() { return image_url; }
    public void setImage_url(String image_url) { this.image_url = image_url; }

    @Override
    public String toString() {
        return "produit_local{" +
                "id_produit=" + id_produit +
                ", nom='" + nom + '\'' +
                ", description='" + description + '\'' +
                ", prix=" + prix +
                ", categorie='" + categorie + '\'' +
                ", region='" + region + '\'' +
                ", stock=" + stock +
                ", image_url='" + image_url + '\'' +
                '}';
    }
}
