package org.example.tests;
import org.example.entities.produit_local;
import org.example.services.ProduitLocalService;

public class TestProduit {
    public static void main(String[] args) {

        ProduitLocalService service = new ProduitLocalService();

        // ✅ AJOUT
        produit_local p1 = new produit_local("Pot Tunisien", "Pot artisanal", 50.0, "Artisanat", "Nabeul", 10, "img1.jpg");
        produit_local p2 = new produit_local("Tapis", "Tapis fait main", 120.0, "Artisanat", "Kairouan", 5, "img2.jpg");
        service.ajouter(p1);
        service.ajouter(p2);

        // ✅ AFFICHAGE
        System.out.println("=== LISTE PRODUITS ===");
        service.afficher().forEach(System.out::println);

        // ✅ MODIFIER (exemple id 1)
        p1.setId_produit(1);
        p1.setPrix(55.0);
        service.modifier(p1);

        // ✅ SUPPRIMER (exemple id 2)
        service.supprimer(2);

        // ✅ AFFICHAGE FINAL
        System.out.println("=== LISTE PRODUITS APRÈS MODIF ET SUPPR ===");
        service.afficher().forEach(System.out::println);
    }
}