package org.example.interfaces;

import org.example.entities.produit_local;
import java.util.List;

public interface IProduitLocal {

    void ajouter(produit_local p);

    void modifier(produit_local p);

    void supprimer(int id_produit);

    List<produit_local> afficher();
}
