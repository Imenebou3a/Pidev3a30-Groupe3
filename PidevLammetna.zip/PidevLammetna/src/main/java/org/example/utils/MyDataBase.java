package org.example.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Classe utilitaire pour gérer la connexion à la base de données MySQL
 */
public class MyDataBase {

    // Configuration de la base de données
    private static final String URL = "jdbc:mysql://localhost:3306/pidev";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    // Instance unique de connexion (Singleton)
    private static Connection connection;

    /**
     * Constructeur privé pour empêcher l'instanciation
     */
    private MyDataBase() {}

    /**
     * Obtenir une connexion à la base de données
     * @return Connection instance de connexion
     */
    public static Connection getConnection() {
        if (connection == null) {
            try {
                // Charger le driver MySQL
                Class.forName("com.mysql.cj.jdbc.Driver");

                // Établir la connexion
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("✅ Connexion à la base de données réussie !");

            } catch (ClassNotFoundException e) {
                System.err.println("❌ Driver MySQL introuvable : " + e.getMessage());
            } catch (SQLException e) {
                System.err.println("❌ Erreur de connexion à la base de données : " + e.getMessage());
            }
        }
        return connection;
    }

    /**
     * Fermer la connexion à la base de données
     */
    public static void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                connection = null;
                System.out.println("✅ Connexion fermée avec succès");
            } catch (SQLException e) {
                System.err.println("❌ Erreur lors de la fermeture : " + e.getMessage());
            }
        }
    }
}