package org.example.tests;

import org.example.entities.ProduitLocal;
import org.example.services.ProduitLocalService;

import java.math.BigDecimal;
import java.util.List;

/**
 * Classe de test pour les produits locaux
 */
public class TestProduit {

    public static void main(String[] args) {
        System.out.println("=== TEST PRODUITS LOCAUX ===\n");

        ProduitLocalService service = new ProduitLocalService();

        // Test 1: Afficher tous les produits
        System.out.println("📦 Liste de tous les produits:");
        List<ProduitLocal> produits = service.afficher();
        produits.forEach(p -> System.out.println("  - " + p.getNom() + " (" + p.getRegion() + ") - " + p.getPrix() + " TND"));
        System.out.println();

        // Test 2: Ajouter un nouveau produit
        System.out.println("➕ Ajout d'un nouveau produit:");
        ProduitLocal nouveauProduit = new ProduitLocal(
                "Chéchia traditionnelle",
                "Bonnet traditionnel tunisien fait main",
                new BigDecimal("35.00"),
                "Artisanat",
                "Tunis",
                15,
                "chechia.jpg"
        );
        service.ajouter(nouveauProduit);
        System.out.println();

        // Test 3: Rechercher par nom
        System.out.println("🔍 Recherche de 'Pot':");
        List<ProduitLocal> resultats = service.rechercherParNom("Pot");
        resultats.forEach(p -> System.out.println("  - " + p.getNom() + " - " + p.getPrix() + " TND"));
        System.out.println();

        // Test 4: Filtrer par catégorie
        System.out.println("🏷️ Filtrage par catégorie 'Artisanat':");
        List<ProduitLocal> artisanat = service.filtrerParCategorie("Artisanat");
        System.out.println("  Nombre de produits artisanaux: " + artisanat.size());
        System.out.println();

        // Test 5: Filtrer par région
        System.out.println("📍 Filtrage par région 'Nabeul':");
        List<ProduitLocal> nabeul = service.filtrerParRegion("Nabeul");
        nabeul.forEach(p -> System.out.println("  - " + p.getNom()));
        System.out.println();

        // Test 6: Produits en stock
        System.out.println("✅ Produits disponibles en stock:");
        List<ProduitLocal> enStock = service.getProduitsEnStock();
        System.out.println("  Nombre de produits en stock: " + enStock.size());
        System.out.println();

        System.out.println("=== FIN DES TESTS ===");
    }
}