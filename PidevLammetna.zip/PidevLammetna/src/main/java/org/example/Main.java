package org.example.utils;

/**
 * Classe principale pour tester la connexion à la base de données
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("╔════════════════════════════════════════╗");
        System.out.println("║     LAMMETNA - SYSTÈME DE GESTION     ║");
        System.out.println("║    Produits Locaux & Kits Hobbies     ║");
        System.out.println("╚════════════════════════════════════════╝");
        System.out.println();

        // Test de connexion à la base de données
        System.out.println("🔌 Test de connexion à la base de données...");
        java.sql.Connection connection = MyDataBase.getConnection();

        if (connection != null) {
            System.out.println("✅ Connexion établie avec succès !");
            System.out.println();
            System.out.println("📊 Informations de la base de données:");

            try {
                java.sql.DatabaseMetaData metaData = connection.getMetaData();
                System.out.println("  • Base de données: " + metaData.getDatabaseProductName());
                System.out.println("  • Version: " + metaData.getDatabaseProductVersion());
                System.out.println("  • Driver: " + metaData.getDriverName());
                System.out.println("  • URL: " + metaData.getURL());

                // Lister les tables
                System.out.println();
                System.out.println("📋 Tables disponibles:");
                java.sql.ResultSet tables = metaData.getTables(null, null, "%", new String[]{"TABLE"});
                while (tables.next()) {
                    String tableName = tables.getString("TABLE_NAME");
                    if (tableName.equals("produit_local") || tableName.equals("kit_hobby_artisanal")) {
                        System.out.println("  ✓ " + tableName);
                    }
                }

            } catch (java.sql.SQLException e) {
                System.err.println("❌ Erreur lors de la récupération des métadonnées: " + e.getMessage());
            }

        } else {
            System.err.println("❌ Échec de la connexion !");
            System.err.println("Vérifiez:");
            System.err.println("  • Que MySQL est démarré (XAMPP/WAMP)");
            System.err.println("  • Que la base 'pidev' existe");
            System.err.println("  • Les identifiants de connexion");
        }

        System.out.println();
        System.out.println("════════════════════════════════════════");
    }
}