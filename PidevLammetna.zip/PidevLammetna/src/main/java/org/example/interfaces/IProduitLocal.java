package org.example.interfaces;

import org.example.entities.ProduitLocal;
import java.util.List;

/**
 * Interface spécifique pour les produits locaux
 */
public interface IProduitLocal extends IKit<ProduitLocal> {

    /**
     * Rechercher des produits par nom
     * @param nom nom du produit
     * @return Liste des produits trouvés
     */
    List<ProduitLocal> rechercherParNom(String nom);

    /**
     * Filtrer les produits par catégorie
     * @param categorie catégorie du produit
     * @return Liste des produits de cette catégorie
     */
    List<ProduitLocal> filtrerParCategorie(String categorie);

    /**
     * Filtrer les produits par région
     * @param region région du produit
     * @return Liste des produits de cette région
     */
    List<ProduitLocal> filtrerParRegion(String region);

    /**
     * Obtenir les produits avec stock disponible
     * @return Liste des produits en stock
     */
    List<ProduitLocal> getProduitsEnStock();
}