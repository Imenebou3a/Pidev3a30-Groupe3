package org.example.controllers.backoffice;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import org.example.entities.ProduitLocal;
import org.example.services.ProduitLocalService;

import java.io.File;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public class ProduitBackController {

    // TABLEAU
    @FXML private TableView<ProduitLocal> tableView;
    @FXML private TableColumn<ProduitLocal, Integer> colId;
    @FXML private TableColumn<ProduitLocal, String> colNom;
    @FXML private TableColumn<ProduitLocal, String> colCategorie;
    @FXML private TableColumn<ProduitLocal, String> colRegion;
    @FXML private TableColumn<ProduitLocal, BigDecimal> colPrix;
    @FXML private TableColumn<ProduitLocal, Integer> colStock;

    // FORMULAIRE
    @FXML private TextField txtNom;
    @FXML private TextArea txtDescription;
    @FXML private TextField txtPrix;
    @FXML private ComboBox<String> comboCategorie;
    @FXML private ComboBox<String> comboRegion;
    @FXML private TextField txtStock;
    @FXML private TextField txtImageUrl;
    @FXML private ImageView imagePreview;

    // RECHERCHE & FILTRES
    @FXML private TextField searchField;
    @FXML private ComboBox<String> filterCategorie;
    @FXML private ComboBox<String> filterRegion;

    // BOUTONS
    @FXML private Button btnAjouter;
    @FXML private Button btnModifier;
    @FXML private Button btnSupprimer;
    @FXML private Button btnNouveau;
    @FXML private Button btnChoisirImage;

    // STATS
    @FXML private Label lblTotalProduits;
    @FXML private Label lblProduitsEnStock;
    @FXML private Label lblProduitsRupture;

    // SERVICE
    private ProduitLocalService produitService;
    private ObservableList<ProduitLocal> produitsObservableList;
    private ProduitLocal produitSelectionne;

    @FXML
    public void initialize() {
        try {
            produitService = new ProduitLocalService();
            configurerTableView();
            initialiserComboBox();
            chargerProduits();
            configurerListeners();
            mettreAJourStatistiques();
            btnModifier.setDisable(true);
            btnSupprimer.setDisable(true);
        } catch (Exception e) {
            System.err.println("Erreur initialize: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void configurerTableView() {
        colId.setCellValueFactory(new PropertyValueFactory<>("idProduit"));
        colNom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        colCategorie.setCellValueFactory(new PropertyValueFactory<>("categorie"));
        colRegion.setCellValueFactory(new PropertyValueFactory<>("region"));
        colPrix.setCellValueFactory(new PropertyValueFactory<>("prix"));
        colStock.setCellValueFactory(new PropertyValueFactory<>("stock"));

        colStock.setCellFactory(column -> new TableCell<ProduitLocal, Integer>() {
            @Override
            protected void updateItem(Integer stock, boolean empty) {
                super.updateItem(stock, empty);
                if (empty || stock == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(stock.toString());
                    if (stock == 0) {
                        setStyle("-fx-text-fill: #ef4444; -fx-font-weight: bold;");
                    } else if (stock < 5) {
                        setStyle("-fx-text-fill: #f59e0b; -fx-font-weight: bold;");
                    } else {
                        setStyle("-fx-text-fill: #10b981; -fx-font-weight: bold;");
                    }
                }
            }
        });
    }

    private void initialiserComboBox() {
        ObservableList<String> categories = FXCollections.observableArrayList(
                "Artisanat", "Gastronomie", "Textile", "Decoration", "Bijoux", "Cosmetiques"
        );
        comboCategorie.setItems(categories);
        filterCategorie.setItems(FXCollections.observableArrayList(
                "Toutes", "Artisanat", "Gastronomie", "Textile", "Decoration", "Bijoux", "Cosmetiques"
        ));
        filterCategorie.setValue("Toutes");

        ObservableList<String> regions = FXCollections.observableArrayList(
                "Tunis", "Ariana", "Ben Arous", "Manouba", "Nabeul", "Zaghouan",
                "Bizerte", "Beja", "Jendouba", "Kef", "Siliana", "Kairouan",
                "Kasserine", "Sidi Bouzid", "Sousse", "Monastir", "Mahdia",
                "Sfax", "Gabes", "Medenine", "Tataouine", "Gafsa", "Tozeur", "Kebili"
        );
        comboRegion.setItems(regions);
        filterRegion.setItems(FXCollections.observableArrayList("Toutes"));
        filterRegion.getItems().addAll(regions);
        filterRegion.setValue("Toutes");
    }

    private void configurerListeners() {
        tableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                produitSelectionne = newSel;
                remplirFormulaire(newSel);
                btnModifier.setDisable(false);
                btnSupprimer.setDisable(false);
            }
        });

        searchField.textProperty().addListener((obs, oldVal, newVal) -> rechercherProduit());
        filterCategorie.setOnAction(e -> appliquerFiltres());
        filterRegion.setOnAction(e -> appliquerFiltres());
    }

    private void chargerProduits() {
        List<ProduitLocal> produits = produitService.afficher();
        produitsObservableList = FXCollections.observableArrayList(produits);
        tableView.setItems(produitsObservableList);
    }

    private void remplirFormulaire(ProduitLocal produit) {
        txtNom.setText(produit.getNom() != null ? produit.getNom() : "");
        txtDescription.setText(produit.getDescription() != null ? produit.getDescription() : "");
        txtPrix.setText(produit.getPrix() != null ? produit.getPrix().toString() : "");
        comboCategorie.setValue(produit.getCategorie());
        comboRegion.setValue(produit.getRegion());
        txtStock.setText(String.valueOf(produit.getStock()));
        txtImageUrl.setText(produit.getImageUrl() != null ? produit.getImageUrl() : "");
        chargerImagePreview(produit.getImageUrl());
    }

    private void chargerImagePreview(String imageUrl) {
        if (imageUrl != null && !imageUrl.isEmpty()) {
            try {
                File file = new File("src/main/resources/images/" + imageUrl);
                if (file.exists()) {
                    imagePreview.setImage(new Image(file.toURI().toString()));
                }
            } catch (Exception e) {
                System.err.println("Erreur image: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleAjouter() {
        if (!validerFormulaire()) return;
        try {
            ProduitLocal produit = new ProduitLocal(
                    txtNom.getText().trim(),
                    txtDescription.getText().trim(),
                    new BigDecimal(txtPrix.getText().trim()),
                    comboCategorie.getValue(),
                    comboRegion.getValue(),
                    Integer.parseInt(txtStock.getText().trim()),
                    txtImageUrl.getText().trim()
            );
            produitService.ajouter(produit);
            afficherAlerte(Alert.AlertType.INFORMATION, "Succes", "Produit ajoute avec succes !");
            chargerProduits();
            viderFormulaire();
            mettreAJourStatistiques();
        } catch (Exception e) {
            afficherAlerte(Alert.AlertType.ERROR, "Erreur", "Erreur lors de l'ajout: " + e.getMessage());
        }
    }

    @FXML
    private void handleModifier() {
        if (produitSelectionne == null) {
            afficherAlerte(Alert.AlertType.WARNING, "Attention", "Selectionnez un produit a modifier.");
            return;
        }
        if (!validerFormulaire()) return;
        try {
            produitSelectionne.setNom(txtNom.getText().trim());
            produitSelectionne.setDescription(txtDescription.getText().trim());
            produitSelectionne.setPrix(new BigDecimal(txtPrix.getText().trim()));
            produitSelectionne.setCategorie(comboCategorie.getValue());
            produitSelectionne.setRegion(comboRegion.getValue());
            produitSelectionne.setStock(Integer.parseInt(txtStock.getText().trim()));
            produitSelectionne.setImageUrl(txtImageUrl.getText().trim());
            produitService.modifier(produitSelectionne);
            afficherAlerte(Alert.AlertType.INFORMATION, "Succes", "Produit modifie avec succes !");
            chargerProduits();
            viderFormulaire();
            mettreAJourStatistiques();
        } catch (Exception e) {
            afficherAlerte(Alert.AlertType.ERROR, "Erreur", "Erreur lors de la modification: " + e.getMessage());
        }
    }

    @FXML
    private void handleSupprimer() {
        if (produitSelectionne == null) {
            afficherAlerte(Alert.AlertType.WARNING, "Attention", "Selectionnez un produit a supprimer.");
            return;
        }
        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Confirmation");
        confirmation.setHeaderText("Supprimer le produit");
        confirmation.setContentText("Confirmer la suppression de \"" + produitSelectionne.getNom() + "\" ?");
        Optional<ButtonType> result = confirmation.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            produitService.supprimer(produitSelectionne.getIdProduit());
            afficherAlerte(Alert.AlertType.INFORMATION, "Succes", "Produit supprime avec succes !");
            chargerProduits();
            viderFormulaire();
            mettreAJourStatistiques();
        }
    }

    @FXML
    private void handleNouveau() {
        viderFormulaire();
    }

    @FXML
    private void handleChoisirImage() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Choisir une image");
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Images", "*.png", "*.jpg", "*.jpeg", "*.gif")
        );
        File file = fileChooser.showOpenDialog(btnChoisirImage.getScene().getWindow());
        if (file != null) {
            txtImageUrl.setText(file.getName());
            imagePreview.setImage(new Image(file.toURI().toString()));
        }
    }

    private void rechercherProduit() {
        String recherche = searchField.getText().trim();
        if (recherche.isEmpty()) {
            chargerProduits();
        } else {
            List<ProduitLocal> resultats = produitService.rechercherParNom(recherche);
            tableView.setItems(FXCollections.observableArrayList(resultats));
        }
    }

    private void appliquerFiltres() {
        List<ProduitLocal> produits = produitService.afficher();
        String categorie = filterCategorie.getValue();
        if (categorie != null && !categorie.equals("Toutes")) {
            produits = produits.stream().filter(p -> categorie.equals(p.getCategorie())).toList();
        }
        String region = filterRegion.getValue();
        if (region != null && !region.equals("Toutes")) {
            produits = produits.stream().filter(p -> region.equals(p.getRegion())).toList();
        }
        tableView.setItems(FXCollections.observableArrayList(produits));
    }

    private void mettreAJourStatistiques() {
        try {
            List<ProduitLocal> produits = produitService.afficher();
            long enStock = produits.stream().filter(p -> p.getStock() > 0).count();
            long rupture = produits.stream().filter(p -> p.getStock() == 0).count();
            if (lblTotalProduits != null) lblTotalProduits.setText(String.valueOf(produits.size()));
            if (lblProduitsEnStock != null) lblProduitsEnStock.setText(String.valueOf(enStock));
            if (lblProduitsRupture != null) lblProduitsRupture.setText(String.valueOf(rupture));
        } catch (Exception e) {
            System.err.println("Erreur stats: " + e.getMessage());
        }
    }

    private void viderFormulaire() {
        txtNom.clear();
        txtDescription.clear();
        txtPrix.clear();
        comboCategorie.setValue(null);
        comboRegion.setValue(null);
        txtStock.clear();
        txtImageUrl.clear();
        imagePreview.setImage(null);
        produitSelectionne = null;
        tableView.getSelectionModel().clearSelection();
        btnModifier.setDisable(true);
        btnSupprimer.setDisable(true);
    }

    private boolean validerFormulaire() {
        StringBuilder erreurs = new StringBuilder();
        if (txtNom.getText().trim().isEmpty()) erreurs.append("- Le nom est obligatoire\n");
        if (txtPrix.getText().trim().isEmpty()) {
            erreurs.append("- Le prix est obligatoire\n");
        } else {
            try {
                BigDecimal prix = new BigDecimal(txtPrix.getText().trim());
                if (prix.compareTo(BigDecimal.ZERO) <= 0) erreurs.append("- Le prix doit etre > 0\n");
            } catch (NumberFormatException e) {
                erreurs.append("- Le prix doit etre un nombre valide\n");
            }
        }
        if (comboCategorie.getValue() == null) erreurs.append("- La categorie est obligatoire\n");
        if (comboRegion.getValue() == null) erreurs.append("- La region est obligatoire\n");
        if (txtStock.getText().trim().isEmpty()) {
            erreurs.append("- Le stock est obligatoire\n");
        } else {
            try {
                if (Integer.parseInt(txtStock.getText().trim()) < 0)
                    erreurs.append("- Le stock ne peut pas etre negatif\n");
            } catch (NumberFormatException e) {
                erreurs.append("- Le stock doit etre un entier\n");
            }
        }
        if (erreurs.length() > 0) {
            afficherAlerte(Alert.AlertType.ERROR, "Erreurs de validation", erreurs.toString());
            return false;
        }
        return true;
    }

    private void afficherAlerte(Alert.AlertType type, String titre, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(titre);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}