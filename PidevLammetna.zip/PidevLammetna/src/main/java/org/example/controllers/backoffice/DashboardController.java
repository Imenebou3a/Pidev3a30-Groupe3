package org.example.controllers.backoffice;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.entities.KitHobbies;
import org.example.entities.ProduitLocal;
import org.example.services.KitHobbiesService;
import org.example.services.ProduitLocalService;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class DashboardController {

    // KPI
    @FXML private Label kpiTotalProduits;
    @FXML private Label kpiTotalKits;
    @FXML private Label kpiEnStock;
    @FXML private Label kpiRupture;
    @FXML private Label kpiProduitsSub;
    @FXML private Label kpiKitsSub;

    // Charts
    @FXML private PieChart pieCategories;
    @FXML private BarChart<String, Number> barKitsType;
    @FXML private BarChart<String, Number> barRegions;
    @FXML private PieChart pieNiveaux;

    // Tableau recents
    @FXML private TableView<ProduitLocal> tableRecents;
    @FXML private TableColumn<ProduitLocal, Integer> colRecentId;
    @FXML private TableColumn<ProduitLocal, String> colRecentNom;
    @FXML private TableColumn<ProduitLocal, String> colRecentCategorie;
    @FXML private TableColumn<ProduitLocal, String> colRecentRegion;
    @FXML private TableColumn<ProduitLocal, BigDecimal> colRecentPrix;
    @FXML private TableColumn<ProduitLocal, Integer> colRecentStock;

    private ProduitLocalService produitService;
    private KitHobbiesService kitService;

    @FXML
    public void initialize() {
        try {
            produitService = new ProduitLocalService();
            kitService = new KitHobbiesService();

            List<ProduitLocal> produits = produitService.afficher();
            List<KitHobbies> kits = kitService.afficher();

            chargerKPIs(produits, kits);
            chargerPieProduits(produits);
            chargerBarKits(kits);
            chargerBarRegions(produits);
            chargerPieNiveaux(kits);
            chargerTableauRecents(produits);
        } catch (Exception e) {
            System.err.println("Erreur Dashboard: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void chargerKPIs(List<ProduitLocal> produits, List<KitHobbies> kits) {
        long enStock = produits.stream().filter(p -> p.getStock() > 0).count();
        long rupture = produits.stream().filter(p -> p.getStock() == 0).count();
        long kitsEnStock = kits.stream().filter(k -> k.getStock() > 0).count();

        kpiTotalProduits.setText(String.valueOf(produits.size()));
        kpiTotalKits.setText(String.valueOf(kits.size()));
        kpiEnStock.setText(String.valueOf(enStock));
        kpiRupture.setText(String.valueOf(rupture));
        kpiProduitsSub.setText(produits.size() + " references actives");
        kpiKitsSub.setText(kitsEnStock + " kits en stock");
    }

    private void chargerPieProduits(List<ProduitLocal> produits) {
        Map<String, Long> parCategorie = produits.stream()
                .filter(p -> p.getCategorie() != null)
                .collect(Collectors.groupingBy(ProduitLocal::getCategorie, Collectors.counting()));

        pieCategories.setData(FXCollections.observableArrayList(
                parCategorie.entrySet().stream()
                        .map(e -> new PieChart.Data(e.getKey() + " (" + e.getValue() + ")", e.getValue()))
                        .collect(Collectors.toList())
        ));
        pieCategories.setStyle("-fx-font-size: 11px;");
    }

    private void chargerBarKits(List<KitHobbies> kits) {
        Map<String, Long> parType = kits.stream()
                .filter(k -> k.getTypeArtisanat() != null)
                .collect(Collectors.groupingBy(KitHobbies::getTypeArtisanat, Collectors.counting()));

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Kits");
        parType.forEach((type, count) -> series.getData().add(new XYChart.Data<>(type, count)));

        barKitsType.getData().clear();
        barKitsType.getData().add(series);
        barKitsType.setStyle("-fx-font-size: 11px;");
    }

    private void chargerBarRegions(List<ProduitLocal> produits) {
        Map<String, Integer> stockParRegion = produits.stream()
                .filter(p -> p.getRegion() != null)
                .collect(Collectors.groupingBy(
                        ProduitLocal::getRegion,
                        Collectors.summingInt(ProduitLocal::getStock)
                ));

        // Top 8 régions par stock
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Stock");
        stockParRegion.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .limit(8)
                .forEach(e -> series.getData().add(new XYChart.Data<>(e.getKey(), e.getValue())));

        barRegions.getData().clear();
        barRegions.getData().add(series);
    }

    private void chargerPieNiveaux(List<KitHobbies> kits) {
        Map<String, Long> parNiveau = kits.stream()
                .filter(k -> k.getNiveauDifficulte() != null)
                .collect(Collectors.groupingBy(KitHobbies::getNiveauDifficulte, Collectors.counting()));

        pieNiveaux.setData(FXCollections.observableArrayList(
                parNiveau.entrySet().stream()
                        .map(e -> new PieChart.Data(e.getKey() + " (" + e.getValue() + ")", e.getValue()))
                        .collect(Collectors.toList())
        ));
    }

    private void chargerTableauRecents(List<ProduitLocal> produits) {
        colRecentId.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("idProduit"));
        colRecentNom.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("nom"));
        colRecentCategorie.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("categorie"));
        colRecentRegion.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("region"));
        colRecentPrix.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("prix"));
        colRecentStock.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("stock"));

        // Les 10 premiers (déjà triés par ID DESC dans le service)
        List<ProduitLocal> recents = produits.stream().limit(10).collect(Collectors.toList());
        tableRecents.setItems(FXCollections.observableArrayList(recents));
    }
}