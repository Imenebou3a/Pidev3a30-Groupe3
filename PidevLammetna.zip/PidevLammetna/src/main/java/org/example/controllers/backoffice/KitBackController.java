package org.example.controllers.backoffice;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import org.example.entities.KitHobbies;
import org.example.entities.ProduitLocal;
import org.example.services.KitHobbiesService;
import org.example.services.ProduitLocalService;

import java.io.File;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public class KitBackController {

    // TABLEAU
    @FXML private TableView<KitHobbies> tableView;
    @FXML private TableColumn<KitHobbies, Integer> colId;
    @FXML private TableColumn<KitHobbies, String> colNomKit;
    @FXML private TableColumn<KitHobbies, String> colType;
    @FXML private TableColumn<KitHobbies, String> colNiveau;
    @FXML private TableColumn<KitHobbies, BigDecimal> colPrix;
    @FXML private TableColumn<KitHobbies, Integer> colStock;

    // FORMULAIRE
    @FXML private TextField txtNomKit;
    @FXML private TextArea txtDescription;
    @FXML private TextField txtPrix;
    @FXML private ComboBox<String> comboType;
    @FXML private ComboBox<String> comboNiveau;
    @FXML private TextField txtStock;
    @FXML private ComboBox<ProduitLocal> comboProduit; // ← ComboBox au lieu de TextField
    @FXML private TextField txtImageUrl;
    @FXML private ImageView imagePreview;

    // RECHERCHE & FILTRES
    @FXML private TextField searchField;
    @FXML private ComboBox<String> filterType;
    @FXML private ComboBox<String> filterNiveau;

    // BOUTONS
    @FXML private Button btnAjouter;
    @FXML private Button btnModifier;
    @FXML private Button btnSupprimer;
    @FXML private Button btnNouveau;
    @FXML private Button btnChoisirImage;

    // STATS
    @FXML private Label lblTotalKits;
    @FXML private Label lblKitsEnStock;
    @FXML private Label lblKitsRupture;

    // SERVICES
    private KitHobbiesService kitService;
    private ProduitLocalService produitService;
    private ObservableList<KitHobbies> kitsObservableList;
    private KitHobbies kitSelectionne;

    @FXML
    public void initialize() {
        try {
            kitService = new KitHobbiesService();
            produitService = new ProduitLocalService();
            configurerTableView();
            initialiserComboBox();
            chargerKits();
            configurerListeners();
            mettreAJourStatistiques();
            btnModifier.setDisable(true);
            btnSupprimer.setDisable(true);
        } catch (Exception e) {
            System.err.println("Erreur initialize KitBackController: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void configurerTableView() {
        colId.setCellValueFactory(new PropertyValueFactory<>("idKit"));
        colNomKit.setCellValueFactory(new PropertyValueFactory<>("nomKit"));
        colType.setCellValueFactory(new PropertyValueFactory<>("typeArtisanat"));
        colNiveau.setCellValueFactory(new PropertyValueFactory<>("niveauDifficulte"));
        colPrix.setCellValueFactory(new PropertyValueFactory<>("prix"));
        colStock.setCellValueFactory(new PropertyValueFactory<>("stock"));

        colStock.setCellFactory(column -> new TableCell<KitHobbies, Integer>() {
            @Override
            protected void updateItem(Integer stock, boolean empty) {
                super.updateItem(stock, empty);
                if (empty || stock == null) { setText(null); setStyle(""); }
                else {
                    setText(stock.toString());
                    if (stock == 0) setStyle("-fx-text-fill: #ef4444; -fx-font-weight: bold;");
                    else if (stock < 5) setStyle("-fx-text-fill: #f59e0b; -fx-font-weight: bold;");
                    else setStyle("-fx-text-fill: #10b981; -fx-font-weight: bold;");
                }
            }
        });

        colNiveau.setCellFactory(column -> new TableCell<KitHobbies, String>() {
            @Override
            protected void updateItem(String niveau, boolean empty) {
                super.updateItem(niveau, empty);
                if (empty || niveau == null) { setText(null); setStyle(""); }
                else {
                    setText(niveau);
                    switch (niveau) {
                        case "Facile" -> setStyle("-fx-text-fill: #10b981; -fx-font-weight: bold;");
                        case "Intermediaire" -> setStyle("-fx-text-fill: #f59e0b; -fx-font-weight: bold;");
                        case "Difficile" -> setStyle("-fx-text-fill: #ef4444; -fx-font-weight: bold;");
                        default -> setStyle("");
                    }
                }
            }
        });
    }

    private void initialiserComboBox() {
        // Types artisanat
        comboType.setItems(FXCollections.observableArrayList(
                "Poterie", "Tissage", "Broderie", "Calligraphie",
                "Sculpture", "Peinture", "Bijouterie", "Vannerie"
        ));

        // Niveaux
        comboNiveau.setItems(FXCollections.observableArrayList(
                "Facile", "Intermediaire", "Difficile"
        ));

        // Filtres
        filterType.setItems(FXCollections.observableArrayList(
                "Tous", "Poterie", "Tissage", "Broderie", "Calligraphie",
                "Sculpture", "Peinture", "Bijouterie", "Vannerie"
        ));
        filterType.setValue("Tous");

        filterNiveau.setItems(FXCollections.observableArrayList(
                "Tous", "Facile", "Intermediaire", "Difficile"
        ));
        filterNiveau.setValue("Tous");

        // ComboBox Produits - affiche "ID - Nom"
        chargerProduitsDansCombo();
    }

    private void chargerProduitsDansCombo() {
        List<ProduitLocal> produits = produitService.afficher();
        comboProduit.setItems(FXCollections.observableArrayList(produits));

        // Afficher "ID - Nom du produit" dans la ComboBox
        comboProduit.setCellFactory(lv -> new ListCell<ProduitLocal>() {
            @Override
            protected void updateItem(ProduitLocal p, boolean empty) {
                super.updateItem(p, empty);
                setText(empty || p == null ? null : "#" + p.getIdProduit() + " - " + p.getNom());
            }
        });
        comboProduit.setButtonCell(new ListCell<ProduitLocal>() {
            @Override
            protected void updateItem(ProduitLocal p, boolean empty) {
                super.updateItem(p, empty);
                setText(empty || p == null ? "Selectionnez un produit" : "#" + p.getIdProduit() + " - " + p.getNom());
            }
        });
    }

    private void configurerListeners() {
        tableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                kitSelectionne = newSel;
                remplirFormulaire(newSel);
                btnModifier.setDisable(false);
                btnSupprimer.setDisable(false);
            }
        });
        searchField.textProperty().addListener((obs, oldVal, newVal) -> rechercherKit());
        filterType.setOnAction(e -> appliquerFiltres());
        filterNiveau.setOnAction(e -> appliquerFiltres());
    }

    private void chargerKits() {
        kitsObservableList = FXCollections.observableArrayList(kitService.afficher());
        tableView.setItems(kitsObservableList);
    }

    private void remplirFormulaire(KitHobbies kit) {
        txtNomKit.setText(kit.getNomKit() != null ? kit.getNomKit() : "");
        txtDescription.setText(kit.getDescription() != null ? kit.getDescription() : "");
        txtPrix.setText(kit.getPrix() != null ? kit.getPrix().toString() : "");
        comboType.setValue(kit.getTypeArtisanat());
        comboNiveau.setValue(kit.getNiveauDifficulte());
        txtStock.setText(String.valueOf(kit.getStock()));
        txtImageUrl.setText(kit.getImageUrl() != null ? kit.getImageUrl() : "");

        // Sélectionner le bon produit dans la ComboBox
        comboProduit.getItems().stream()
                .filter(p -> p.getIdProduit() == kit.getIdProduit())
                .findFirst()
                .ifPresent(p -> comboProduit.setValue(p));

        chargerImagePreview(kit.getImageUrl());
    }

    private void chargerImagePreview(String imageUrl) {
        if (imageUrl != null && !imageUrl.isEmpty()) {
            try {
                File file = new File("src/main/resources/images/" + imageUrl);
                if (file.exists()) imagePreview.setImage(new Image(file.toURI().toString()));
            } catch (Exception e) {
                System.err.println("Erreur image: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleAjouter() {
        if (!validerFormulaire()) return;
        try {
            KitHobbies kit = new KitHobbies(
                    txtNomKit.getText().trim(),
                    txtDescription.getText().trim(),
                    comboType.getValue(),
                    comboNiveau.getValue(),
                    new BigDecimal(txtPrix.getText().trim()),
                    Integer.parseInt(txtStock.getText().trim()),
                    txtImageUrl.getText().trim(),
                    comboProduit.getValue().getIdProduit()
            );
            kitService.ajouter(kit);
            afficherAlerte(Alert.AlertType.INFORMATION, "Succes", "Kit ajoute avec succes !");
            chargerKits();
            viderFormulaire();
            mettreAJourStatistiques();
        } catch (Exception e) {
            afficherAlerte(Alert.AlertType.ERROR, "Erreur", "Erreur: " + e.getMessage());
        }
    }

    @FXML
    private void handleModifier() {
        if (kitSelectionne == null) {
            afficherAlerte(Alert.AlertType.WARNING, "Attention", "Selectionnez un kit.");
            return;
        }
        if (!validerFormulaire()) return;
        try {
            kitSelectionne.setNomKit(txtNomKit.getText().trim());
            kitSelectionne.setDescription(txtDescription.getText().trim());
            kitSelectionne.setTypeArtisanat(comboType.getValue());
            kitSelectionne.setNiveauDifficulte(comboNiveau.getValue());
            kitSelectionne.setPrix(new BigDecimal(txtPrix.getText().trim()));
            kitSelectionne.setStock(Integer.parseInt(txtStock.getText().trim()));
            kitSelectionne.setImageUrl(txtImageUrl.getText().trim());
            kitSelectionne.setIdProduit(comboProduit.getValue().getIdProduit());
            kitService.modifier(kitSelectionne);
            afficherAlerte(Alert.AlertType.INFORMATION, "Succes", "Kit modifie avec succes !");
            chargerKits();
            viderFormulaire();
            mettreAJourStatistiques();
        } catch (Exception e) {
            afficherAlerte(Alert.AlertType.ERROR, "Erreur", "Erreur: " + e.getMessage());
        }
    }

    @FXML
    private void handleSupprimer() {
        if (kitSelectionne == null) {
            afficherAlerte(Alert.AlertType.WARNING, "Attention", "Selectionnez un kit.");
            return;
        }
        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Confirmation");
        confirmation.setHeaderText("Supprimer le kit");
        confirmation.setContentText("Supprimer \"" + kitSelectionne.getNomKit() + "\" ?");
        Optional<ButtonType> result = confirmation.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            kitService.supprimer(kitSelectionne.getIdKit());
            afficherAlerte(Alert.AlertType.INFORMATION, "Succes", "Kit supprime !");
            chargerKits();
            viderFormulaire();
            mettreAJourStatistiques();
        }
    }

    @FXML private void handleNouveau() { viderFormulaire(); }

    @FXML
    private void handleChoisirImage() {
        FileChooser fc = new FileChooser();
        fc.setTitle("Choisir une image");
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Images", "*.png", "*.jpg", "*.jpeg", "*.gif"));
        File file = fc.showOpenDialog(btnChoisirImage.getScene().getWindow());
        if (file != null) {
            txtImageUrl.setText(file.getName());
            imagePreview.setImage(new Image(file.toURI().toString()));
        }
    }

    private void rechercherKit() {
        String recherche = searchField.getText().trim();
        if (recherche.isEmpty()) chargerKits();
        else tableView.setItems(FXCollections.observableArrayList(kitService.rechercherParNom(recherche)));
    }

    private void appliquerFiltres() {
        List<KitHobbies> kits = kitService.afficher();
        String type = filterType.getValue();
        if (type != null && !type.equals("Tous"))
            kits = kits.stream().filter(k -> type.equals(k.getTypeArtisanat())).toList();
        String niveau = filterNiveau.getValue();
        if (niveau != null && !niveau.equals("Tous"))
            kits = kits.stream().filter(k -> niveau.equals(k.getNiveauDifficulte())).toList();
        tableView.setItems(FXCollections.observableArrayList(kits));
    }

    private void mettreAJourStatistiques() {
        try {
            List<KitHobbies> kits = kitService.afficher();
            long enStock = kits.stream().filter(k -> k.getStock() > 0).count();
            long rupture = kits.stream().filter(k -> k.getStock() == 0).count();
            if (lblTotalKits != null) lblTotalKits.setText(String.valueOf(kits.size()));
            if (lblKitsEnStock != null) lblKitsEnStock.setText(String.valueOf(enStock));
            if (lblKitsRupture != null) lblKitsRupture.setText(String.valueOf(rupture));
        } catch (Exception e) {
            System.err.println("Erreur stats: " + e.getMessage());
        }
    }

    private void viderFormulaire() {
        txtNomKit.clear();
        txtDescription.clear();
        txtPrix.clear();
        comboType.setValue(null);
        comboNiveau.setValue(null);
        txtStock.clear();
        comboProduit.setValue(null);
        txtImageUrl.clear();
        imagePreview.setImage(null);
        kitSelectionne = null;
        tableView.getSelectionModel().clearSelection();
        btnModifier.setDisable(true);
        btnSupprimer.setDisable(true);
    }

    private boolean validerFormulaire() {
        StringBuilder erreurs = new StringBuilder();
        if (txtNomKit.getText().trim().isEmpty()) erreurs.append("- Nom du kit obligatoire\n");
        if (txtPrix.getText().trim().isEmpty()) {
            erreurs.append("- Prix obligatoire\n");
        } else {
            try {
                if (new BigDecimal(txtPrix.getText().trim()).compareTo(BigDecimal.ZERO) <= 0)
                    erreurs.append("- Prix doit etre > 0\n");
            } catch (NumberFormatException e) { erreurs.append("- Prix invalide\n"); }
        }
        if (comboType.getValue() == null) erreurs.append("- Type d'artisanat obligatoire\n");
        if (comboNiveau.getValue() == null) erreurs.append("- Niveau de difficulte obligatoire\n");
        if (txtStock.getText().trim().isEmpty()) {
            erreurs.append("- Stock obligatoire\n");
        } else {
            try {
                if (Integer.parseInt(txtStock.getText().trim()) < 0)
                    erreurs.append("- Stock ne peut pas etre negatif\n");
            } catch (NumberFormatException e) { erreurs.append("- Stock invalide\n"); }
        }
        if (comboProduit.getValue() == null) erreurs.append("- Produit associe obligatoire\n");

        if (erreurs.length() > 0) {
            afficherAlerte(Alert.AlertType.ERROR, "Erreurs de validation", erreurs.toString());
            return false;
        }
        return true;
    }

    private void afficherAlerte(Alert.AlertType type, String titre, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(titre);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}