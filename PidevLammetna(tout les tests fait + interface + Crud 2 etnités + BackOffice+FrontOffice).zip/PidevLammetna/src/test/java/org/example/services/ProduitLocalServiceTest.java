package org.example.services;

import org.example.entities.ProduitLocal;
import org.junit.jupiter.api.*;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class ProduitLocalServiceTest {

    private static ProduitLocalService service;
    private static int idProduitTest;

    @BeforeAll
    static void setUp() {
        service = new ProduitLocalService();
        System.out.println("=== Debut des tests ProduitLocal ===");
    }

    @AfterAll
    static void tearDown() {
        // Nettoyage UNIQUE à la fin de TOUS les tests
        List<ProduitLocal> produits = service.afficher();
        for (ProduitLocal p : produits) {
            if (p.getNom() != null &&
                    (p.getNom().contains("Test") || p.getNom().contains("Modifie"))) {
                service.supprimer(p.getIdProduit());
                System.out.println("  Nettoye: " + p.getNom());
            }
        }
        System.out.println("=== Fin des tests ProduitLocal ===");
    }

    // ========== TEST 1: AJOUTER ==========
    @Test
    @Order(1)
    @DisplayName("Test 1: Ajouter un produit")
    void testAjouterProduit() {
        System.out.println("\n[TEST 1] Ajout d'un produit...");

        ProduitLocal produit = new ProduitLocal(
                "ProduitTest",
                "Description de test",
                new BigDecimal("99.99"),
                "Artisanat",
                "Tunis",
                10,
                "test_image.jpg"
        );

        service.ajouter(produit);

        List<ProduitLocal> produits = service.afficher();
        assertFalse(produits.isEmpty(), "La liste ne devrait pas etre vide apres ajout");

        ProduitLocal produitAjoute = produits.stream()
                .filter(p -> "ProduitTest".equals(p.getNom()))
                .findFirst()
                .orElse(null);

        assertNotNull(produitAjoute, "Le produit ajoute devrait exister");
        idProduitTest = produitAjoute.getIdProduit();

        System.out.println("Produit ajoute avec ID: " + idProduitTest);
    }

    // ========== TEST 2: AFFICHER ==========
    @Test
    @Order(2)
    @DisplayName("Test 2: Afficher tous les produits")
    void testAfficherProduits() {
        System.out.println("\n[TEST 2] Affichage de tous les produits...");

        List<ProduitLocal> produits = service.afficher();
        assertNotNull(produits, "La liste ne devrait pas etre null");
        assertFalse(produits.isEmpty(), "La liste devrait contenir des produits");

        System.out.println("Nombre de produits: " + produits.size());
    }

    // ========== TEST 3: GET BY ID ==========
    @Test
    @Order(3)
    @DisplayName("Test 3: Recuperer un produit par ID")
    void testGetById() {
        System.out.println("\n[TEST 3] Recuperation par ID: " + idProduitTest);

        if (idProduitTest == 0) {
            service.afficher().stream()
                    .filter(p -> "ProduitTest".equals(p.getNom()))
                    .findFirst()
                    .ifPresent(p -> idProduitTest = p.getIdProduit());
        }

        ProduitLocal produit = service.getById(idProduitTest);
        assertNotNull(produit, "Le produit devrait exister");
        assertEquals("ProduitTest", produit.getNom(), "Le nom devrait correspondre");
        assertEquals("Artisanat", produit.getCategorie(), "La categorie devrait correspondre");
        assertEquals(0, new BigDecimal("99.99").compareTo(produit.getPrix()), "Le prix devrait correspondre");

        System.out.println("Produit recupere: " + produit.getNom());
    }

    // ========== TEST 4: MODIFIER ==========
    @Test
    @Order(4)
    @DisplayName("Test 4: Modifier un produit")
    void testModifierProduit() {
        System.out.println("\n[TEST 4] Modification du produit...");

        if (idProduitTest == 0) {
            service.afficher().stream()
                    .filter(p -> "ProduitTest".equals(p.getNom()))
                    .findFirst()
                    .ifPresent(p -> idProduitTest = p.getIdProduit());
        }

        ProduitLocal produit = new ProduitLocal(
                idProduitTest,
                "ProduitModifie",
                "Description modifiee",
                new BigDecimal("149.99"),
                "Textile",
                "Sfax",
                20,
                "test_image2.jpg"
        );

        service.modifier(produit);

        ProduitLocal modifie = service.getById(idProduitTest);
        assertNotNull(modifie, "Le produit modifie devrait exister");
        assertEquals("ProduitModifie", modifie.getNom(), "Le nom devrait etre modifie");
        assertEquals("Textile", modifie.getCategorie(), "La categorie devrait etre modifiee");
        assertEquals(0, new BigDecimal("149.99").compareTo(modifie.getPrix()), "Le prix devrait etre modifie");
        assertEquals(20, modifie.getStock(), "Le stock devrait etre modifie");

        System.out.println("Produit modifie avec succes");
    }

    // ========== TEST 5: RECHERCHER PAR NOM ==========
    @Test
    @Order(5)
    @DisplayName("Test 5: Rechercher un produit par nom")
    void testRechercherParNom() {
        System.out.println("\n[TEST 5] Recherche par nom...");

        List<ProduitLocal> resultats = service.rechercherParNom("ProduitModifie");
        assertNotNull(resultats, "Les resultats ne devraient pas etre null");
        assertFalse(resultats.isEmpty(), "La recherche devrait trouver des resultats");

        assertTrue(resultats.stream().anyMatch(p -> "ProduitModifie".equals(p.getNom())),
                "Le produit modifie devrait etre trouve");

        System.out.println("Produit trouve par recherche");
    }

    // ========== TEST 6: FILTRER PAR CATÉGORIE ==========
    @Test
    @Order(6)
    @DisplayName("Test 6: Filtrer par categorie")
    void testFiltrerParCategorie() {
        System.out.println("\n[TEST 6] Filtrage par categorie...");

        List<ProduitLocal> resultats = service.filtrerParCategorie("Textile");
        assertNotNull(resultats, "Les resultats ne devraient pas etre null");
        assertFalse(resultats.isEmpty(), "Le filtre devrait trouver des produits");

        assertTrue(resultats.stream().allMatch(p -> "Textile".equals(p.getCategorie())),
                "Tous les produits devraient etre de categorie Textile");

        System.out.println("Filtre categorie : " + resultats.size() + " produits");
    }

    // ========== TEST 7: FILTRER PAR RÉGION ==========
    @Test
    @Order(7)
    @DisplayName("Test 7: Filtrer par region")
    void testFiltrerParRegion() {
        System.out.println("\n[TEST 7] Filtrage par region...");

        List<ProduitLocal> resultats = service.filtrerParRegion("Sfax");
        assertNotNull(resultats, "Les resultats ne devraient pas etre null");
        assertFalse(resultats.isEmpty(), "Le filtre devrait trouver des produits");

        assertTrue(resultats.stream().allMatch(p -> "Sfax".equals(p.getRegion())),
                "Tous les produits devraient etre de region Sfax");

        System.out.println("Filtre region : " + resultats.size() + " produits");
    }

    // ========== TEST 8: PRODUITS EN STOCK ==========
    @Test
    @Order(8)
    @DisplayName("Test 8: Produits avec stock > 0")
    void testGetProduitsEnStock() {
        System.out.println("\n[TEST 8] Produits en stock...");

        List<ProduitLocal> resultats = service.afficher().stream()
                .filter(p -> p.getStock() > 0)
                .toList();

        assertNotNull(resultats);
        assertTrue(resultats.stream().allMatch(p -> p.getStock() > 0),
                "Tous les produits devraient avoir stock > 0");

        System.out.println("Produits en stock: " + resultats.size());
    }

    // ========== TEST 9: SUPPRIMER ==========
    @Test
    @Order(9)
    @DisplayName("Test 9: Supprimer un produit")
    void testSupprimerProduit() {
        System.out.println("\n[TEST 9] Suppression du produit...");

        if (idProduitTest == 0) {
            service.afficher().stream()
                    .filter(p -> "ProduitModifie".equals(p.getNom()) || "ProduitTest".equals(p.getNom()))
                    .findFirst()
                    .ifPresent(p -> idProduitTest = p.getIdProduit());
        }

        service.supprimer(idProduitTest);

        assertNull(service.getById(idProduitTest), "Le produit supprime ne devrait plus exister");

        // Reset pour que @AfterAll ne tente pas de re-supprimer
        idProduitTest = 0;

        System.out.println("Produit supprime avec succes");
    }

    // ========== TEST 10: VALIDATION PRIX NEGATIF ==========
    @Test
    @Order(10)
    @DisplayName("Test 10: Validation - prix negatif detecte")
    void testValidationPrixNegatif() {
        System.out.println("\n[TEST 10] Validation prix negatif...");

        BigDecimal prixInvalide = new BigDecimal("-10");
        assertTrue(prixInvalide.compareTo(BigDecimal.ZERO) < 0,
                "Un prix negatif doit etre detecte comme invalide");

        System.out.println("Validation prix OK");
    }

    // ========== TEST 11: VALIDATION STOCK NEGATIF ==========
    @Test
    @Order(11)
    @DisplayName("Test 11: Validation - stock negatif detecte")
    void testValidationStockNegatif() {
        System.out.println("\n[TEST 11] Validation stock negatif...");

        int stockInvalide = -5;
        assertTrue(stockInvalide < 0,
                "Un stock negatif doit etre detecte comme invalide");

        System.out.println("Validation stock OK");
    }
}