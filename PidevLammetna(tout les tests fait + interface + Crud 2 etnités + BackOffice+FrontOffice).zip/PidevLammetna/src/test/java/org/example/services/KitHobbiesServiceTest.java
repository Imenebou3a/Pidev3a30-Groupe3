package org.example.services;

import org.example.entities.KitHobbies;
import org.junit.jupiter.api.*;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class KitHobbiesServiceTest {

    private static KitHobbiesService service;
    private static int idKitTest;
    private static final int ID_PRODUIT_EXISTANT = 1;

    @BeforeAll
    static void setUp() {
        service = new KitHobbiesService();
        System.out.println("=== Debut des tests KitHobbies ===");
    }

    @AfterAll
    static void tearDown() {
        // Nettoyage UNIQUE à la fin de TOUS les tests
        List<KitHobbies> kits = service.afficher();
        for (KitHobbies k : kits) {
            if (k.getNomKit() != null &&
                    (k.getNomKit().contains("Test") || k.getNomKit().contains("Modifie"))) {
                service.supprimer(k.getIdKit());
                System.out.println("  Nettoye: " + k.getNomKit());
            }
        }
        System.out.println("=== Fin des tests KitHobbies ===");
    }

    // ========== TEST 1: AJOUTER ==========
    @Test
    @Order(1)
    @DisplayName("Test 1: Ajouter un kit")
    void testAjouterKit() {
        System.out.println("\n[TEST 1] Ajout d'un kit...");

        KitHobbies kit = new KitHobbies(
                "KitTest",
                "Description de test",
                "Poterie",
                "Facile",
                new BigDecimal("199.99"),
                15,
                "kit_test.jpg",
                ID_PRODUIT_EXISTANT
        );

        service.ajouter(kit);

        List<KitHobbies> kits = service.afficher();
        assertFalse(kits.isEmpty(), "La liste ne devrait pas etre vide apres ajout");

        KitHobbies kitAjoute = kits.stream()
                .filter(k -> "KitTest".equals(k.getNomKit()))
                .findFirst()
                .orElse(null);

        assertNotNull(kitAjoute, "Le kit ajoute devrait exister");
        idKitTest = kitAjoute.getIdKit();

        System.out.println("Kit ajoute avec ID: " + idKitTest);
    }

    // ========== TEST 2: AFFICHER ==========
    @Test
    @Order(2)
    @DisplayName("Test 2: Afficher tous les kits")
    void testAfficherKits() {
        System.out.println("\n[TEST 2] Affichage de tous les kits...");

        List<KitHobbies> kits = service.afficher();
        assertNotNull(kits, "La liste ne devrait pas etre null");
        assertFalse(kits.isEmpty(), "La liste devrait contenir des kits");

        System.out.println("Nombre de kits: " + kits.size());
    }

    // ========== TEST 3: GET BY ID ==========
    @Test
    @Order(3)
    @DisplayName("Test 3: Recuperer un kit par ID")
    void testGetById() {
        System.out.println("\n[TEST 3] Recuperation du kit par ID: " + idKitTest);

        // Sécurité : si idKitTest non initialisé, le retrouver depuis la DB
        if (idKitTest == 0) {
            service.afficher().stream()
                    .filter(k -> "KitTest".equals(k.getNomKit()))
                    .findFirst()
                    .ifPresent(k -> idKitTest = k.getIdKit());
        }

        KitHobbies kit = service.getById(idKitTest);
        assertNotNull(kit, "Le kit devrait exister");
        assertEquals("KitTest", kit.getNomKit(), "Le nom devrait correspondre");
        assertEquals("Poterie", kit.getTypeArtisanat(), "Le type devrait correspondre");
        assertEquals("Facile", kit.getNiveauDifficulte(), "Le niveau devrait correspondre");
        assertEquals(0, new BigDecimal("199.99").compareTo(kit.getPrix()), "Le prix devrait correspondre");

        System.out.println("Kit recupere: " + kit.getNomKit());
    }

    // ========== TEST 4: MODIFIER ==========
    @Test
    @Order(4)
    @DisplayName("Test 4: Modifier un kit")
    void testModifierKit() {
        System.out.println("\n[TEST 4] Modification du kit...");

        if (idKitTest == 0) {
            service.afficher().stream()
                    .filter(k -> "KitTest".equals(k.getNomKit()))
                    .findFirst()
                    .ifPresent(k -> idKitTest = k.getIdKit());
        }

        KitHobbies kit = new KitHobbies(
                idKitTest,
                "KitModifie",
                "Description modifiee",
                "Tissage",
                "Intermediaire",
                new BigDecimal("249.99"),
                25,
                "kit_modifie.jpg",
                ID_PRODUIT_EXISTANT
        );

        service.modifier(kit);

        KitHobbies modifie = service.getById(idKitTest);
        assertNotNull(modifie, "Le kit modifie devrait exister");
        assertEquals("KitModifie", modifie.getNomKit(), "Le nom devrait etre modifie");
        assertEquals("Tissage", modifie.getTypeArtisanat(), "Le type devrait etre modifie");
        assertEquals("Intermediaire", modifie.getNiveauDifficulte(), "Le niveau devrait etre modifie");
        assertEquals(0, new BigDecimal("249.99").compareTo(modifie.getPrix()), "Le prix devrait etre modifie");
        assertEquals(25, modifie.getStock(), "Le stock devrait etre modifie");

        System.out.println("Kit modifie avec succes");
    }

    // ========== TEST 5: RECHERCHER PAR NOM ==========
    @Test
    @Order(5)
    @DisplayName("Test 5: Rechercher un kit par nom")
    void testRechercherParNom() {
        System.out.println("\n[TEST 5] Recherche par nom...");

        List<KitHobbies> resultats = service.rechercherParNom("KitModifie");
        assertNotNull(resultats, "Les resultats ne devraient pas etre null");
        assertFalse(resultats.isEmpty(), "La recherche devrait trouver des resultats");

        boolean trouve = resultats.stream().anyMatch(k -> "KitModifie".equals(k.getNomKit()));
        assertTrue(trouve, "Le kit modifie devrait etre trouve");

        System.out.println("Kit trouve par recherche");
    }

    // ========== TEST 6: FILTRER PAR TYPE ==========
    @Test
    @Order(6)
    @DisplayName("Test 6: Filtrer par type d'artisanat")
    void testFiltrerParType() {
        System.out.println("\n[TEST 6] Filtrage par type...");

        List<KitHobbies> resultats = service.filtrerParType("Tissage");
        assertNotNull(resultats, "Les resultats ne devraient pas etre null");
        assertFalse(resultats.isEmpty(), "Le filtre devrait trouver des kits");

        boolean tousTissage = resultats.stream().allMatch(k -> "Tissage".equals(k.getTypeArtisanat()));
        assertTrue(tousTissage, "Tous les kits devraient etre de type Tissage");

        System.out.println("Filtre par type : " + resultats.size() + " kits");
    }

    // ========== TEST 7: FILTRER PAR NIVEAU ==========
    @Test
    @Order(7)
    @DisplayName("Test 7: Filtrer par niveau de difficulte")
    void testFiltrerParNiveau() {
        System.out.println("\n[TEST 7] Filtrage par niveau...");

        List<KitHobbies> resultats = service.filtrerParNiveau("Intermediaire");
        assertNotNull(resultats, "Les resultats ne devraient pas etre null");
        assertFalse(resultats.isEmpty(), "Le filtre devrait trouver des kits");

        boolean tousInter = resultats.stream().allMatch(k -> "Intermediaire".equals(k.getNiveauDifficulte()));
        assertTrue(tousInter, "Tous les kits devraient etre de niveau Intermediaire");

        System.out.println("Filtre par niveau : " + resultats.size() + " kits");
    }

    // ========== TEST 8: KITS EN STOCK ==========
    @Test
    @Order(8)
    @DisplayName("Test 8: Kits avec stock > 0")
    void testGetKitsEnStock() {
        System.out.println("\n[TEST 8] Kits en stock...");

        List<KitHobbies> resultats = service.afficher().stream()
                .filter(k -> k.getStock() > 0)
                .toList();

        assertNotNull(resultats, "Les resultats ne devraient pas etre null");
        assertTrue(resultats.stream().allMatch(k -> k.getStock() > 0),
                "Tous les kits devraient avoir un stock > 0");

        System.out.println("Kits en stock: " + resultats.size());
    }

    // ========== TEST 9: SUPPRIMER ==========
    @Test
    @Order(9)
    @DisplayName("Test 9: Supprimer un kit")
    void testSupprimerKit() {
        System.out.println("\n[TEST 9] Suppression du kit...");

        if (idKitTest == 0) {
            service.afficher().stream()
                    .filter(k -> "KitModifie".equals(k.getNomKit()) || "KitTest".equals(k.getNomKit()))
                    .findFirst()
                    .ifPresent(k -> idKitTest = k.getIdKit());
        }

        service.supprimer(idKitTest);

        KitHobbies supprime = service.getById(idKitTest);
        assertNull(supprime, "Le kit supprime ne devrait plus exister");

        // Reset pour que @AfterAll ne tente pas de re-supprimer
        idKitTest = 0;

        System.out.println("Kit supprime avec succes");
    }

    // ========== TEST 10: VALIDATION PRIX NEGATIF ==========
    @Test
    @Order(10)
    @DisplayName("Test 10: Validation - prix negatif detecte")
    void testValidationPrixNegatif() {
        System.out.println("\n[TEST 10] Test validation prix negatif...");

        BigDecimal prixInvalide = new BigDecimal("-50");
        assertTrue(prixInvalide.compareTo(BigDecimal.ZERO) < 0,
                "Un prix negatif devrait etre detecte comme invalide");

        System.out.println("Validation prix negatif OK");
    }

    // ========== TEST 11: VALIDATION STOCK NEGATIF ==========
    @Test
    @Order(11)
    @DisplayName("Test 11: Validation - stock negatif detecte")
    void testValidationStockNegatif() {
        System.out.println("\n[TEST 11] Test validation stock negatif...");

        int stockInvalide = -10;
        assertTrue(stockInvalide < 0,
                "Un stock negatif devrait etre detecte comme invalide");

        System.out.println("Validation stock negatif OK");
    }
}