package org.example.services;

import org.example.entities.ProduitLocal;
import org.example.interfaces.IProduitLocal;
import org.example.utils.MyDataBase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Service de gestion des produits locaux
 */
public class ProduitLocalService implements IProduitLocal {

    private Connection connection;

    public ProduitLocalService() {
        this.connection = MyDataBase.getConnection();
    }

    @Override
    public void ajouter(ProduitLocal produit) {
        String sql = "INSERT INTO produit_local (nom, description, prix, categorie, region, stock, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement pst = connection.prepareStatement(sql)) {
            pst.setString(1, produit.getNom());
            pst.setString(2, produit.getDescription());
            pst.setBigDecimal(3, produit.getPrix());
            pst.setString(4, produit.getCategorie());
            pst.setString(5, produit.getRegion());
            pst.setInt(6, produit.getStock());
            pst.setString(7, produit.getImageUrl());

            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("✅ Produit ajouté avec succès : " + produit.getNom());
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur lors de l'ajout du produit : " + e.getMessage());
        }
    }

    @Override
    public void modifier(ProduitLocal produit) {
        String sql = "UPDATE produit_local SET nom=?, description=?, prix=?, categorie=?, region=?, stock=?, image_url=? WHERE id_produit=?";

        try (PreparedStatement pst = connection.prepareStatement(sql)) {
            pst.setString(1, produit.getNom());
            pst.setString(2, produit.getDescription());
            pst.setBigDecimal(3, produit.getPrix());
            pst.setString(4, produit.getCategorie());
            pst.setString(5, produit.getRegion());
            pst.setInt(6, produit.getStock());
            pst.setString(7, produit.getImageUrl());
            pst.setInt(8, produit.getIdProduit());

            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("✅ Produit modifié avec succès : " + produit.getNom());
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur lors de la modification du produit : " + e.getMessage());
        }
    }

    @Override
    public void supprimer(int id) {
        String sql = "DELETE FROM produit_local WHERE id_produit=?";

        try (PreparedStatement pst = connection.prepareStatement(sql)) {
            pst.setInt(1, id);

            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("✅ Produit supprimé avec succès (ID: " + id + ")");
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur lors de la suppression du produit : " + e.getMessage());
        }
    }

    @Override
    public List<ProduitLocal> afficher() {
        List<ProduitLocal> produits = new ArrayList<>();
        String sql = "SELECT * FROM produit_local ORDER BY id_produit DESC";

        try (Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                ProduitLocal produit = new ProduitLocal(
                        rs.getInt("id_produit"),
                        rs.getString("nom"),
                        rs.getString("description"),
                        rs.getBigDecimal("prix"),
                        rs.getString("categorie"),
                        rs.getString("region"),
                        rs.getInt("stock"),
                        rs.getString("image_url")
                );
                produits.add(produit);
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur lors de la récupération des produits : " + e.getMessage());
        }

        return produits;
    }

    @Override
    public ProduitLocal getById(int id) {
        String sql = "SELECT * FROM produit_local WHERE id_produit=?";

        try (PreparedStatement pst = connection.prepareStatement(sql)) {
            pst.setInt(1, id);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return new ProduitLocal(
                            rs.getInt("id_produit"),
                            rs.getString("nom"),
                            rs.getString("description"),
                            rs.getBigDecimal("prix"),
                            rs.getString("categorie"),
                            rs.getString("region"),
                            rs.getInt("stock"),
                            rs.getString("image_url")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur lors de la récupération du produit : " + e.getMessage());
        }

        return null;
    }

    @Override
    public List<ProduitLocal> rechercherParNom(String nom) {
        List<ProduitLocal> produits = new ArrayList<>();
        String sql = "SELECT * FROM produit_local WHERE nom LIKE ? ORDER BY nom";

        try (PreparedStatement pst = connection.prepareStatement(sql)) {
            pst.setString(1, "%" + nom + "%");

            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    ProduitLocal produit = new ProduitLocal(
                            rs.getInt("id_produit"),
                            rs.getString("nom"),
                            rs.getString("description"),
                            rs.getBigDecimal("prix"),
                            rs.getString("categorie"),
                            rs.getString("region"),
                            rs.getInt("stock"),
                            rs.getString("image_url")
                    );
                    produits.add(produit);
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur lors de la recherche : " + e.getMessage());
        }

        return produits;
    }

    @Override
    public List<ProduitLocal> filtrerParCategorie(String categorie) {
        List<ProduitLocal> produits = new ArrayList<>();
        String sql = "SELECT * FROM produit_local WHERE categorie=? ORDER BY nom";

        try (PreparedStatement pst = connection.prepareStatement(sql)) {
            pst.setString(1, categorie);

            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    ProduitLocal produit = new ProduitLocal(
                            rs.getInt("id_produit"),
                            rs.getString("nom"),
                            rs.getString("description"),
                            rs.getBigDecimal("prix"),
                            rs.getString("categorie"),
                            rs.getString("region"),
                            rs.getInt("stock"),
                            rs.getString("image_url")
                    );
                    produits.add(produit);
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur lors du filtrage par catégorie : " + e.getMessage());
        }

        return produits;
    }

    @Override
    public List<ProduitLocal> filtrerParRegion(String region) {
        List<ProduitLocal> produits = new ArrayList<>();
        String sql = "SELECT * FROM produit_local WHERE region=? ORDER BY nom";

        try (PreparedStatement pst = connection.prepareStatement(sql)) {
            pst.setString(1, region);

            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    ProduitLocal produit = new ProduitLocal(
                            rs.getInt("id_produit"),
                            rs.getString("nom"),
                            rs.getString("description"),
                            rs.getBigDecimal("prix"),
                            rs.getString("categorie"),
                            rs.getString("region"),
                            rs.getInt("stock"),
                            rs.getString("image_url")
                    );
                    produits.add(produit);
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur lors du filtrage par région : " + e.getMessage());
        }

        return produits;
    }

    @Override
    public List<ProduitLocal> getProduitsEnStock() {
        List<ProduitLocal> produits = new ArrayList<>();
        String sql = "SELECT * FROM produit_local WHERE stock > 0 ORDER BY nom";

        try (Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                ProduitLocal produit = new ProduitLocal(
                        rs.getInt("id_produit"),
                        rs.getString("nom"),
                        rs.getString("description"),
                        rs.getBigDecimal("prix"),
                        rs.getString("categorie"),
                        rs.getString("region"),
                        rs.getInt("stock"),
                        rs.getString("image_url")
                );
                produits.add(produit);
            }
        } catch (SQLException e) {
            System.err.println("❌ Erreur lors de la récupération des produits en stock : " + e.getMessage());
        }

        return produits;
    }
}