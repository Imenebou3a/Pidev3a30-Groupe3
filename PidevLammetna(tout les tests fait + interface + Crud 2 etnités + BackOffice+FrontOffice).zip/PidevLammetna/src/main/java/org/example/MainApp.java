package org.example;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

public class MainApp extends Application {

    private Stage primaryStage;
    private BorderPane mainLayout;
    private Button btnDashboard, btnProduits, btnKits, btnEvenements, btnHebergement, btnForum, btnBoutique;
    private Scene backofficeScene, frontofficScene;

    @Override
    public void start(Stage primaryStage) throws Exception {
        this.primaryStage = primaryStage;
        primaryStage.setTitle("Lammetna Admin");
        primaryStage.setResizable(true);

        mainLayout = new BorderPane();
        mainLayout.setLeft(creerSidebar());
        mainLayout.setTop(creerHeader());

        chargerDashboard();

        backofficeScene = new Scene(mainLayout, 1400, 850);
        backofficeScene.getStylesheets().add(getClass().getResource("/backoffice/global.css").toExternalForm());
        primaryStage.setScene(backofficeScene);
        primaryStage.centerOnScreen();
        primaryStage.show();
    }

    private VBox creerSidebar() {
        VBox sidebar = new VBox(0);
        sidebar.setPrefWidth(220);
        sidebar.setMinWidth(220);
        sidebar.getStyleClass().add("sidebar");

        VBox logoBox = new VBox(4);
        logoBox.getStyleClass().add("sidebar-logo");
        logoBox.setPadding(new Insets(28, 20, 24, 20));
        Label logoTitle = new Label("LAMMETNA");
        logoTitle.getStyleClass().add("logo-title");
        Label logoSub = new Label("Admin Panel");
        logoSub.getStyleClass().add("logo-sub");
        logoBox.getChildren().addAll(logoTitle, logoSub);

        Region sep = new Region();
        sep.getStyleClass().add("sidebar-sep");
        sep.setPrefHeight(1);

        Label menuLabel = new Label("MENU PRINCIPAL");
        menuLabel.getStyleClass().add("sidebar-section-label");
        menuLabel.setPadding(new Insets(20, 20, 8, 20));

        btnDashboard = creerBoutonSidebar("  📊 Dashboard");
        btnProduits  = creerBoutonSidebar("  🏺 Produits Locaux");
        btnKits      = creerBoutonSidebar("  🎨 Kits Hobbies");
        btnEvenements = creerBoutonSidebar("  🎪 Événements");
        btnHebergement = creerBoutonSidebar("  🏠 Hébergement");
        btnForum = creerBoutonSidebar("  💬 Forum");

        btnDashboard.setOnAction(e -> { setActif(btnDashboard); try { chargerDashboard(); } catch (Exception ex) { ex.printStackTrace(); }});
        btnProduits.setOnAction(e  -> { setActif(btnProduits);  try { chargerProduits(); } catch (Exception ex) { ex.printStackTrace(); }});
        btnKits.setOnAction(e      -> { setActif(btnKits);      try { chargerKits();     } catch (Exception ex) { ex.printStackTrace(); }});
        btnEvenements.setOnAction(e -> { setActif(btnEvenements); afficherMessageEnConstruction("Événements & Participations"); });
        btnHebergement.setOnAction(e -> { setActif(btnHebergement); afficherMessageEnConstruction("Hébergement & Réservations"); });
        btnForum.setOnAction(e -> { setActif(btnForum); afficherMessageEnConstruction("Forum"); });

        // Séparateur pour la section front
        Region sep2 = new Region();
        sep2.getStyleClass().add("sidebar-sep");
        sep2.setPrefHeight(1);
        sep2.setPadding(new Insets(20, 0, 0, 0));

        Label frontLabel = new Label("VISITEUR");
        frontLabel.getStyleClass().add("sidebar-section-label");
        frontLabel.setPadding(new Insets(20, 20, 8, 20));

        btnBoutique = creerBoutonSidebar("  🛍️ Boutique");
        btnBoutique.setOnAction(e -> { setActif(btnBoutique); try { chargerBoutique(); } catch (Exception ex) { ex.printStackTrace(); }});

        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);
        Label version = new Label("v1.0.0 — Lammetna");
        version.getStyleClass().add("sidebar-version");
        version.setPadding(new Insets(0, 0, 20, 20));

        sidebar.getChildren().addAll(logoBox, sep, menuLabel, btnDashboard, btnProduits, btnKits,
                btnEvenements, btnHebergement, btnForum,
                sep2, frontLabel, btnBoutique, spacer, version);
        setActif(btnDashboard);
        return sidebar;
    }

    private Button creerBoutonSidebar(String texte) {
        Button btn = new Button(texte);
        btn.getStyleClass().add("sidebar-btn");
        btn.setMaxWidth(Double.MAX_VALUE);
        btn.setAlignment(Pos.CENTER_LEFT);
        return btn;
    }

    private void setActif(Button actif) {
        for (Button b : new Button[]{btnDashboard, btnProduits, btnKits, btnEvenements, btnHebergement, btnForum, btnBoutique}) {
            if (b != null) b.getStyleClass().remove("sidebar-btn-active");
        }
        actif.getStyleClass().add("sidebar-btn-active");
    }

    private HBox creerHeader() {
        HBox header = new HBox();
        header.getStyleClass().add("main-header");
        header.setAlignment(Pos.CENTER_RIGHT);
        header.setPadding(new Insets(0, 30, 0, 30));
        header.setPrefHeight(60);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label adminLabel = new Label("Admin Lammetna");
        adminLabel.getStyleClass().add("header-admin-label");

        Label avatar = new Label("AL");
        avatar.getStyleClass().add("header-avatar");

        header.getChildren().addAll(spacer, adminLabel, avatar);
        return header;
    }

    private void chargerDashboard() throws Exception {
        Parent p = FXMLLoader.load(getClass().getResource("/backoffice/dashboard.fxml"));
        mainLayout.setCenter(p);
    }

    private void chargerProduits() throws Exception {
        Parent p = FXMLLoader.load(getClass().getResource("/backoffice/produit_back.fxml"));
        mainLayout.setCenter(p);
    }

    private void chargerKits() throws Exception {
        Parent p = FXMLLoader.load(getClass().getResource("/backoffice/kit_back.fxml"));
        mainLayout.setCenter(p);
    }

    private void chargerBoutique() throws Exception {
        if (frontofficScene == null) {
            Parent frontRoot = FXMLLoader.load(getClass().getResource("/frontoffice/front_home.fxml"));
            frontofficScene = new Scene(frontRoot, 1400, 850);
            frontofficScene.getStylesheets().add(getClass().getResource("/frontoffice/front.css").toExternalForm());
        }

        // Basculer vers la scène front office
        primaryStage.setScene(frontofficScene);
        primaryStage.setTitle("Lammetna - Boutique");
    }

    private void afficherMessageEnConstruction(String module) {
        // Créer un message "En construction" stylé
        VBox messageBox = new VBox(20);
        messageBox.setAlignment(Pos.CENTER);
        messageBox.setStyle("-fx-background-color: #fdf8f2;");

        Label icon = new Label("🚧");
        icon.setStyle("-fx-font-size: 72px;");

        Label titre = new Label("Module " + module);
        titre.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: #1A7A7A;");

        Label sousTitre = new Label("En cours de développement");
        sousTitre.setStyle("-fx-font-size: 18px; -fx-text-fill: #666;");

        Label description = new Label("Cette fonctionnalité sera bientôt disponible.");
        description.setStyle("-fx-font-size: 14px; -fx-text-fill: #999;");

        messageBox.getChildren().addAll(icon, titre, sousTitre, description);
        mainLayout.setCenter(messageBox);
    }

    public static void main(String[] args) { launch(args); }
}