package org.example.controllers.frontoffice;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import org.example.entities.ProduitLocal;
import org.example.services.ProduitLocalService;

import java.io.File;
import java.util.List;

/**
 * Controller Frontoffice pour l'affichage des produits locaux
 * Interface utilisateur (consultation et recherche)
 */
public class ProduitFrontController {

    // ===== COMPOSANTS FXML =====
    @FXML private TextField searchField;
    @FXML private ComboBox<String> filterCategorie;
    @FXML private ComboBox<String> filterRegion;
    @FXML private ComboBox<String> filterTri;
    @FXML private GridPane gridProduits;
    @FXML private ScrollPane scrollPane;
    @FXML private Label lblNombreResultats;

    // ===== SERVICES =====
    private ProduitLocalService produitService;
    private List<ProduitLocal> produitsCourants;

    // ===== CONSTANTES =====
    private static final int COLONNES = 3;
    private static final double CARD_WIDTH = 280;
    private static final double CARD_HEIGHT = 400;

    /**
     * Initialisation du controller
     */
    @FXML
    public void initialize() {
        produitService = new ProduitLocalService();

        initialiserFiltres();
        configurerListeners();
        chargerProduits();
    }

    /**
     * Initialiser les filtres
     */
    private void initialiserFiltres() {
        // Catégories
        filterCategorie.setItems(FXCollections.observableArrayList(
                "Toutes", "Artisanat", "Gastronomie", "Textile", "Décoration", "Bijoux", "Cosmétiques"
        ));
        filterCategorie.setValue("Toutes");

        // Régions
        filterRegion.setItems(FXCollections.observableArrayList(
                "Toutes", "Tunis", "Nabeul", "Kairouan", "Sousse", "Sfax", "Bizerte"
        ));
        filterRegion.setValue("Toutes");

        // Options de tri
        filterTri.setItems(FXCollections.observableArrayList(
                "Plus récents", "Prix croissant", "Prix décroissant", "Nom A-Z", "Nom Z-A"
        ));
        filterTri.setValue("Plus récents");
    }

    /**
     * Configurer les listeners
     */
    private void configurerListeners() {
        searchField.textProperty().addListener((obs, oldValue, newValue) -> appliquerFiltres());
        filterCategorie.setOnAction(e -> appliquerFiltres());
        filterRegion.setOnAction(e -> appliquerFiltres());
        filterTri.setOnAction(e -> trierProduits());
    }

    /**
     * Charger tous les produits
     */
    private void chargerProduits() {
        produitsCourants = produitService.getProduitsEnStock();
        afficherProduits(produitsCourants);
    }

    /**
     * Appliquer les filtres
     */
    private void appliquerFiltres() {
        List<ProduitLocal> produitsFiltres = produitService.afficher();

        // Filtre par recherche
        String recherche = searchField.getText().trim();
        if (!recherche.isEmpty()) {
            produitsFiltres = produitsFiltres.stream()
                    .filter(p -> p.getNom().toLowerCase().contains(recherche.toLowerCase()) ||
                            p.getDescription().toLowerCase().contains(recherche.toLowerCase()))
                    .toList();
        }

        // Filtre par catégorie
        String categorie = filterCategorie.getValue();
        if (categorie != null && !categorie.equals("Toutes")) {
            produitsFiltres = produitsFiltres.stream()
                    .filter(p -> p.getCategorie().equals(categorie))
                    .toList();
        }

        // Filtre par région
        String region = filterRegion.getValue();
        if (region != null && !region.equals("Toutes")) {
            produitsFiltres = produitsFiltres.stream()
                    .filter(p -> p.getRegion().equals(region))
                    .toList();
        }

        // Filtrer uniquement les produits en stock
        produitsFiltres = produitsFiltres.stream()
                .filter(p -> p.getStock() > 0)
                .toList();

        produitsCourants = produitsFiltres;
        trierProduits();
    }

    /**
     * Trier les produits
     */
    private void trierProduits() {
        String tri = filterTri.getValue();
        List<ProduitLocal> produitsTries = produitsCourants;

        switch (tri) {
            case "Prix croissant":
                produitsTries = produitsCourants.stream()
                        .sorted((p1, p2) -> p1.getPrix().compareTo(p2.getPrix()))
                        .toList();
                break;
            case "Prix décroissant":
                produitsTries = produitsCourants.stream()
                        .sorted((p1, p2) -> p2.getPrix().compareTo(p1.getPrix()))
                        .toList();
                break;
            case "Nom A-Z":
                produitsTries = produitsCourants.stream()
                        .sorted((p1, p2) -> p1.getNom().compareTo(p2.getNom()))
                        .toList();
                break;
            case "Nom Z-A":
                produitsTries = produitsCourants.stream()
                        .sorted((p1, p2) -> p2.getNom().compareTo(p1.getNom()))
                        .toList();
                break;
        }

        afficherProduits(produitsTries);
    }

    /**
     * Afficher les produits dans la grille
     */
    private void afficherProduits(List<ProduitLocal> produits) {
        gridProduits.getChildren().clear();

        int row = 0;
        int col = 0;

        for (ProduitLocal produit : produits) {
            VBox card = creerCardProduit(produit);
            gridProduits.add(card, col, row);

            col++;
            if (col >= COLONNES) {
                col = 0;
                row++;
            }
        }

        // Mettre à jour le nombre de résultats
        if (lblNombreResultats != null) {
            lblNombreResultats.setText(produits.size() + " produit(s) trouvé(s)");
        }
    }

    /**
     * Créer une card pour un produit
     */
    private VBox creerCardProduit(ProduitLocal produit) {
        VBox card = new VBox(15);
        card.getStyleClass().add("product-card");
        card.setPrefSize(CARD_WIDTH, CARD_HEIGHT);
        card.setAlignment(Pos.TOP_CENTER);
        card.setPadding(new Insets(20));

        // Image du produit
        ImageView imageView = new ImageView();
        imageView.setFitWidth(240);
        imageView.setFitHeight(180);
        imageView.setPreserveRatio(true);
        imageView.getStyleClass().add("product-image");

        try {
            File imageFile = new File("src/main/resources/images/" + produit.getImageUrl());
            if (imageFile.exists()) {
                imageView.setImage(new Image(imageFile.toURI().toString()));
            } else {
                // Image par défaut
                imageView.setImage(new Image("file:src/main/resources/images/default.png"));
            }
        } catch (Exception e) {
            System.err.println("Erreur chargement image: " + e.getMessage());
        }

        // Nom du produit
        Label lblNom = new Label(produit.getNom());
        lblNom.getStyleClass().add("product-name");
        lblNom.setWrapText(true);
        lblNom.setMaxWidth(240);

        // Catégorie
        Label lblCategorie = new Label(produit.getCategorie());
        lblCategorie.getStyleClass().add("product-category");

        // Région
        Label lblRegion = new Label("📍 " + produit.getRegion());
        lblRegion.getStyleClass().add("product-region");

        // Prix
        Label lblPrix = new Label(produit.getPrix() + " TND");
        lblPrix.getStyleClass().add("product-price");

        // Stock
        Label lblStock = new Label("En stock: " + produit.getStock());
        if (produit.getStock() < 5) {
            lblStock.getStyleClass().add("product-stock-low");
        } else {
            lblStock.getStyleClass().add("product-stock");
        }

        // Bouton Voir détails
        Button btnDetails = new Button("Voir détails");
        btnDetails.getStyleClass().add("btn-primary");
        btnDetails.setOnAction(e -> afficherDetails(produit));

        card.getChildren().addAll(imageView, lblNom, lblCategorie, lblRegion, lblPrix, lblStock, btnDetails);

        return card;
    }

    /**
     * Afficher les détails d'un produit
     */
    private void afficherDetails(ProduitLocal produit) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Détails du produit");
        alert.setHeaderText(produit.getNom());

        String details = String.format(
                "Description: %s\n\n" +
                        "Catégorie: %s\n" +
                        "Région: %s\n" +
                        "Prix: %.2f TND\n" +
                        "Stock disponible: %d unités",
                produit.getDescription(),
                produit.getCategorie(),
                produit.getRegion(),
                produit.getPrix(),
                produit.getStock()
        );

        alert.setContentText(details);
        alert.showAndWait();
    }

    /**
     * Action : Réinitialiser les filtres
     */
    @FXML
    private void handleResetFiltres() {
        searchField.clear();
        filterCategorie.setValue("Toutes");
        filterRegion.setValue("Toutes");
        filterTri.setValue("Plus récents");
        chargerProduits();
    }
}