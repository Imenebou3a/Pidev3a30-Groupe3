package org.example.interfaces;

import java.util.List;

/**
 * Interface générique pour les opérations CRUD
 * @param <T> Type d'entité
 */
public interface IKit<T> {

    /**
     * Ajouter une entité
     * @param entity entité à ajouter
     */
    void ajouter(T entity);

    /**
     * Modifier une entité
     * @param entity entité à modifier
     */
    void modifier(T entity);

    /**
     * Supprimer une entité par son ID
     * @param id identifiant de l'entité
     */
    void supprimer(int id);

    /**
     * Récupérer toutes les entités
     * @return Liste de toutes les entités
     */
    List<T> afficher();

    /**
     * Récupérer une entité par son ID
     * @param id identifiant de l'entité
     * @return L'entité trouvée ou null
     */
    T getById(int id);
}